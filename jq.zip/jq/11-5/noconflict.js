var jq=$.noConflict();
jq(function($){
	var bgW= $(document).width();
		alert(bgW)
});