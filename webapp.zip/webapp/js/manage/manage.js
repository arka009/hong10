$(function(){
    
	// ----------------------------------------------
	// english 鼠标悬浮 提示升级
	$('.en').hover(
			function(){
				
				$(".sy_update").animate({
					"top" : "0px"
				});
				},function(){
				
				$(".sy_update").animate({
					"top" : "-25px"
				});
				
			}
		);
		var open_flag=true;
		$(".hospital_homepage .open").find("span").click(function(){
			if(open_flag){
				$(this).parent().siblings(".primary").css({
					height:"auto"
				});
				$(this).html("收起");
				open_flag=false;
			}else{
				$(this).parent().siblings(".primary").css({
					height:"183px"
				});
				open_flag=true;
				$(this).html("展开");
			}
			
		});
		
		
		$(".item ul a li").hover(function(){

			
			if($(this).attr("class")=="active"){
				$(this).css({
					"background":"#1495d7 url(../../img/manage/item_active.png) center bottom no-repeat"
				});
			}else{
				$(this).css({
					"background":"#1495d7"
				});
			}
			
			
		},function(){
			$(this).css({
				"background":"#36d3ff"
			});
			$(".item ul a li.active").css({
				"background":"#1495d7 url(../../img/manage/item_active.png) center bottom no-repeat"
			});
		});
		
		
		
		
		/*$(".menu li").hover(function(){	
			$(this).addClass("active");
			
		},function(){
			$(this).removeClass("active");
		});
		$(".menu li").bind("click",function(){
			
			$(this).addClass("active");
		})*/
		
		
		/*background:#1395d8 url(../../img/manage/menu_dot_active.png) left center no-repeat*/
		/*
		$(".menu li").hover(function(){
			$(".menu li").css({
				"background":"url(../../img/manage/menu_dot.png) left center no-repeat"
			})
			$(this).css({
				"color":"#fff",
				"background":"url(../../img/manage/menu_dot_active.png) #1395d8  left center no-repeat"
			});
		},function(){
			$(this).css({
				"color":"#595757",
				"background":"url(../../img/manage/menu_dot.png) left center no-repeat"
			});
			$(".menu li.active").css({
				"color":"#fff",
				"background":"url(../../img/manage/menu_dot_active.png) #1395d8  left center no-repeat"
			});
		});*/
		
		$(".menu li").hover(function(){
			$(".menu li").removeClass();
			$(".hidden").css("display","none");
			$(this).addClass("active");
			$(".hidden").eq($(this).index()).css("display","block");
		})
		
		
		
	// ----------------------------------------------
	// 左侧菜单点击，右侧切换部分
	$("#menu li").click(function(){
		$("#menu li").attr("class","");
		$(this).attr("class","active");
		$(".hidden").css("display","none");
		$(".hidden").eq($(this).index()).css("display","block");
	});
		
		
		
		
	
	
	// ----------------------------------------------
	// 右侧一表了解人民医院质量管理和一图梳理人民医院质量管理，切换部分
	$("#quality li").click(function(){
		$("#quality li").attr("class","");
		$(this).attr("class","active");
		$("#quality").siblings(".tab_photo_box1").css("display","none");
		$("#quality").siblings(".tab_photo_box1").eq($(this).index()).css("display","block");
	});
	
	// ----------------------------------------------
	// 右侧一表了解人民医院信息化管理和一图梳理人民医院信息化管理，切换部分
	$("#informatization li").click(function(){
		$("#informatization li").attr("class","");
		$(this).attr("class","active");
		/*$(".tab_photo_box").css("display","none");
		$(".tab_photo_box").eq($(this).index()).css("display","block");*/
		$("#informatization").siblings(".tab_photo_box2").css("display","none");
		$("#informatization").siblings(".tab_photo_box2").eq($(this).index()).css("display","block");
	});
	
		
	// ----------------------------------------------
	// 单纯左侧菜单切换，右侧锚点定位部分
	$("#menu_eva li").click(function(){
		$("#menu_eva li").attr("class","");
		$(this).attr("class","active");
	});
	
	
	
	// ----------------------------------------------
	// 单纯医院首页、管理菁华、管理课程、经典案例菜单切换，下侧锚点定位部分
	$("#hospital_item li").click(function(){
		
		$("#hospital_item li").removeAttr("class","active");
		$(this).attr("class","active");
		$(".detail .hos_t").slideUp(200);
		/*$("#hospital_item li").attr("class","");
		$(this).attr("class","active");
		
		$(".detail .hos_t").hide();
		$(".detail .hos_t").eq($(this).index()).show();*/
	});
	
	$("#hospital_item li").eq(0).click(function(){
		$(".detail .hos_t").slideDown(200);
	});
	$("#hospital_item li").eq(1).click(function(){
		$(".detail .hos_t").eq(1).slideDown(200);
	});
	$("#hospital_item li").eq(2).click(function(){
		$(".detail .hos_t").eq(2).slideDown(200);
	});	
	$("#hospital_item li").eq(3).click(function(){
		$(".detail .hos_t").eq(3).slideDown(200);
	});	
	
	
		// ----------------------------------------------
    // 所在地区_展开收缩部分
    $("#condition_box dl dd").each(function(i){
		var a=$("#condition_box dl").children('dd').eq(11).nextAll("dd");
		a.hide();
		$(".more").click(function(){
				a.show();
				$(".more").css("display","none");
				$(".hide").css("display","block");
		});
		$(".hide").click(function(){
				a.hide();
				$(".hide").css("display","none");
				$(".more").css("display","block");
		});
		
	});
})
