// 请求路径
var portal_name = ctx.substring(1, ctx.length);
//var web_service_name = "tscloud-portal";
// 整个URl字符串(在浏览器中就是完整的地址栏)
var allUrl = window.location.href;
// 取得项目前面的URL
var hostPath = allUrl.substring(0, allUrl.indexOf(portal_name));
// WebService请求地址
var ws_url = "http://" + window.location.host + ctx;// 发布使用的url

//当前登录用户
var currentUser;
// 当前主题
var currentTheme = "metro";
// 当前国际化
var currentCulture = "zh-CN";

//sunyu add for #76
var page_display = "{0}-{1} 共 {2} 条数据";
var page_empty  = "无数据";
// end
var diskMax = "";
var diskSizeMax = "";

function getDiskMax() {
	Core.AjaxRequest({
		url : ws_url + "/rest/configs/getProp/order.disk.max",
		dataType : "text",
		type : "GET",
		async : false,
		callback : function (data) {
			diskMax = data;
		} 
     });
}

function getDiskSizeMax() {
	Core.AjaxRequest({
		url : ws_url + "/rest/configs/getProp/order.disk.size.max",
		dataType : "text",
		type : "GET",
		async : false,
		callback : function (data) {
			diskSizeMax = data;
		} 
     });
}


//列表中国语言设置
var gridLocalizationObj = {
	pagergotopagestring : "当前页:",
	pagershowrowsstring : "每页显示:",
	pagerrangestring : " 共 ",
	pagernextbuttonstring : "下一页",
	pagerpreviousbuttonstring : "上一页",
	sortascendingstring : "正序",
	sortdescendingstring : "倒序",
	sortremovestring : "清除排序",
	firstDay : 1,
	percentsymbol : "%",
	currencysymbol : "￥",
	currencysymbolposition : "before",
	decimalseparator : ".",
	thousandsseparator : ",",
	emptydatastring:"暂没有数据",
	days : {
	    // full day names
		names: ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"],
	    // abbreviated day names
		namesAbbr: ["周日","周一","周二","周三","周四","周五","周六"],
	    // shortest day names
		namesShort: ["周日","周一","周二","周三","周四","周五","周六"]
	},
	months : {
	    // full month names (13 months for lunar calendards -- 13th month should be "" if not lunar)
		names: ["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月",""],
	    // abbreviated month names
		namesAbbr: ["1","2","3","4","5","6","7","8","9","10","11","12",""]
	}
};

function goPlatformURL() {
	window.open("http://" + window.location.host + ctx + "/pages/console/approve/approve-index-platform.jsp");
};

// 权限
var roleCatlog = [];
var roleFunction = {};

var roleCatlogAdmin = [];
var roleFunctionAdmin = {};

//查询用户并存入全局变量
setCurrentUser();

/** 加载页面判断user是否登陆 */
function setCurrentUser(user) {
	if (typeof user != "undefined") {
		currentUser = user;
	} else {
		Core.AjaxRequest({
			url : ws_url + "/rest/user/current",
			type : "GET",
			async : false,
			// sunyu for #115
			showTimeout: false,
			// end
			callback : function(data) {
				var user = data.user;
				if (typeof user != "undefined" && null != user) {
					currentUser = user;
					
				}
			}
		});
	}
}

/** 获取全局用户信息变量 */
function getCurrentUser() {
	return currentUser;
}

/**
 * 跳转至登录页面
 * 
 * @param gopath
 *            去往地址,null使用当前页面.路径例子'/pages/console/console.jsp'
 * @param param
 *            登陆成功回传参数,非必填.
 */
function goLoginPage(gopath, backpath, param) {
	
	gopath = ((gopath == null ||gopath == "" || gopath== 'undefined')?"":gopath).replace(/<[\/]*script>/g, "");
	backpath = ((backpath == null ||backpath == "" || backpath== 'undefined')?"":backpath).replace(/<[\/]*script>/g, "");
	param = ((param == null ||param == "" || param== 'undefined')?"":param).replace(/<[\/]*script>/g, "");
	
	
	// 获取去往路径
	var backPath = typeof backpath == "undefined" || null == backpath ? window.location.pathname
			: ctx + backpath;
	var goPath = typeof gopath == "undefined" || null == gopath ? window.location.pathname
			: ctx + gopath;
	
	
	
	// 判断当前用户是否已经登陆
	if (typeof currentUser != "undefined" && null != currentUser) {
		window.location.href = goPath;
	} else {
		var params = {};
		if (typeof param1 == "undefined") {
			params = {
				path : goPath,
				backPath : backPath
			};
		} else {
			params = {
				path : goPath,
				backPath : backPath,
				param : JSON.stringify(param)
			};
		}
		var str = encodeURIComponent(JSON.stringify(params).replace(/<[\/]*script>/g, ""));
		window.location.href = ctx + "/pages/login.jsp?params=" + str; 
	}
}

/**
 * 跳转至登录页面
 * 
 * @param path
 *            返回地址,null返回当前页面.路径例子'/pages/console/console.jsp'
 * @param param
 *            登陆成功回传参数,非必填.
 */

function interceptionString(str, length) {
	if (typeof (str) == "string" || typeof (length) == "number") {
		var retstr = "";
		if (str.length > length) {
			retstr = str.substring(0, length) + "...";
		} else {
			retstr = str;
		}
		return retstr;
	} else {
		return "";
	}
}

/**
 * 动态引入JS文件
 * 
 * @param url
 */
function addJS(url) {
	var script = document.createElement("script");
	script.setAttribute("async", "true");
	script.setAttribute("src", url);
	document.body.appendChild(script);
}

/**
 * 去掉HTML注释
 * 
 * @param e
 */
function unComment(e) {
	var t = e;
	for ( var n = 0, r = t.length; n < r; n++) {
		var i = document.getElementById(t[n]);
		for ( var s = 0, o = i.childNodes.length; s < o; s++) {
			var u = i.childNodes[s];
			if (u.nodeType == 3) {
				if (u.nodeType == document.COMMENT_NODE) {
					i.innerHTML = u.nodeValue;
					break
				}
			} else
				i.innerHTML = u.nodeValue
		}
	}
}