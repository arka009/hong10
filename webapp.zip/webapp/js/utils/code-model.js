/**
 * 获取数据字典的方法
 */
var codeModel = function(options){
    
    // 获取数据字典表方法
    this.getCommonCode =function(codeName){
    	Core.AjaxRequest({
			url :ws_url + "/rest/system/"+codeName, 
			type:"get",
			async:false,
			callback : function (data) {
				console.log(data);
				return data;
	        } 
	     });
    };
    // 自定义数据字典方法
    this.getCustomCode =function(id,url,fieldText,valueText,nullItem,methodType,params){
    	Core.AjaxRequest({
			url :ws_url +"/rest"+ url, 
			type:methodType = null ? "get":methodType,
			params:params = null ? "":params,
			async:false,
			callback : function (data) {
				var source ={
		             datatype: "json",
		             datafields: [
		                 { name: fieldText },
		                 { name: valueText }
		             ],
		             localdata:data
		         };
				 var dataAdapter = new $.jqx.dataAdapter(source);
				 $("#"+id+"").jqxDropDownList({
					   placeHolder: "请选择...",
	                   selectedIndex: obj.selectedIndex, 
	                   source: dataAdapter,
	                   displayMember: fieldText, 
	                   valueMember: valueText,
	                   width: obj.width,
	                   height: obj.height,
	                   autoDropDownHeight :obj.autoDropDownHeight,
	                   dropDownWidth :obj.dropDownWidth,
	                   dropDownHeight :obj.dropDownHeight,
	                   disabled:obj.disabled,
	                   theme:"metro"
	             });
				// 判断是否显示空白行
				 if(typeof(nullItem) == "boolean"&& nullItem ){
					 $("#"+id+"").jqxDropDownList('insertAt', { label:"全部" ,value:""},0);
				 }
	        } 
	     });
    };
    
    // 自定义数据字典方法
    this.getCustomCode1 =function(id,url,fieldText,valueText,nullItem,methodType,params,selected){
    	Core.AjaxRequest({
			url :ws_url +"/rest"+ url, 
			type:methodType = null ? "get":methodType,
			params:params = null ? "":params,
			async:false,
			callback : function (data) {
				var source ={
		             datatype: "json",
		             datafields: [
		                 { name: fieldText },
		                 { name: valueText }
		             ],
		             localdata:data
		         };
				
				var settings ={
						message: "没有可以选择的资源，请检查后再试",
				};
				
				if (data.length < 1) {
					Core.alert(settings);
					obj.isEmpty = true;	
					return;
				}
				else {
					obj.isEmpty = false;
				}
				
				var i = 0;
				$.each(data, function (i, row) {
					if (row.resSetType == selected) {
						obj.selectedIndex = i;
						return false;
					}	
				});
				
				
				 var dataAdapter = new $.jqx.dataAdapter(source);
				 $("#"+id+"").jqxDropDownList({
					   placeHolder: "请选择...",
	                   selectedIndex: obj.selectedIndex, 
	                   source: dataAdapter,
	                   displayMember: fieldText, 
	                   valueMember: valueText,
	                   width: obj.width,
	                   height: obj.height,
	                   autoDropDownHeight :obj.autoDropDownHeight,
	                   dropDownWidth :obj.dropDownWidth,
	                   dropDownHeight :obj.dropDownHeight,
	                   disabled:obj.disabled,
	                   theme:"metro"
	             });
				// 判断是否显示空白行
				 if(typeof(nullItem) == "boolean"&& nullItem ){
					 $("#"+id+"").jqxDropDownList('insertAt', { label:"全部" ,value:""},0);
				 }
	        } 
	     });
    };
    
    // 条件查询数据字典表
    this.getCommonCodeByConditions =function(id,nullItem,params){
    	Core.AjaxRequest({
			url :ws_url + "/rest/system/getCodeByParams", 
			type:"post",
			params:params,
			async:false,
			callback : function (data) {
				var source =
		         {
		             datatype: "json",
		             datafields: [
		                 { name: 'codeValue' },
		                 { name: 'codeDisplay' }
		             ],
		             localdata:data
		         };
				 var dataAdapter = new $.jqx.dataAdapter(source);
				 
				 $("#"+id+"").jqxDropDownList({
					   placeHolder:"全部",
	                   selectedIndex: obj.selectedIndex, 
	                   source: dataAdapter,
	                   displayMember: obj.displayMember, 
	                   valueMember: obj.valueMember,
	                   width: obj.width,
	                   height: obj.height,
	                   autoDropDownHeight : obj.autoDropDownHeight,
	                   theme:"metro"
	             });
				 // 判断是否显示空白行
				 if(typeof(nullItem) == "boolean"&& nullItem ){
					 $("#"+id+"").jqxDropDownList('insertAt', { label:"全部" ,value:""},0);
				 }
	        } 
	     });
    };
    
    
    // 获取数据字典表Attribute1的值
    this.getAttribute1CommonCode =function(id,codeName,nullItem){
    	Core.AjaxRequest({
			url :ws_url + "/rest/system/"+codeName, 
			type:"get",
			callback : function (data) {
				var source =
		         {
		             datatype: "json",
		             datafields: [
		                 { name: 'attribute1' },
		                 { name: 'codeDisplay' }
		             ],
		             localdata:data
		         };
				 var dataAdapter = new $.jqx.dataAdapter(source);
				 
				 $("#"+id+"").jqxDropDownList({
					   placeHolder:"全部",
	                   selectedIndex: obj.selectedIndex, 
	                   source: dataAdapter,
	                   displayMember: obj.displayMember, 
	                   valueMember: "attribute1",
	                   width: obj.width,
	                   height: obj.height,
	                   autoDropDownHeight : obj.autoDropDownHeight,
	                   theme:"metro"
	             });
				 // 判断是否显示空白行
				 if(typeof(nullItem) == "boolean"&& nullItem ){
					 $("#"+id+"").jqxDropDownList('insertAt', { label:"全部" ,value:""},0);
				 }
	        } 
	     });
    };
    
};
