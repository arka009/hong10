
/**
 * 将form表单转换成json字符串
 */
(function($){  
    $.fn.serializeJson=function(){  
        var str = '{';
        var id = this.attr("id");
        
        var length = $("#"+id+" [data-name]").length;
        var array = $("#"+id+" [data-name]");
        
    	for(var i=0;i<length;i++){
    		var name = array.eq(i).attr("data-name");
    		var id = array.eq(i).attr("id");
    		if(i == (length-1)){
    			str+='"'+ name +'"' + ':' + '"'+ $("#"+id+"").val() +'"' + "}";
    		}else{
        		str+='"'+ name +'"' + ":" + '"'+ $("#"+id+"").val() +'"' + ",";
    		}
    	}
        return str;  
    };  
})(jQuery);


/**
 * window弹出位置共通
 */
(function($){  
    $.fn.openJqxWindow=function(position){  
        var id = this.attr("id");
        var win = window;
        while (win != win.parent) {
            win = win.parent;
        }
        var windowW = $(win).width(); 
	  	var windowH = $(win).height(); 
	  	
	  	var objWidth = $("#"+id+"").width();
	  	var objHeight = $("#"+id+"").height();
	  	if("center" == position){
	  		$("#"+id+"").jqxWindow({ position: { x: (windowW-objWidth)/2, y: (windowH-objHeight)/2 } });
		  	$("#"+id+"").jqxWindow('open');
	  	}else if("top" == position){
	  		$("#"+id+"").jqxWindow({ position: { x: (windowW-objWidth)/2, y: 0 } });
		  	$("#"+id+"").jqxWindow('open');
	  	}else if("bottom" == position){
	  		$("#"+id+"").jqxWindow({ position: { x: (windowW-objWidth)/2, y: (windowH-objHeight-3) } });
		  	$("#"+id+"").jqxWindow('open');
	  	}

    };  
})(jQuery);