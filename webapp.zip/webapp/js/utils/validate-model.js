/**
 * 验证正则表达式或方法
 */ 
var Validator = {};

// 只能输入英文或者数字
Validator.IsEnOrNum = function(val) {
    if(/[\u4E00-\u9FA5]/g.test(val)){
           return false;
     }else{
           return true;
     }
};

// 只能输入数字，包括整数、小数
Validator.IsNum = function(val) {
    if(/^(\-?\d+)(\.\d+)?$/g.exec(val)) {
         return true;
    }else {
         return false;
    }
};
 
// 是否符合对应的整数位数和小数位数的数字,只能为正数
// input ： 被验证数据
// maxLengthOfInt ： 整数的最大位数
// maxLengthOfDec : 小数的最大位数
Validator.isPositiveNumWithDecimal = function(val, maxLengthOfInt, maxLengthOfDec) {
     var pattern = new RegExp('^(\\d{1,'+maxLengthOfInt+'})(\\.\\d{1,' +maxLengthOfDec+'})?$' , 'g' );
     if(pattern.exec(val)){
          return true;
     }else{
          return false;
     }
};

// 是否是正整数
Validator.IsPositiveInteger = function(val) {
   var patrn = /^[0-9]*[1-9][0-9]*$/;
   if(patrn.exec(val)){
       return true;
   }else{
       return false;
   }
};

// 0到100的正浮点数，小数部分最多保留两位
Validator.IsFloat = function(val) {
     var patrn = /^([1-9]\d?(\.\d{1,2})?|0\.\d{1,2}|100|100.0|100.00)$/ ;
     if(patrn.exec(val)){
        return true;
     }else{
        return false;
     }
 };
 
// 是否是电话号码
 Validator.IsMobile = function(val) {
	 var patrn = /^0?(13[0-9]|15[012356789]|18[0-9]|14[57])[0-9]{8}$/ ;
	 if(patrn.exec(val)){
	        return true;
	 }else{
	        return false;
	 }
 };
 
// 是否相等
 Validator.IsEquals = function(val1, val2) {
	  if(val1 == val2){
	        return true;
	  }else{
	        return false;
	  }
 };
 
// 是否超过最大长度
 Validator.isBeyondLeng = function(val,maxLen){
       var len = 0;
       for (var i = 0; i < val.length; i++) {
        var c = val.charCodeAt(i);
        //单字节加1
        if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
              len++;
        }else {
              len += 2;
        }
        }
   if(len<=maxLen){
        return true;
   }else{
        return false;
   }
};

// 是否是MAC地址
Validator.IsMac = function(val) {
   var patrn = /[0-9A-Fa-f]{2}-[0-9A-Fa-f]{2}-[0-9A-Fa-f]{2}-[0-9A-Fa-f]{2}-[0-9A-Fa-f]{2}-[0-9A-Fa-f]{2}/ ;
   if(patrn.exec(val)){
       return true;
   }else{
       return false;
   }
 };
 
// 是否是IP地址
Validator.IsIpAddress = function(val, commit) {
    var pattern=/^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$/ ;
    if(!pattern.test(val)){
        return false;
    } else{
        return true;
    }
};






 






