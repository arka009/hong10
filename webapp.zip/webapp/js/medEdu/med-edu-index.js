
getHosName('d8ebed43-77a4-11e5-b58a-00ff11c9bcf0');
getValidLearnNum('d8ebed43-77a4-11e5-b58a-00ff11c9bcf0');
getNotApproveReusmeNum('d8ebed43-77a4-11e5-b58a-00ff11c9bcf0');
getDeptPassResumeNum('d8ebed43-77a4-11e5-b58a-00ff11c9bcf0');
//查询医院名称
function getHosName(hosEduSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectHosByMedEdu/"+hosEduSid, 
		type:"GET",
		callback : function (data) {
			console.log(data);
			$("#hosNameEdu").html(data.hospitalName);
		}
	});
}

//查询有效进修数量
function getValidLearnNum(hosEduSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selectBachByParamsInMedEdu", 
		type:"POST",
		params:{
			medicalEduPartSid:hosEduSid,
			positionStatus:'01'
		},
		callback : function (data) {
			console.log(data);
			if(data.length>0){
				$("#validLearnNum").html(data.length);
			}else{
				$("#validLearnNum").html(0);
			}
		}
	});
}

//查询待处理进修申请
function getNotApproveReusmeNum(hosEduSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/selectResumeByParams", 
		type:"POST",
		params:{
			medicalEduPartSid:hosEduSid,
			status:'01'
		},
		callback : function (data) {
			console.log(data);
			if(data.length>0){
				$("#notApproveReusmeNum").html(data.length);
			}else{
				$("#notApproveReusmeNum").html(0);
			}
		}
	});
}

//查询科室通过进修申请
function getDeptPassResumeNum(hosEduSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/selectResumeByParams", 
		type:"POST",
		params:{
			medicalEduPartSid:hosEduSid,
			status:'03'
		},
		callback : function (data) {
			console.log(data);
			if(data.length>0){
				$("#deptPassNum").html(data.length);
			}else{
				$("#deptPassNum").html(0);
			}
		}
	});
}