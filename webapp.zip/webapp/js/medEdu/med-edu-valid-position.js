var medEduPartSid='d8ebed43-77a4-11e5-b58a-00ff11c9bcf0';
//查询条件
var selectParams=function(){
	var selectBatch=$("#selectBatch").val();
	if('0'!=selectBatch&&selectBatch!=null&&selectBatch!=""){
		this.learnBeginDateYear=selectBatch.split("-")[0];
		this.learnBeginDateMonth=selectBatch.split("-")[1];
	}
	var specType= $("#specType").val();
	if("00"!=specType){
		this.specType=specType;
	}
	if($("#deptBySpec").val()!='0'){
		this.deptSid=$("#deptBySpec").val();
	}else{
		this.deptSid=null;
	}
	if($("#search").val()!=null&&$("#search").val()!=""){
		this.positionName=$("#search").val();
	}
	this.sortFileter=$("#sortFilter").val();
	this.isDesc=function(){
		if($("#ascOrDesc").prop("checked")) {
			return '02';
		} else{
			return '01';
		}
	};
	this.medicalEduPartSid=medEduPartSid;
	this.positionStatus='01';
};

// 条件查询简历
function selectResumeByParams(){
	var param=new selectParams();
	param.ascOrDesc=param.isDesc();
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selectBachByParamsInMedEdu", 
		type:"POST",
		params:param,
		callback : function (data) {
			console.log(data);
			$("#num").html(data.length);
			$("#resumeGrid li").remove();
			var j=0;
			if(data!=null&&data.length>0){
			for(var i=0;i<data.length;i++){
				var editMethord="getPositionBySid('"+data[i].positionSid+"')";
				var isRetestStr='';
				if('01'==data[i].isRetest){
					isRetestStr='有';
				}else{
					isRetestStr='无';
				}
				//填充按专科查询进修
				var li="<li>" +
							"<p class='y_c_title' style='height:50px'>" +
								"<input type='checkbox' name='item' id=''value='"+data[i].positionSid+"'>" +
								"<span class='sp_cfirst'> "+data[i].learnBeginDateYear+"年"+data[i].learnBeginDateMonth+"月</span>" +
								"<span class='yellowAlertInfoPos'id='alertInfo"+i+"'></span>" +
								
							"</p>" +
							"<dl>" +
								"<dd>" +
									"<p class='first' style='margin-top:13px'>" +
										"<a href=''>"+data[i].deptName+"</a> " + 
										"<span class='value'>临床专科</span>" +
									"</p>" +
									"<p style='width:300px; margin-top:10px'>" +
										"<span class='key'>招收人数：</span><span class='value' style='display:inline-block;width:142px'><span>"+data[i].recruitPeopleNum+"</span>人</span>" +
										"<span class='key'>复试：</span><span class='value'><span style='display:inline-block;'>"+isRetestStr+"</span></span>" +
									"</p>" +
									"<p style='width:500px;margin-top:10px'>" +
										"<span class='value' style='color:#1395d8'>已有 <span class='notApproveNum' style='background-color:#1395d8'>"+data[i].passPeopleNum+"</span> 人通过</span>" +
										"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +
										"<span class='value' style='color:#e1685c'>已有 <span class='notApproveNum'>"+data[i].applyPoepleNum+"</span> 人申请</span>" +
										"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +
										"<span class='value' style='color:#f39800'>目前 <span class='notApproveNum' style='background-color:#f39800'>"+data[i].userNotConfirmNum+"</span> 人待确认</span>" +
									"</p>" +
								"</dd>" +
							"</dl>" +
							"<p class='y_c_control y_m_control'>" +
							"<i class='greyProgressBar'>"+
							"<i class='buleProgressBar' id='processBar"+i+"'></i>"+
							"</i>"+
							"<i class='bulePecent' id='pecent"+i+"'>30%</i>"+
//								"<a href='"+ctx+"/pages/medEdu/med-edu-edit-position.jsp?posSid="+data[i].positionSid+"' class='edit'>编辑</a>" +
								"<a href='' class='offline' onClick='downPos(this)'>下线</a>" +
								"<a href='' class='del big_del' onClick='delPos(this)'>删除</a>" +
							"</p>" +
						"</li>";
				$("#resumeGrid").append(li);
				var pecent=data[i].passPeopleNum/data[i].recruitPeopleNum;
//				var pecent=(12/data[i].recruitPeopleNum).toFixed(2);
				if(pecent<0.9){
					$("#processBar"+i).attr("class","buleProgressBar");
					$("#pecent"+i).attr("class","bulePecent");
					$("#processBar"+i).css("width",""+101*pecent+"px");
					$("#pecent"+i).css("width",""+(101*pecent+12)+"px");
					$("#pecent"+i).html(pecent*100+"%");
				}else if(pecent>=0.9&&pecent<1){
					$("#processBar"+i).attr("class","yellowProgressBar");
					$("#pecent"+i).attr("class","yellowPecent");
					$("#processBar"+i).css("width",""+101*pecent+"px");
					$("#pecent"+i).css("width",""+(101*pecent+12)+"px");
					$("#pecent"+i).html(pecent*100+"%");
					$("#alertInfo"+i).attr("class","yellowAlertInfoPos");
					$("#alertInfo"+i).html("[ 该进修通过人数即将满员 ]");
				}else if(pecent>=1){
					$("#processBar"+i).attr("class","redProgressBar");
					$("#pecent"+i).attr("class","redPecent");
					$("#processBar"+i).css("width","101px");
					$("#pecent"+i).css("width","101px");
					$("#pecent"+i).html(pecent*100+"%");
					$("#alertInfo"+i).attr("class","redAlertInfoPos");
					$("#alertInfo"+i).html("[ 该进修通过人数已满员，是否下线该进修？下线不影响已报名的申请 ]");
				}
			}
			mCheck();
			//分页
			getPage('.fenye','resumeGrid',4);
			}else{
				var li="<li style='height:40px;text-align:center;padding-top:20px;'>" +
						"<div>" +
						"<i class='nodata'></i>" +
						"</div>" +
						"</li>";
					$("#resumeGrid").append(li);
			}
      } 
   });
}
//TODO 根据医教科SID查询统计去重后的批次
function selectStatisticsBatchByMedEduSid(){
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selectStatisticsBatchByMedEduSid/"+medEduPartSid, 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				var option="<option value='0'  class='label'>全部</option>";
				$("#selectBatch").append(option);
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].batchCode+"'>"+data[i].batchValue+"</option>";
						$("#selectBatch").append(option);
//						selectSpec(data[i].codeValue);
					}else{
						var option="<option value='"+data[i].batchCode+"'>"+data[i].batchValue+"</option>";
						$("#selectBatch").append(option);
					}
				}
//				$("#specType option:first").prop("selected", 'selected');
//				$("#specType option[value='01']").attr("selected", "selected");
			}
		} 
	})
}
//查询专科分类
function selectSpecType(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/SPEC_TYPE", 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#specType").append(option);
						selectSpec(data[i].codeValue); 	
					}else{
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#specType").append(option);
					}
				}
//				$("#specType option:first").prop("selected", 'selected');
//				$("#specType option[value='01']").attr("selected", "selected");
			}
        } 
	})
}

//查询所有医院下所有科室
function selectSpec(specType){
	console.log(specType);
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectDeptBySpec", 
		type:"POST",
		params:{
			specType:specType,
		},
		callback : function (data) {
			console.log(data);
			var alloption="<option value='0'  class='label'>全部</option>";
			$("#deptBySpec").append(alloption);
			for(var i=0;i<data.length;i++){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].deptSid+"'>"+data[i].deptName+"</option>";
						$("#deptBySpec").append(option);
					}else{
						var option="<option value='"+data[i].deptSid+"'>"+data[i].deptName+"</option>";
						$("#deptBySpec").append(option);
					}
				}
			}
			$( "#deptBySpec" ).easyDropDown({
				wrapperClass: 'dropdown',
				cutOff:12
				
			});
			
      } 
   });
}

//下线
function downPos(obj){
	var checkboxObj=$(obj).parent().prevAll().eq(1).find("input");
	var resDeptSid=$(checkboxObj).val();
	var resDeptSidArray=new Array();
	resDeptSidArray.push(resDeptSid);
	Core.AjaxRequest({
		url :ws_url + "/rest/position/operatePosition", 
		type:"POST",
		params:{
			positionSids:resDeptSidArray,
			positionStatus:"02"
		},
		callback : function (data) {
			
      } 
   });
}

//批量下线
function downPoses(){
	var checkBoxChecked=$("input[name='item']:checked");
	var resDeptSidArray=new Array(); 
	if(checkBoxChecked.length>0){
		for(var i=0;i<checkBoxChecked.length;i++){
			console.log($(checkBoxChecked[i]).val());
			resDeptSidArray.push($(checkBoxChecked[i]).val());
		}
		Core.AjaxRequest({
			url :ws_url + "/rest/position/operatePosition", 
			type:"POST",
			params:{
				positionSids:resDeptSidArray,
				positionStatus:"02"
			},
			callback : function (data) {
				
			} 
	   });
		
	}else{
		alert("请选择数据后再发送");
	}
}

//删除
function delPos(obj){
	var checkboxObj=$(obj).parent().prevAll().eq(1).children().eq(0);
	var resDeptSid=$(checkboxObj).val();
	var resDeptSidArray=new Array();
	resDeptSidArray.push(resDeptSid);
	Core.AjaxRequest({
		url :ws_url + "/rest/position/operatePosition", 
		type:"POST",
		params:{
			positionSids:resDeptSidArray,
			positionStatus:"03"
		},
		callback : function (data) {
			
      } 
   });
}

//批量删除
function delPoses(){
	var checkBoxChecked=$("input[name='item']:checked");
	var resDeptSidArray=new Array(); 
	if(checkBoxChecked.length>0){
		for(var i=0;i<checkBoxChecked.length;i++){
			console.log($(checkBoxChecked[i]).val());
			resDeptSidArray.push($(checkBoxChecked[i]).val());
		}
		Core.AjaxRequest({
			url :ws_url + "/rest/position/operatePosition", 
			type:"POST",
			params:{
				positionSids:resDeptSidArray,
				positionStatus:"03"
			},
			callback : function (data) {
				
			} 
	   });
		
	}else{
		alert("请选择数据后再发送");
	}
}