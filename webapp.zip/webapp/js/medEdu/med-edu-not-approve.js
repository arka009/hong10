//var medEduPartSid='d8ebed43-77a4-11e5-b58a-00ff11c9bcf0';
//查询条件
var selectParams=function(){
	var selectBatch=$("#selectBatch").val();
	if('0'!=selectBatch&&selectBatch!=null&&selectBatch!=""){
		this.learnBeginDateYear=selectBatch.split("-")[0];
		this.learnBeginDateMonth=selectBatch.split("-")[1];
	}
	var specType= $("#specType").val();
	if('0'!=specType&&specType!=null&&specType!=""){
		this.specType=specType;
	}
	if($("#deptBySpec").val()!='0'){
		this.deptSid=$("#deptBySpec").val();
	}else{
		this.deptSid=null;
	}
	if($("#search").val()!=null&&$("#search").val()!=""){
		this.realName=$("#search").val();
	}
	this.sortFileter=$("#sortFilter").val();
	this.isDesc=function(){
		if($("#ascOrDesc").prop("checked")) {
			return '02';
		} else{
			return '01';
		}
	};
	this.medicalEduPartSid=medEduPartSid;
	this.status='01';
};
// 条件查询简历
function selectResumeByParams(){
	console.log($("#search").val());
	var param=new selectParams();
	param.ascOrDesc=param.isDesc();
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/selectResumeByParams", 
		type:"POST",
		params:param,
		callback : function (data) {
			console.log(data);
			$("#num").html(data.length);
			$("#resumeGrid li").remove();
			if(data!=null&&data.length>0){
			var j=0;
			for(var i=0;i<data.length;i++){
				//填充按专科查询进修
				var resDeptSidDb='"'+data[i].resDeptSid+'"';
				var viewResume="viewResume(this,"+data[i].userSid+","+resDeptSidDb+")";
				var li="<li>" +
							"<div class='top_dv clearfix'>"+
							"<p class='y_c_title '>" +
								"<input type='checkbox' name='item' id='' value='"+data[i].resDeptSid+"'>" +
								"<span class='sp_cfirst'>申请：</span>" +
								"<span>"+data[i].applyDept+"</span>" +
								"<span>（"+data[i].learnBeginDateYear+"年"+data[i].learnBeginDateMonth+"月）</span>" +
								
							"</p>" +
							"<p class='y_c_fr fr'>" +
								"<span class='s_h'>"+data[i].resDeliveryTime+"</span>&nbsp;&nbsp;&nbsp;"+
								"<span class='s_h read_not' id='readStatus"+i+"'>已读</span>"+
							"</p>"+
							"</div>"+
							"<dl style='width:582px'>" +
								"<dt>" +
								"<a href='javascript:;' onClick='"+viewResume+"'><img style='width:120px;height:145px'src='"+ctx+"/"+data[i].faceImage+"' alt=''></a>" +
								"</dt>" +
								"<dd>" +
									"<p class='first'  style='width:280px'>" +
										"<a href='javascript:;' onClick='"+viewResume+"'>"+data[i].realName+"</a>&nbsp;" +
										
									"</p>" +
									"<p>" +
										"<span class='value'>"+data[i].belongDept+" / "+data[i].workMajorLength+"年 / "+data[i].workTitleName+"</span> " +
									"</p>" +
									"<p>" +
										"<span class='key'>毕业院校："+data[i].graduateSchool+"       "+data[i].highestDegreeName+"" +
									"</p>" +
									"<p>"+
									"<span class='key'>就职：</span>" +
									"<span class='value'>"+data[i].belongHosName+"&nbsp;"+data[i].hosLevelName+"</span>" +
									"</p>"+
								"</dd>" +
							"</dl>" +
							"<p class='y_c_control'>" +
								"<a href='javaScript:;'  id='viewReusmeButton"+i+"' onClick='"+viewResume+"' class='viewprofile'>查看简历</a>" +
								"<a href='' class='send_ks' onClick='sendReusmeToDept(this)'>发送给科室</a>" +
								"<a href='' class='big_del refuse' onClick='refuseResume(this)'>拒绝</a>" +
							"</p>" +
						"</li>";
				$("#resumeGrid").append(li);
				if("01"==data[i].isView||"03"==data[i].isView){
					$("#readStatus"+i).html("已读");
					$("#readStatus"+i).attr("class","s_h read");
				}else{
					$("#readStatus"+i).html("未读");
					$("#readStatus"+i).attr("class","s_h read_not");
				}
				
			}
			$(".flagstar").hover(function(){
				
				
				//$(this).children("strong").show();
				
				var flag=true;
				$(this).bind("click",function(){
					if(flag){
						$(this).removeClass("flag_not").addClass("flag").html("已标记");
						
						flag=false;
							
					}else{
						$(this).removeClass("flag").addClass("flag_not").html("未标记");
						flag=true;
					}
					
					
					
				});
				
				
			},function(){
				$(this).children("strong").hide();
			});
				
			mCheck();
			
			//分页
			getPage('.fenye','resumeGrid',4);
			}else{
				var li="<li style='text-align:center;padding-top:20px;'>" +
				"<div style='background-color: #FFF;width:692px;height:145px;margin-top:30px;'>" +
				"<div class='nodata'><span style='position:relative;top:90px;color:#7e7d7d'>无数据</span></div>" +
				"</div>" +
				"</li>";
				$("#resumeGrid").append(li);
		}
      } 
   });
	
}



//查看简历
var userSidRes=null;
var resDeptSidView=null;
function viewResume(obj,userSid,resDeptSid){
	userSidRes=userSid;
	resDeptSidView=resDeptSid;
	changeIsView("01",resDeptSidView);
	var data={"isMedFlag":"01"};
	
	alert_box(ctx+'/pages/resume/resume-view.jsp #viewReusmeDiv',data);
	
	
}

//查询专科分类
function selectSpecType(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/SPEC_TYPE", 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#specType").append(option);
						selectSpec(data[i].codeValue);
					}else{
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#specType").append(option);
					}
				}
//				$("#specType option:first").prop("selected", 'selected');
//				$("#specType option[value='01']").attr("selected", "selected");
			}
        } 
	})
}
//TODO 根据医教科SID查询统计去重后的批次
function selectStatisticsBatchByMedEduSid(){
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selectStatisticsBatchByMedEduSid/"+medEduPartSid, 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				var option="<option value='0'>全部</option>";
				$("#selectBatch").append(option);
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].batchCode+"'>"+data[i].batchValue+"</option>";
						$("#selectBatch").append(option);
//						selectSpec(data[i].codeValue);
					}else{
						var option="<option value='"+data[i].batchCode+"'>"+data[i].batchValue+"</option>";
						$("#selectBatch").append(option);
					}
				}
//				$("#specType option:first").prop("selected", 'selected');
//				$("#specType option[value='01']").attr("selected", "selected");
			}
		} 
	})
}

//查询所有医院下所有科室
function selectSpec(specType){
	console.log(specType);
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectDeptBySpec", 
		type:"POST",
		params:{
			specType:specType,
		},
		callback : function (data) {
			console.log(data);
			var alloption="<option value='0' >全部</option>";
			$("#deptBySpec").append(alloption);
			var items=new Array();
			items.push(alloption);
			for(var i=0;i<data.length;i++){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].deptSid+"'>"+data[i].deptName+"</option>";
						$("#deptBySpec").append(option);
						items.push(option);
					}else{
						var option="<option value='"+data[i].deptSid+"'>"+data[i].deptName+"</option>";
						$("#deptBySpec").append(option);
						items.push(option);
					}
				}
				
				$( "#deptBySpec" ).easyDropDown({
					wrapperClass: 'dropdown',
					cutOff:12
					
				});
			}
			
//			 $( "#specType" ).selectmenu("refresh");
      } 
   });
}

//发送单一简历到科室
function sendReusmeToDept(obj){
	var checkboxObj=$(obj).parent().prevAll().eq(1).find("input");
	var resDeptSid=$(checkboxObj).val();
	var resDeptSidArray=new Array();
	resDeptSidArray.push(resDeptSid);
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/deliveryResumeToDept", 
		type:"POST",
		params:{
			resumeDeptSid:resDeptSidArray,
		},
		callback : function (data) {
			
      } 
   });
}

//批量发送简历到科室
function sendReusmesToDept(){
	var checkBoxChecked=$("input[name='item']:checked");
	var resDeptSidArray=new Array(); 
	if(checkBoxChecked.length>0){
		for(var i=0;i<checkBoxChecked.length;i++){
			console.log($(checkBoxChecked[i]).val());
			resDeptSidArray.push($(checkBoxChecked[i]).val());
		}
		Core.AjaxRequest({
			url :ws_url + "/rest/resume/deliveryResumeToDept", 
			type:"POST",
			params:{
				resumeDeptSid:resDeptSidArray,
			},
			callback : function (data) {
				
			} 
	   });
		
	}else{
		alert("请选择数据后再发送");
	}
}

//医教科拒绝
function refuseResume(obj){
	var checkboxObj=$(obj).parent().prevAll().eq(1).find("input");
	var resDeptSid=$(checkboxObj).val();
	var resDeptSidArray=new Array();
	resDeptSidArray.push(resDeptSid);
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/oprateResume", 
		type:"POST",
		params:{
			resumeDeptSids:resDeptSidArray,
			status:"05"
		},
		callback : function (data) {
			
      } 
   });
}
//批量拒绝简历
function refuseReusmes(){
	var checkBoxChecked=$("input[name='item']:checked");
	var resDeptSidArray=new Array(); 
	if(checkBoxChecked.length>0){
		for(var i=0;i<checkBoxChecked.length;i++){
			console.log($(checkBoxChecked[i]).val());
			resDeptSidArray.push($(checkBoxChecked[i]).val());
		}
		Core.AjaxRequest({
			url :ws_url + "/rest/resume/oprateResume", 
			type:"POST",
			params:{
				resumeDeptSids:resDeptSidArray,
				status:"05"
			},
			callback : function (data) {
				
			} 
	   });
		
	}else{
		alert("请选择数据后再发送");
	}
}

//批量删除简历
function delReusmes(){
	var checkBoxChecked=$("input[name='item']:checked");
	var resDeptSidArray=new Array(); 
	if(checkBoxChecked.length>0){
		for(var i=0;i<checkBoxChecked.length;i++){
			console.log($(checkBoxChecked[i]).val());
			resDeptSidArray.push($(checkBoxChecked[i]).val());
		}
		Core.AjaxRequest({
			url :ws_url + "/rest/resume/oprateResume", 
			type:"POST",
			params:{
				resumeDeptSids:resDeptSidArray,
				status:"09"
			},
			callback : function (data) {
				
			} 
	   });
		
	}else{
		alert("请选择数据后再发送");
	}
}
//标记学员
function changeIsView(flag,resDeptSidView){
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/changeIsView/"+flag+"/"+resDeptSidView, 
		type:"get",
		async:false,
		callback : function (data) {
			console.log(data.isDeptFlag);
			if("01"==data.isDeptFlag){
				$("#flagStu").html("已标记");
				$("#flagStu").attr("class","flagStu");
			}else{
				$("#flagStu").html("标记星标学员");
				$("#flagStu").attr("class","noflagStu");
			}
		} 
	})
}