
//查询条件
var selectParams=function(){
	var selectBatch=$("#selectBatch").val();
	if('0'!=selectBatch&&selectBatch!=null&&selectBatch!=""){
		this.learnBeginDateYear=selectBatch.split("-")[0];
		this.learnBeginDateMonth=selectBatch.split("-")[1];
	}
	var specType= $("#specType").val();
	if('0'!=specType&&specType!=null&&specType!=""){
		this.specType=specType;
	}
	if($("#deptBySpec").val()!='0'){
		this.deptSid=$("#deptBySpec").val();
	}else{
		this.deptSid=null;
	}
	if($("#search").val()!=null&&$("#search").val()!=""){
		this.realName=$("#search").val();
	}
	this.medicalEduPartSid='d8ebed43-77a4-11e5-b58a-00ff11c9bcf0';
	this.status="'08','03','04','06','07','10'";
};

// 条件查询简历
function selectResumeByParams(){
	console.log($("#search").val());
	var param=new selectParams();
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/selectResumeByParams", 
		type:"POST",
		params:param,
		callback : function (data) {
			console.log(data);
			$("#resumeGrid li").remove();
			var j=0;
			if(data!=null&&data.length>0){
			for(var i=0;i<data.length;i++){
				//填充按专科查询进修
				var li="<li>" +
							"<p class='y_c_title'>" +
								
								"<span class='sp_cfirst'>申请：</span>" +
								"<span>"+data[i].applyDept+"</span>" +
								"<span>（"+data[i].learnBeginDateYear+"年"+data[i].learnBeginDateMonth+"月）</span>" +
							"</p>" +
							"<dl style='width:452px'>" +
								"<dt>" +
								"<a href='javascript:void(0);' onClick='viewResume(this,"+data[i].userSid+")'><img style='width:120px;height:145px'src='"+ctx+"/"+data[i].faceImage+"' alt=''></a>" +
								"</dt>" +
								"<dd>" +
									"<p class='first'  style='width:280px'>" +
										"<a href=''>"+data[i].realName+"</a>&nbsp;" +
										
									"</p>" +
									"<p>" +
										"<span class='value'>"+data[i].belongDept+" / "+data[i].workMajorLength+"年 / "+data[i].workTitleName+"</span> " +
									"</p>" +
									"<p>" +
									"<span class='key'>就职：</span>" +
									"<span class='value'>"+data[i].belongHosName+"&nbsp;"+data[i].hosLevelName+"</span>" +
									"</p>" +
									"<p>" +
									"<span class='key'>电话：</span>" +
									"<span class='value'>"+data[i].mobile+"</span>" +
									"</p>" +
								"</dd>" +
							"</dl>" +
							"<p class='y_c_control y_c_send_control' style='padding-left:130px'>" +
								"<a href='javascript:;'  id='viewReusmeButton"+i+"' onClick='viewResume(this,"+data[i].userSid+")' class='viewprofile'>查看简历</a>" +
								
								
							"</p>" +
						"</li>";
				$("#resumeGrid").append(li);
			}
			mCheck();
			//分页
			getPage('.fenye','resumeGrid',4);
			}else{
				var li="<li style='text-align:center;padding-top:20px;'>" +
				"<div style='background-color: #FFF;width:692px;height:145px;margin-top:30px;'>" +
				"<div class='nodata'><span style='position:relative;top:90px;color:#7e7d7d'>无数据</span></div>" +
				"</div>" +
				"</li>";
				$("#resumeGrid").append(li);
			}
      } 
   });
}

//查看简历
function viewResume(obj,userSid){
	popUpViewResumeBox("#"+$(obj).attr('id')+"",'#viewReusmeDiv','#closeViewResume',-450,400);
	getResumeByUserSid(userSid);
}

//查询专科分类
function selectSpecType(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/SPEC_TYPE", 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#specType").append(option);
						selectSpec(data[i].codeValue);
					}else{
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#specType").append(option);
					}
				}
//				$("#specType option:first").prop("selected", 'selected');
//				$("#specType option[value='01']").attr("selected", "selected");
			}
        } 
	})
}

//查询所有医院下所有科室
function selectSpec(specType){
	console.log(specType);
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectDeptBySpec", 
		type:"POST",
		params:{
			specType:specType,
		},
		callback : function (data) {
			console.log(data);
			var alloption="<option value='0'  class='label'>全部</option>";
			$("#deptBySpec").append(alloption);
			var items=new Array();
			items.push(alloption);
			for(var i=0;i<data.length;i++){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].deptSid+"'>"+data[i].deptName+"</option>";
						$("#deptBySpec").append(option);
						items.push(option);
					}else{
						var option="<option value='"+data[i].deptSid+"'>"+data[i].deptName+"</option>";
						$("#deptBySpec").append(option);
						items.push(option);
					}
				}
				
				$( "#deptBySpec" ).easyDropDown({
					wrapperClass: 'dropdown',
					cutOff: 10,
					
				});
			}
			
			 $( "#specType" ).selectmenu("refresh");
      } 
   });
}

//发送单一简历到科室
function sendReusmeToDept(obj){
	var checkboxObj=$(obj).parent().prevAll().eq(1).children().eq(0);
	var resDeptSid=$(checkboxObj).val();
	var resDeptSidArray=new Array();
	resDeptSidArray.push(resDeptSid);
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/deliveryResumeToDept", 
		type:"POST",
		params:{
			resumeDeptSid:resDeptSidArray,
		},
		callback : function (data) {
			
      } 
   });
}

//批量发送简历到科室
function sendReusmesToDept(){
	var checkBoxChecked=$("input[name='item']:checked");
	var resDeptSidArray=new Array(); 
	if(checkBoxChecked.length>0){
		for(var i=0;i<checkBoxChecked.length;i++){
			console.log($(checkBoxChecked[i]).val());
			resDeptSidArray.push($(checkBoxChecked[i]).val());
		}
		Core.AjaxRequest({
			url :ws_url + "/rest/resume/deliveryResumeToDept", 
			type:"POST",
			params:{
				resumeDeptSid:resDeptSidArray,
			},
			callback : function (data) {
				
			} 
	   });
		
	}else{
		alert("请选择数据后再发送");
	}
}

//医教科拒绝
function refuseResume(obj){
	var checkboxObj=$(obj).parent().prevAll().eq(1).children().eq(0);
	var resDeptSid=$(checkboxObj).val();
	var resDeptSidArray=new Array();
	resDeptSidArray.push(resDeptSid);
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/oprateResume", 
		type:"POST",
		params:{
			resumeDeptSids:resDeptSidArray,
			status:"05"
		},
		callback : function (data) {
			
      } 
   });
}
//批量拒绝简历
function refuseReusmes(){
	var checkBoxChecked=$("input[name='item']:checked");
	var resDeptSidArray=new Array(); 
	if(checkBoxChecked.length>0){
		for(var i=0;i<checkBoxChecked.length;i++){
			console.log($(checkBoxChecked[i]).val());
			resDeptSidArray.push($(checkBoxChecked[i]).val());
		}
		Core.AjaxRequest({
			url :ws_url + "/rest/resume/oprateResume", 
			type:"POST",
			params:{
				resumeDeptSids:resDeptSidArray,
				status:"05"
			},
			callback : function (data) {
				
			} 
	   });
		
	}else{
		alert("请选择数据后再发送");
	}
}

//批量删除简历
function delReusmes(){
	var checkBoxChecked=$("input[name='item']:checked");
	var resDeptSidArray=new Array(); 
	if(checkBoxChecked.length>0){
		for(var i=0;i<checkBoxChecked.length;i++){
			console.log($(checkBoxChecked[i]).val());
			resDeptSidArray.push($(checkBoxChecked[i]).val());
		}
		Core.AjaxRequest({
			url :ws_url + "/rest/resume/oprateResume", 
			type:"POST",
			params:{
				resumeDeptSids:resDeptSidArray,
				status:"09"
			},
			callback : function (data) {
				
			} 
	   });
		
	}else{
		alert("请选择数据后再发送");
	}
}