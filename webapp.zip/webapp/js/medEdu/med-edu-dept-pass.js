//var medEduPartSid='d8ebed43-77a4-11e5-b58a-00ff11c9bcf0';
//查询条件
var selectParams=function(){
	var selectBatch=$("#selectBatch").val();
	if('0'!=selectBatch&&selectBatch!=null&&selectBatch!=""){
		this.learnBeginDateYear=selectBatch.split("-")[0];
		this.learnBeginDateMonth=selectBatch.split("-")[1];
	}
	var specType= $("#specType").val();
	if('0'!=specType&&specType!=null&&specType!=""){
		this.specType=specType;
	}
	if($("#deptBySpec").val()!=''){
		this.deptSid=$("#deptBySpec").val();
	}else{
		this.deptSid=null;
	}
	if($("#search").val()!=null&&$("#search").val()!=""){
		this.realName=$("#search").val();
	}
	this.sortFileter=$("#sortFilter").val();
	this.isDesc=function(){
		if($("#ascOrDesc").prop("checked")) {
			return '02';
		} else{
			return '01';
		}
	};
	this.isDeptFlag=function(){
		if($("#deptFlag").prop("checked")) {
			return '01';
		} else{
			return '02';
		}
	};
	this.medicalEduPartSid=medEduPartSid;
	this.status='03';
};

// 条件查询简历
function selectResumeByParams(){
	var param=new selectParams();
	param.ascOrDesc=param.isDesc();
	param.isDeptFlag=param.isDeptFlag();
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/selectResumeByParams", 
		type:"POST",
		params:param,
		callback : function (data) {
			console.log(data);
			$("#num").html(data.length);
			$("#resumeGrid li").remove();
			var j=0;
			if(data!=null&&data.length>0){
				
			
			for(var i=0;i<data.length;i++){
				var resDeptSidDb='"'+data[i].resDeptSid+'"';
				var viewResume="viewResume(this,"+data[i].userSid+","+resDeptSidDb+")";
					//填充按专科查询进修
					var li="<li>" +
								"<p class='y_c_title'>" +
									"<input type='checkbox' name='item' id='' value='"+data[i].resDeptSid+"'>" +
									"<span class='sp_cfirst'>申请：</span>" +
									"<span>"+data[i].applyDept+"</span>" +
									"<span>（"+data[i].learnBeginDateYear+"年"+data[i].learnBeginDateMonth+"月）</span>" +
									/*"<i class='flag_not flagstar' id='isFlag"+i+"'>未标记<strong style='display:none;'></strong></i>"+*/
								"</p>" +
								"<dl>" +
									"<dt>" +
									"<img style='width:120px;height:145px'src='"+ctx+"/"+data[i].faceImage+"' alt=''>" +
									"</dt>" +
									"<dd>" +									
									
										"<p class='first'  style='width:280px'>" +
											"<a href='javascript:;' onClick='"+viewResume+"'>"+data[i].realName+"</a>&nbsp;" +
										
										"</p>" +
										"<p>" +
											"<span class='value'>"+data[i].belongDept+" / "+data[i].workMajorLength+"年 / "+data[i].workTitleName+"</span> " +
										"</p>" +
										"<p>" +
											"<span class='key'>毕业院校："+data[i].graduateSchool+"       "+data[i].highestDegreeName+"" +
										"</p>" +
										"<p>"+
										"<span class='key'>就职：</span>" +
										"<span class='value'>"+data[i].belongHosName+"&nbsp;"+data[i].hosLevelName+"</span>" +
										"</p>"+
//										
									"</dd>" +
								"</dl>" +
								"<p class='y_c_control y_c_m_control'>" +
//									
									"<a href='javaScript:;' id='viewReusmeButton"+i+"' onClick='"+viewResume+"' class='viewprofile'>查看简历</a>" +
									"<a class='send_ks' onClick='sendNotice(this)'>发送确认</a>" +
//									"<a href='' class='refuse' onClick='refuseResume(this)'>拒绝</a>" +
								"</p>" +
							"</li>";
					$("#resumeGrid").append(li);
					if("01"==data[i].isDeptFlag){
						$("#isFlag"+i).html("已标记");
						$("#isFlag"+i).attr("class","flag_not flagstar");
					}else{
						$("#isFlag"+i).html("未标记");
						$("#isFlag"+i).attr("class","flag flagstar");
					}
			}
			mCheck();
			//分页
			getPage('.fenye','resumeGrid',4);
			}else{
				var li="<li style='text-align:center;padding-top:20px;'>" +
				"<div style='background-color: #FFF;width:692px;height:145px;margin-top:30px;'>" +
				"<div class='nodata'><span style='position:relative;top:90px;color:#7e7d7d'>无数据</span></div>" +
				"</div>" +
				"</li>";
				$("#resumeGrid").append(li);
		}
      } 
   });
}
//TODO 根据医教科SID查询统计去重后的批次
function selectStatisticsBatchByMedEduSid(){
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selectStatisticsBatchByMedEduSid/"+medEduPartSid, 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				var option="<option value='0'>全部</option>";
				$("#selectBatch").append(option);
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].batchCode+"'>"+data[i].batchValue+"</option>";
						$("#selectBatch").append(option);
//						selectSpec(data[i].codeValue);
					}else{
						var option="<option value='"+data[i].batchCode+"'>"+data[i].batchValue+"</option>";
						$("#selectBatch").append(option);
					}
				}
//				$("#specType option:first").prop("selected", 'selected');
//				$("#specType option[value='01']").attr("selected", "selected");
			}
		} 
	})
}
//查看简历
var userSidRes=null;
var resDeptSidView=null;
function viewResume(obj,userSid,resDeptSid){
	userSidRes=userSid;
	resDeptSidView=resDeptSid;
	var data={"isMedFlag":"01"};
	alert_box(ctx+'/pages/resume/resume-view.jsp #viewReusmeDiv',data);
}
//查询专科分类


function selectSpecType(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/SPEC_TYPE", 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#specType").append(option);
						selectSpec(data[i].codeValue);
					}else{
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#specType").append(option);
					}
				}
//				$("#specType option:first").prop("selected", 'selected');
//				$("#specType option[value='01']").attr("selected", "selected");
			}
        } 
	})
}

//查询所有医院下所有科室
function selectSpec(specType){
	console.log(specType);
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectDeptBySpec", 
		type:"POST",
		params:{
			specType:specType,
		},
		callback : function (data) {
			console.log(data);
			var alloption="<option value='0' >全部</option>";
			$("#deptBySpec").append(alloption);
			var items=new Array();
			items.push(alloption);
			for(var i=0;i<data.length;i++){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].deptSid+"'>"+data[i].deptName+"</option>";
						$("#deptBySpec").append(option);
						items.push(option);
					}else{
						var option="<option value='"+data[i].deptSid+"'>"+data[i].deptName+"</option>";
						$("#deptBySpec").append(option);
						items.push(option);
					}
				}
				
				$( "#deptBySpec" ).easyDropDown({
					wrapperClass: 'dropdown',
					cutOff:12
					
				});
			}
			
//			 $( "#specType" ).selectmenu("refresh");
      } 
   });
}

//医教科发送通知
function sendNotice(obj){
	var checkboxObj=$(obj).parent().prevAll().eq(1).find("input");
	var resDeptSid=$(checkboxObj).val();
	console.log(resDeptSid);
	var resDeptSidArray=new Array();
	resDeptSidArray.push(resDeptSid);
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/medEduSendNoticeToUser", 
		type:"POST",
		params:{
			resumeDeptSid:resDeptSidArray,
			status:'12'
		},
		callback : function (data) {
			
		} 
   });
}
//批量发送通知
function sendNotices(){
	var checkBoxChecked=$("input[name='item']:checked");
	var resDeptSidArray=new Array(); 
	if(checkBoxChecked.length>0){
		for(var i=0;i<checkBoxChecked.length;i++){
			console.log($(checkBoxChecked[i]).val());
			resDeptSidArray.push($(checkBoxChecked[i]).val());
		}
		Core.AjaxRequest({
			url :ws_url + "/rest/resume/medEduSendNoticeToUser", 
			type:"POST",
			params:{
				resumeDeptSid:resDeptSidArray
			},
			callback : function (data) {
				
			} 
	   });
		
	}else{
		alert("请选择数据后再发送");
	}
}

//批量删除简历
function delReusmes(){
	var checkBoxChecked=$("input[name='item']:checked");
	var resDeptSidArray=new Array(); 
	if(checkBoxChecked.length>0){
		for(var i=0;i<checkBoxChecked.length;i++){
			console.log($(checkBoxChecked[i]).val());
			resDeptSidArray.push($(checkBoxChecked[i]).val());
		}
		Core.AjaxRequest({
			url :ws_url + "/rest/resume/oprateResume", 
			type:"POST",
			params:{
				resumeDeptSids:resDeptSidArray,
				status:"10"
			},
			callback : function (data) {
				
			} 
	   });
		
	}else{
		alert("请选择数据后再发送");
	}
}