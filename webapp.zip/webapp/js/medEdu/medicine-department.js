//var medEduPartSid='d8ebed43-77a4-11e5-b58a-00ff11c9bcf0';
//查询条件
var selectParams=function(){
	var selectBatch=$("#selectBatch").val();
	if('0'!=selectBatch&&selectBatch!=null&&selectBatch!=""){
		this.learnBeginDateYear=selectBatch.split("-")[0];
		this.learnBeginDateMonth=selectBatch.split("-")[1];
	}
	var specType= $("#specType").val();
	if('0'!=specType&&specType!=null&&specType!=""){
		this.specType=specType;
	}
	this.medicalEduPartSid=medEduPartSid;
	this.status=function(){
		if($("#onlyViewNotPass").prop("checked")) {
			return '06';
		} else{
			return "'06','13'";
		}
	};
//	this.status="'06','13'";
};
// 条件查询简历
function selectResumeByParams(){
	var param=new selectParams();
	param.status=param.status();
	Core.AjaxRequest({
		//查询当前医教科下的批次，以及批次下的医生
		url :ws_url + "/rest/resume/selectWaitAdmissionByParams", 
		type:"POST",
		params:param,
		callback : function (data) {
			$("#resumeGrid").empty();
			if(data!=null&&data.length>0){
			for(var i=0;i<data.length;i++){
				//填充按专科查询进修
				
				var conDiv="<li>" +
							"<div class='t_dv'>" +
								"<h1><span>"+data[i].deptName+":</span><span>"+data[i].learnBeginDateYear+"年"+data[i].learnBeginDateMonth+"月批</span><em>部分未发送</em></h1>" +
								"<h2>" +
									"<input type='checkbox'id='allCheck"+i+"'/><i>全选</i>" +
								"</h2>" +
							"</div>" +
							"<ul class='ul_face' id='waitAddmisUsers"+i+"'>" +
								
							"</ul>" +
								"<div class='btn_dv'>" +
								"<span class='sendlqtz' onclick='sendAddmisNotice(this)'>发送录取通知</span>" +
								"<span class='del' onclick='delResume(this)'>删除</span>" +
								"</div>" +
							"</li>";
				$("#resumeGrid").append(conDiv);
				
				var waitUsers=data[i].waitAdmisUser;
				$.each(waitUsers,function(index,content){
					var li="<li>" +
							"<span></span>" +
							"<img src='"+ctx+"/"+content.faceImage+"' style='width:71px;height:71px' alt=''>" +
							"<div class='bb'><input type='checkbox' name='check"+index+"' id='check"+index+"' value='"+content.resDeptSid+"'></div>" +
							"</li>";
					$("#waitAddmisUsers"+i).append(li);
					if('13'==content.resDeptStatus){
						$("#check"+index)[0].checked=true;
					}
				});
				
				$("#allCheck"+i).click(function(){
					if(this.checked){
						$(this).parent().next().next().find("input").each(function(){
							this.checked=true;
						});
					}else{
						$(this).parent().next().next().find("input").each(function(){
							this.checked=false;
						});
					}
				});
			}
			intCheckbox();
			//分页
			getPage('.fenye','resumeGrid',4);
			}else{
				var li="<li style='text-align:center;padding-top:20px;'>" +
				"<div style='background-color: #FFF;width:692px;height:145px;margin-top:30px;'>" +
				"<div class='nodata'><span style='position:relative;top:90px;color:#7e7d7d'>无数据</span></div>" +
				"</div>" +
				"</li>";
				$("#resumeGrid").append(li);
		}
      } 
   });
	
}
//查询专科分类
function selectSpecType(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/SPEC_TYPE", 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#specType").append(option);
					}else{
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#specType").append(option);
					}
				}
			}
        } 
	});
}
//TODO 根据医教科SID查询统计去重后的批次
function selectStatisticsBatchByMedEduSid(){
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selectStatisticsBatchByMedEduSid/"+medEduPartSid, 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				var option="<option value='0'>全部</option>";
				$("#selectBatch").append(option);
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].batchCode+"'>"+data[i].batchValue+"</option>";
						$("#selectBatch").append(option);
					}else{
						var option="<option value='"+data[i].batchCode+"'>"+data[i].batchValue+"</option>";
						$("#selectBatch").append(option);
					}
				}
			}
		} 
	});
}

//批量发送录取通知
function sendAddmisNotice(obj){
	var checkBox=$(obj).parent().prev().find("input");
//	input[name='item']:checked
	var resDeptSidArray=new Array(); 
	if(checkBox.length>0){
		for(var i=0;i<checkBox.length;i++){
			if(checkBox[i].checked){
				resDeptSidArray.push($(checkBox[i]).val());
			}
		}
	}
	console.log(resDeptSidArray);
	if(resDeptSidArray.length>0){
		Core.AjaxRequest({
			url :ws_url + "/rest/resume/oprateResume", 
			type:"POST",
			params:{
				resumeDeptSids:resDeptSidArray,
				status:"13"
			},
			callback : function (data) {
				
			} 
	   });
		
	}else{
		alert("请选择数据后再发送");
	}
}
//批量删除
function delResume(obj){
	var checkBox=$(obj).parent().prev().find("input");
//	input[name='item']:checked
	var resDeptSidArray=new Array(); 
	if(checkBox.length>0){
		for(var i=0;i<checkBox.length;i++){
			if(checkBox[i].checked){
				resDeptSidArray.push($(checkBox[i]).val());
			}
		}
	}
	if(resDeptSidArray.length>0){
		Core.AjaxRequest({
			url :ws_url + "/rest/resume/oprateResume", 
			type:"POST",
			params:{
				resumeDeptSids:resDeptSidArray,
				status:"09"
			},
			callback : function (data) {
				selectResumeByParams();
			} 
	   });
		
	}else{
		alert("请选择数据后再发送");
	}
}