var medEduPartSid='d8ebed43-77a4-11e5-b58a-00ff11c9bcf0';
//查询条件
var selectParams=function(){
	var selectBatch=$("#selectBatch").val();
	if('0'!=selectBatch&&selectBatch!=null&&selectBatch!=""){
		this.learnBeginDateYear=selectBatch.split("-")[0];
		this.learnBeginDateMonth=selectBatch.split("-")[1];
	}
	var specType= $("#specType").val();
	if("00"!=specType){
		this.specType=specType;
	}
	if($("#deptBySpec").val()!='0'){
		this.deptSid=$("#deptBySpec").val();
	}else{
		this.deptSid=null;
	}
	if($("#search").val()!=null&&$("#search").val()!=""){
		this.positionName=$("#search").val();
	}
	this.sortFileter=$("#sortFilter").val();
	this.isDesc=function(){
		if($("#ascOrDesc").prop("checked")) {
			return '02';
		} else{
			return '01';
		}
	};
	this.medicalEduPartSid=medEduPartSid;
	this.positionStatus='02';
};

// 条件查询简历
function selectResumeByParams(){
	var param=new selectParams();
	param.ascOrDesc=param.isDesc();
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selectBachByParamsInMedEdu", 
		type:"POST",
		params:param,
		callback : function (data) {
			console.log(data);
			$("#num").html(data.length);
			$("#resumeGrid li").remove();
			var j=0;
			if(data!=null&&data.length>0){
			for(var i=0;i<data.length;i++){
				var isRetestStr='';
				if('01'==data[i].isRetest){
					isRetestStr='有';
				}else{
					isRetestStr='无';
				}
				//填充按专科查询进修
				var li="<li>" +
				"<p class='y_c_title' style='height:50px'>" +
					"<input type='checkbox' name='item' id=''value='"+data[i].positionSid+"'>" +
					"<span class='sp_cfirst'> "+data[i].learnBeginDateYear+"年"+data[i].learnBeginDateMonth+"月</span>" +
				"</p>" +
				"<dl>" +
					"<dd>" +
						"<p class='first' style='margin-top:13px'>" +
							"<a href=''>"+data[i].deptName+"</a> " + 
							"<span class='value'>临床专科</span>" +
						"</p>" +
						"<p style='width:300px; margin-top:10px'>" +
							"<span class='key'>招收人数：</span><span class='value' style='display:inline-block;width:142px'><span>"+data[i].recruitPeopleNum+"</span>人</span>" +
							"<span class='key'>复试：</span><span class='value'><span style='display:inline-block;'>"+isRetestStr+"</span></span>" +
						"</p>" +
						"<p style='width:500px;margin-top:10px'>" +
							"<span class='value' style='color:#1395d8'>已有 <span class='notApproveNum' style='background-color:#1395d8'>"+data[i].passPeopleNum+"</span> 人通过</span>" +
							"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +
							"<span class='value' style='color:#e1685c'>已有 <span class='notApproveNum'>"+data[i].applyPoepleNum+"</span> 人申请</span>" +
							"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +
							"<span class='value' style='color:#f39800'>目前 <span class='notApproveNum' style='background-color:#f39800'>"+data[i].userNotConfirmNum+"</span> 人待确认</span>" +
						"</p>" +
					"</dd>" +
				"</dl>" +
				"<p class='y_c_control y_m_control'>" +
					
					"<a href='"+ctx+"/pages/medEdu/med-edu-edit-position.jsp?posSid="+data[i].positionSid+"' class='edit'>重新上线</a>" +
//					"<a href='javascript:;' class='offline' onClick='downPos(this)'>下线</a>" +
					"<a href='' class='del big_del' onClick='delPos(this)'>删除</a>" +
				"</p>" +
			"</li>";
				$("#resumeGrid").append(li);
			}
			mCheck();
			//分页
			getPage('.fenye','resumeGrid',4);
			
		}else{
			var li="<li style='text-align:center;padding-top:20px;'>" +
			"<div style='background-color: #FFF;width:692px;height:145px;margin-top:30px;'>" +
			"<div class='nodata'><span style='position:relative;top:90px;color:#7e7d7d'>无数据</span></div>" +
			"</div>" +
			"</li>";
				$("#resumeGrid").append(li);
		}
      } 
   });
}

//查询专科分类
function selectSpecType(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/SPEC_TYPE", 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#specType").append(option);
						selectSpec(data[i].codeValue); 	
					}else{
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#specType").append(option);
					}
				}
//				$("#specType option:first").prop("selected", 'selected');
//				$("#specType option[value='01']").attr("selected", "selected");
			}
        } 
	})
}

//查询所有医院下所有科室
function selectSpec(specType){
	console.log(specType);
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectDeptBySpec", 
		type:"POST",
		params:{
			specType:specType,
		},
		callback : function (data) {
			console.log(data);
			var alloption="<option value='0'>全部</option>";
			$("#deptBySpec").append(alloption);
			for(var i=0;i<data.length;i++){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].deptSid+"'>"+data[i].deptName+"</option>";
						$("#deptBySpec").append(option);
					}else{
						var option="<option value='"+data[i].deptSid+"'>"+data[i].deptName+"</option>";
						$("#deptBySpec").append(option);
					}
				}
				$( "#deptBySpec" ).easyDropDown({
					wrapperClass: 'dropdown',
					
				});
			}
			
      } 
   });
}
//TODO 根据医教科SID查询统计去重后的批次
function selectStatisticsBatchByMedEduSid(){
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selectStatisticsBatchByMedEduSid/"+medEduPartSid, 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				var option="<option value='0'  class='label'>全部</option>";
				$("#selectBatch").append(option);
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].batchCode+"'>"+data[i].batchValue+"</option>";
						$("#selectBatch").append(option);
//						selectSpec(data[i].codeValue);
					}else{
						var option="<option value='"+data[i].batchCode+"'>"+data[i].batchValue+"</option>";
						$("#selectBatch").append(option);
					}
				}
//				$("#specType option:first").prop("selected", 'selected');
//				$("#specType option[value='01']").attr("selected", "selected");
			}
		} 
	})
}
//删除
function delPos(obj){
	var checkboxObj=$(obj).parent().prevAll().eq(1).children().eq(0);
	var resDeptSid=$(checkboxObj).val();
	var resDeptSidArray=new Array();
	resDeptSidArray.push(resDeptSid);
	Core.AjaxRequest({
		url :ws_url + "/rest/position/operatePosition", 
		type:"POST",
		params:{
			positionSids:resDeptSidArray,
			positionStatus:"03"
		},
		callback : function (data) {
			
      } 
   });
}

//批量删除
function delPoses(){
	var checkBoxChecked=$("input[name='item']:checked");
	var resDeptSidArray=new Array(); 
	if(checkBoxChecked.length>0){
		for(var i=0;i<checkBoxChecked.length;i++){
			console.log($(checkBoxChecked[i]).val());
			resDeptSidArray.push($(checkBoxChecked[i]).val());
		}
		Core.AjaxRequest({
			url :ws_url + "/rest/position/operatePosition", 
			type:"POST",
			params:{
				positionSids:resDeptSidArray,
				positionStatus:"03"
			},
			callback : function (data) {
				
			} 
	   });
		
	}else{
		alert("请选择数据后再发送");
	}
}