
//放置批次code值数组
var batchArrayCode=new Array();

//批次value值数组
var batchArray=new Array();

//当前批次code
var batchNumNow=1;
function selectSpecType(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/SPEC_TYPE", 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#specType").append(option);
					}else{
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#specType").append(option);
					}
				}
				$("#specType option[value='01']").attr("selected", true);
			}
        } 
     });
}

//查询所有医院下所有科室
function selectSpec(specType){
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectDeptBySpec", 
		type:"POST",
		params:{
			specType:specType,
		},
		callback : function (data) {
			var j=0;
			for(var i=0;i<data.length;i++){
				//填充按专科查询进修
				if(j==0){
					var ul="<ul class='specUl'></ul>";
					$("#specTd").append(ul);
					j++;
				}else{
					if(j==3){
						j=0;
					}else{
						j++;
					};
				};
				var ali="<li><input type='radio' name='specRadio' value='"+data[i].deptSid+"'><label>"+data[i].deptName+"</label></li>";
				$("#specTd ul:last").append(ali);
			}
			$('label').click(function(){
			    var radioId = $(this).attr('name');
			    $('label').removeAttr('class') && $(this).attr('class', 'checked');
			    $('input[type="radio"]').removeAttr('checked') && $('#' + radioId).attr('checked', 'checked');
			  });
      } 
   });
}


//查询是否复试
function selectYesNo(j){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/YES_NO", 
		type:"get",
		async:false,
		callback : function (data) {
			console.log(data);
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#isReTest"+j).append(option);
					}else{
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#isReTest"+j).append(option);
					}
				}
//				$("#specType option[value='01']").attr("selected", "selected");
			}
		} 
	});
}
//查询学位
function selectDegrees(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/DEGREE", 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#lowDegree").append(option);
					}else{
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#lowDegree").append(option);
					}
				}
				$("#lowDegree option[value='01']").attr("selected", "selected");
			}
		} 
	});
}
//查询学历
function selectEduBack(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/EDU_BACK", 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#lowEduBack").append(option);
					}else{
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#lowEduBack").append(option);
					}
				}
				$("#lowEdu option[value='01']").attr("selected", "selected");
			}
		} 
	});
}
//查询学历
function selectWorkTitle(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/WORK_TITLE", 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#lowTitle").append(option);
					}else{
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#lowTitle").append(option);
					}
				}
				$("#lowTitle option[value='01']").attr("selected", "selected");
			}
		} 
	});
}
//查询工作经验
function selectWorkLength(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/WORK_EXPERISE", 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
					if(i==0){
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#lowWorkLength").append(option);
					}else{
						var option="<option value='"+data[i].codeValue+"'>"+data[i].codeDisplay+"</option>";
						$("#lowWorkLength").append(option);
					}
				}
				$("#lowWorkLength option[value='01']").attr("selected", "selected");
			}
		} 
	});
}

//定义职位部分属性
function position(){
	this.lowEduBack=function(){
		if($("#lowEduBackChk").prop("checked")) {
			return $("#lowEduBack").val();
		} else{
			return null;
		}
	};
	this.lowTitle=function(){
		if($("#lowTitleChk").prop("checked")) {
			return $("#lowTitle").val();
		} else{
			return null;
		}
	};
	this.lowWorkLength=function(){
		if($("#lowWorkLengthChk").prop("checked")) {
			return $("#lowWorkLength").val();
		} else{
			return null;
		}
	};
	this.isDoctorQuaCer=function(){
		 if($("#isDoctorQuaCer").prop("checked")) {
		 	return "01";
		 } else{
		 	return "02";
		 }
	};
	this.isProPhyCer=function(){
		 if($("#isProPhyCer").prop("checked")) {
			 	return "01";
			 } else{
			 	return "02";
			 }
		};
	this.isNurQuaCer=function(){
		 if($("#isNurQuaCer").prop("checked")) {
			 	return "01";
			 } else{
			 	return "02";
			 }
		};
	this.isDoctorPraCer=function(){
		 if($("#isDoctorPraCer").prop("checked")) {
			 	return "01";
			 } else{
			 	return "02";
			 }
		};
	this.isProPraCer=function(){
		 if($("#isProPraCer").prop("checked")) {
			 	return "01";
			 } else{
			 	return "02";
			 }
		};
	this.isNurPraCer=function(){
		 if($("#isNurPraCer").prop("checked")) {
			 	return "01";
			 } else{
			 	return "02";
			 }
		};
	this.isLarInstCer=function(){
		if($("#isLarInstCer").prop("checked")) {
			return "01";
		} else{
			return "02";
		}
	};
}
function getPositionBySid(positionSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/position/getPosBySid/"+positionSid, 
		type:"GET",
		callback : function (data) {
			console.log(data);
			//设置页面的值
			$("#specType").val(data.deptSid);
			//初始化专科类型
			$("#specType").selectmenu();
			var deptArray=$("input[name='specRadio']");
			for(var i=0;i<deptArray.length;i++){
				if($(deptArray[i]).val()==data.deptSid){
					$(deptArray[i]).attr("checked","checked");
				}
			}
			$("#learnDirection").val(data.learnDirection);


			//设置职位要求
			
			if(data.requireEducate!=null){
				$("#lowEduBackChk").attr("checked","checked");
				$("#lowEduBack").val(data.requireEducate);
			}
			if(data.requireTitle!=null){
				$("#lowTitleChk").attr("checked","checked");
				$("#lowTitle").val(data.requireTitle);
			}
			if(data.workExperise!=null){ 
				$("#lowWorkLengthChk").attr("checked","checked");
				$("#lowWorkLength").val(data.workExperise);
			}
			if(data.isDoctorQuaCer=='01'){
				$("#isDoctorQuaCer").attr("checked","checked");
			}
			if(data.isProPhyCer=='01'){
				$("#isProPhyCer").attr("checked","checked");
			}
			if(data.isNurQuaCer=='01'){
				$("#isNurQuaCer").attr("checked","checked");
			}
			if(data.isDoctorPraCer=='01'){
				$("#isDoctorPraCer").attr("checked","checked");
			}
			if(data.isProPraCer=='01'){
				$("#isProPraCer").attr("checked","checked");
			}
			if(data.isNurPraCer=='01'){
				$("#isNurPraCer").attr("checked","checked");
			}
			
			if(data.isLarInstCer=='01'){
				$("#isLarInstCer").attr("checked","checked");
			}
			
			//初始化最低学位
			$("#lowDegree").selectmenu();

			//初始化最低职称
			$("#lowTitle").selectmenu();

			//初始化工作经验
			$("#lowWorkLength").selectmenu();
			$("#otherRequest").val(data.otherRequest);
			$("#recruitProcess").val(data.recruitProcess);
			$("#notice").val(data.notice);
			$("#contactor").val(data.contactor);
			$("#contactWay").val(data.contactWay);
			
			console.log(batchArray);
      } 
   });
}
//发布职位
function releasePosition(){
	checkBatchArrayCodeRepeat(batchNumNow);
	//收集页面批次值
	collectBatchValue();
	console.log(batchArrayCode);
	var pos=new position();
	Core.AjaxRequest({
		url :ws_url + "/rest/position/releaseSinglePosition", 
		type:"post",
		params:{
			deptSid:$("input[name='specRadio']:checked").val(),
	 		learnDirection:$("#learnDirection").val(),
	 		requireEducate:pos.lowEduBack(),
			requireTitle:pos.lowTitle(),
			workExperise:pos.lowWorkLength(),
			isDoctorQuaCer:pos.isDoctorQuaCer(),
			isProPhyCer:pos.isProPhyCer(),
			isNurQuaCer:pos.isNurQuaCer(),
			isDoctorPraCer:pos.isDoctorPraCer(),
			isProPraCer:pos.isProPraCer(),
			isNurPraCer:pos.isNurPraCer(),
			isLarInstCer:pos.isLarInstCer(),
			otherRequest:$("#otherRequest").val(),
			recruitProcess:$("#recruitProcess").val(),
			notice:$("#notice").val(),
			contactor:$("#contactor").val(),
			contactWay:$("#contactWay").val(),
			type:"01",
			specType:$("#specType").val(),
			medicalEduPartSid:"d8ebed43-77a4-11e5-b58a-00ff11c9bcf0",
			batchList:batchArray
		},
		callback : function (data) {
			
		}
	});
}

//动态添加删除批次
function addBatch(obj,batchNumPrev){
	checkBatchArrayCodeRepeat(batchNumPrev);
	batchNumNow++;
	var nearTr=$(obj).parent().parent().next();
	var addArea="<tr>" +
			"<td>招生日期</td>" +
			"<td >" +
				"<select name='speed' id='recruitYear"+batchNumNow+"' style='width:180px;height:32px'>" +
					"<option value='0' >全部</option>" +
					"<option value='2015'>2015年</option>" +
					"<option value='2016'>2016年</option>" +
					"<option value='2017'>2017年</option>" +
					"<option value='2018'>2018年</option>" +
					"<option value='2019'>2019年</option>" +
					"<option value='2020'>2020年</option>" +
				"</select>&nbsp;" +
				"<select name='speed' id='recruitMonth"+batchNumNow+"' style='width:180px;height:32px'>" +
					"<option value='0'>全部</option>" +
					"<option value='1'>1月</option>" +
					"<option value='2'>2月</option>" +
					"<option value='3'>3月</option>" +
					"<option value='4'>4月</option>" +
					"<option value='5'>5月</option>" +
					"<option value='6'>6月</option>" +
					"<option value='7'>7月</option>" +
					"<option value='8'>8月</option>" +
					"<option value='9'>9月</option>" +
					"<option value='10'>10月</option>" +
					"<option value='11'>11月</option>" +
					"<option value='12'>12月</option>" +
				"</select>" +
			"</td>" +
			"<td>开课日期</td>" +
			"<td>" +
				"<select name='speed' id='learnBeginYear"+batchNumNow+"' style='width:180px;height:32px'>" +
					"<option value='0' >全部</option>" +
					"<option value='2015'>2015年</option>" +
					"<option value='2016'>2016年</option>" +
					"<option value='2017'>2017年</option>" +
					"<option value='2018'>2018年</option>" +
					"<option value='2019'>2019年</option>" +
					"<option value='2020'>2020年</option>" +
				"</select>&nbsp;" +
				"<select name='speed' id='learnBeginMonth"+batchNumNow+"' style='width:180px;height:32px'>" +
					"<option value='0'>全部</option>" +
					"<option value='1'>1月</option>" +
					"<option value='2'>2月</option>" +
					"<option value='3'>3月</option>" +
					"option value='4'>4月</option>" +
					"<option value='5'>5月</option>" +
					"<option value='6'>6月</option>" +
					"<option value='7'>7月</option>" +
					"<option value='8'>8月</option>" +
					"<option value='9'>9月</option>" +
					"<option value='10'>10月</option>" +
					"<option value='11'>11月</option>" +
					"<option value='12'>12月</option>" +
				" </select>" +
				"</td>" +
			"</tr>" 
				+
			"<tr>" +
				"<td style='vertical-align: top;'>开课周期 </td>" +
				"<td colspan='3'>" +
					"<ul class='courseLengthUl'>" +
						"<li>" +
							"<input type='checkbox' name='courseLength"+batchNumNow+"' id='oneMon"+batchNumNow+"'value='1'>1个月" +
							"&nbsp;"+
							"<input type='text' style='width: 67px;height:20px' id='oneMonCost"+batchNumNow+"'> 元" +
						"</li>" +
						"<li style='margin-left:30px'>" +
							"<input type='checkbox' name='courseLength"+batchNumNow+"' id='threeMon"+batchNumNow+"' value='3'>3个月" +
							"&nbsp;"+
							"<input type='text' style='width: 67px;height:20px' id='threeMonCost"+batchNumNow+"'> 元" +
						"</li>" +
						"<li>" +
							"<input type='checkbox' name='courseLength"+batchNumNow+"' id='sixMon"+batchNumNow+"' value='6'>6个月" +
							"&nbsp;"+
							"<input type='text' style='width: 67px;height:20px' id='sixMonCost"+batchNumNow+"'> 元" +
						"</li>" +
						"<li style='margin-left:30px'>" +
							"<input type='checkbox' name='courseLength"+batchNumNow+"' id='twelveMon"+batchNumNow+"' value='12'>一年" +
							"&nbsp;&nbsp;&nbsp;"+
							"<input type='text' style='width: 67px;height:20px' id='twelveMon1Cost"+batchNumNow+"'> 元" +
						"</li>" +
						"<li>" +
							"<input type='checkbox' name='courseLength1' id='udLengthCh"+batchNumNow+"'>"+
							"其他 &nbsp;&nbsp;<input type='text' style='width: 67px;height:20px' id='udLength"+batchNumNow+"'> 月 " +
							"<input type='text' style='width: 67px;height:20px' id='udLengthCost"+batchNumNow+"'> 元" +
						"</li>"+
						"<li style='margin-left:30px'>" +
							"招收人数 "+
						"<input id='recruitNumSpinner"+batchNumNow+"' name='recruitNumSpinner' style='width: 42px;height: 25px'>"+
						"</li>"+
					"</ul>" +
				"</td>" +
			"</tr>" +
			"<tr>" +
				"<td>是否复试</td>" +
				"<td style='width:241px'>" +
					"<select name='speed' id='isReTest"+batchNumNow+"' style='width:180px;height:32px'>" +
					" </select>" +
				"</td>" +
				"<td class='tdName'>复试时间</td>" +
						"<td>" +
							"<input type='text' id='isRetestDate"+batchNumNow+"'>" +
							" <a  class='positionAdd' onClick='addBatch(this,"+batchNumNow+")'>添加</a>" +
						"</td>" +
			"</tr>" +
			"<tr>" +
				"<td colspan='4'>" +
					"<img class='hrImage'>" +
				"</td>" +
			"</tr>";
	
	nearTr.after(addArea);
	//切换上个添加按钮为删除
	$(obj).html("删除");
	$(obj).removeClass().addClass("positionDel");
	
	//解绑添加方法
	$(obj).removeAttr("onClick");
	
	//赋予删除按钮方法
	$(obj).attr("onClick","delBatch(this,"+batchNumPrev+")");
	
	//初始化控件
	//初始化是否复试
	selectYesNo(batchNumNow);
	$('#isReTest'+batchNumNow).selectmenu();
	//初始化招生年
	$('#recruitYear'+batchNumNow).selectmenu({
		width:95,
	});
	//初始化招生月
	$('#recruitMonth'+batchNumNow).selectmenu({
		width:80,
	});
	//初始化招生月
	$('#learnBeginYear'+batchNumNow).selectmenu({
		width:95,
	});
	//初始化招生月
	$('#learnBeginMonth'+batchNumNow).selectmenu({
		width:80,
	});
	//初始化复试时间
	$('#isRetestDate'+batchNumNow).datepicker({
		utoSize: true,
	});
	//初始化招收人数
	$('#recruitNumSpinner'+batchNumNow).spinner({
		min:0,
	});
	console.log(batchArray);
}


//批次code值判断重复,若存在则不变，否则添加
function checkBatchArrayCodeRepeat(code){
	var flag=true;
	$.each(batchArrayCode,function(index,content){
		if(code==content){
			flag=false;
			return;
		}
	});
	if(flag){
//		var baCodeAdd={"batchCode":code,"batchSid":"","flag":"add"};
		batchArrayCode.push(code);
	}
}

function delBatch(obj,code){
	console.log(code);
	console.log(batchArrayCode);
	$.each(batchArrayCode,function(index,content){
		console.log(content);
		if(code==content){
			batchArrayCode.splice(index, 1);
			
			var prevTrObj=null;
			var trObj=$(obj).parent().parent();
			//查询父对象 查询到所在tr前五个tr 并删除
			for(var i=0;i<5;i++){
				prevTrObj=trObj.prev();
				trObj.remove();
				trObj=prevTrObj;
			}
		}
	});
}
//收集当前页面批次值,并返回批次数组
function collectBatchValue(){
	batchArray.splice(0,batchArray.length);
	$.each(batchArrayCode,function(index,content){
		var batch=new Object();
		batch.recruitDateYear=$("#recruitYear"+content).val();
		batch.recruitDateMonth=$("#recruitMonth"+content).val();
		batch.learnBeginDateYear=$("#learnBeginYear"+content).val();
		batch.learnBeginDateMonth=$("#learnBeginMonth"+content).val();
		if($("#learnBeginMonth"+content).val()>6){
			batch.halfYearFlag='02';
		}else{
			batch.halfYearFlag='01';
		}
		//周期费用
		var cytles=new Array();
		
		//一月
		if($("#oneMon"+content).prop("checked")){
			var oneMon=new Object();
			oneMon.cycleLength=$("#oneMon"+content).val();
			oneMon.cost=$("#oneMonCost"+content).val();
			oneMon.isAboveOneYear="01";
			cytles.push(oneMon);
		}
		
		if($("#threeMon"+content).prop("checked")){
			//三月
			var threeMon=new Object();
			threeMon.cycleLength=$("#threeMon"+content).val();
			threeMon.cost=$("#threeMonCost"+content).val();
			threeMon.isAboveOneYear="01";
			cytles.push(threeMon);
		}
		
		if($("#sixMon"+content).prop("checked")){
			//六月
			var sixMon=new Object();
			sixMon.cycleLength=$("#sixMon"+content).val();
			sixMon.cost=$("#sixMonCost"+content).val();
			sixMon.isAboveOneYear="01";
			cytles.push(sixMon);
		}
		
		if($("#twelveMon"+content).prop("checked")){
			//十二月
			var twelveMon=new Object();
			twelveMon.cycleLength=$("#twelveMon"+content).val();
			twelveMon.cost=$("#twelveMonCost"+content).val();
			twelveMon.isAboveOneYear="02";
			cytles.push(twelveMon);
		}
		
		if($("#udLength"+content).val()!=null&&$("#udLength"+content).val()!=""){
			//自定义
			var udLength=new Object();
			udLength.cycleLength=$("#udLength"+content).val();
			udLength.cost=$("#udLengthCost"+content).val();
			if($("#udLength"+content).val()>12){
				udLength.isAboveOneYear="02";
			}else{
				udLength.isAboveOneYear="01";
			}
			cytles.push(udLength);
		}
		
		batch.cytles=cytles;
		batch.isRetest=$("#isReTest"+content).val();
		batch.retestDate=$("#isRetestDate"+content).datepicker("getDate");
		batch.recruitPeopleNum=$("#recruitNumSpinner"+content).val();
		batch.cost=$("#cost"+content).val();
		batchArray.push(batch);
	});
}