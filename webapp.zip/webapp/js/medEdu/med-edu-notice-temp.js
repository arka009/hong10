 
//获取通知模板
/*function selectTempsByParams(){
	Core.AjaxRequest({
		url :ws_url + "/rest/notice/getNoticeTempByParams", 
		type:"POST",
		params:{
			medicalEduPartSid:'2524c87b-4d8a-11e5-b4fa-480fcf280719'
		},
		callback : function (data) {
			console.log(data);
			$("#noticeTemp div").remove();
			var j=0;
			for(var i=0;i<data.length;i++){
				var div="<div class='tz_box_1'>" +
							"<h5>"+data[i].noticeTypeName+"模板</h5>" +
							"<input type='text' class='nick' style='padding-top:14px;' disabled='disabled' value='"+data[i].noticePerson+"'>：</input>" +
							"<textArea style='width:685px;height:100px' disabled='disabled'>"+data[i].noticeMain+"</textArea>" +
							"<p class='control'>" +
								"<a href='javascript:;' class='c_bj' onClick='editTemp(this)'>编辑</a> " +
								"<a href='javascript:;' class='c_hf' onClick='getTempBySid(this,"+data[i].noticeTempSid+")'>恢复默认</a> " +
								"<a href='javascript:;' class='c_save' onClick='saveTemp(this,"+data[i].noticeTempSid+")'>保存</a>" +
							"</p>" +
						"</div>";
				$("#noticeTemp").append(div);
			}
				
      } 
   });
}*/

//编辑通知模板
/*function editTemp(obj){
	var tempType=$(obj).parent().prevAll().eq(1);
	$(tempType).removeAttr("disabled");
	var tempMain=$(obj).parent().prevAll().eq(0);
	$(tempMain).removeAttr("disabled");
}*/

//保存通知模板
/*function saveTemp(obj,noticeTempSid){
	var tempType=$(obj).parent().prevAll().eq(1);
	var tempMain=$(obj).parent().prevAll().eq(0);
	Core.AjaxRequest({
		url :ws_url + "/rest/notice/saveNoticeTemp", 
		type:"POST",
		params:{
			noticeTempSid:noticeTempSid,
			noticePerson:$(tempType).val(),
			noticeMain:$(tempMain).val()
		},
		callback : function (data) {
			$(tempType).attr("disabled","disabled");
			$(tempMain).attr("disabled","disabled");
      	} 
   });
}*/

//恢复默认
/*function getTempBySid(obj,noticeTempSid){
	var tempType=$(obj).parent().prevAll().eq(1);
	var tempMain=$(obj).parent().prevAll().eq(0);
	Core.AjaxRequest({
		url :ws_url + "/rest/notice/getNoticeTempBySid/"+noticeTempSid, 
		type:"GET",
		callback : function (data) {
			$(tempType).val(data.noticePerson);
			$(tempMain).val(data.noticeMain);
      	} 
   });
}*/