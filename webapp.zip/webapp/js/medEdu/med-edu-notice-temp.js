 
console.log(medEduPartSid);
function switchDiv(type){
	if("01"==type){
		$("#recruitContent").css("display","block");
		$("#waitConfirm").css("display","none");
		$("#notPass").css("display","none");
	}else if("02"==type){
		$("#recruitContent").css("display","none");
		$("#waitConfirm").css("display","block");
		$("#notPass").css("display","none");
	}else if("03"==type){
		$("#recruitContent").css("display","none");
		$("#waitConfirm").css("display","none");
		$("#notPass").css("display","block");
	}
}
//获取通知模板
function selectTempsByParams(){
	Core.AjaxRequest({
		url :ws_url + "/rest/notice/getNoticeTempByParams", 
		type:"POST",
		params:{
			medicalEduPartSid:medEduPartSid
		},
		callback : function (data) {
			$.each(data,function(index,content){
				if("02"==content.noticeType){
					if("report_begin_time"==content.noticeFieldCode){
						$("#tzhz_start").val(content.noticeFieldValue);
					}else if("report_end_time"==content.noticeFieldCode){
						$("#tzhz_end").val(content.noticeFieldValue);
					}else if("report_location"==content.noticeFieldCode){
						$("#location").val(content.noticeFieldValue);
					}else if("remarks"==content.noticeFieldCode){
						$("#remarks").val(content.noticeFieldValue);
					}else if("attachment"==content.noticeFieldCode){
						var index=content.noticeFieldValue.lastIndexOf("."); 
						var fileType=content.noticeFieldValue.substring(index+1);
						if("doc"==fileType||"docx"==fileType){
							$("#admisword").attr("src",ctx+"/img/word.png");
						}else if("pdf"==fileType){
							$("#admisword").attr("src",ctx+"/img/pdf.png");
						}
					}
				}else if("01"==content.noticeType){
					if("main_content"==content.noticeFieldCode){
						$("#waitContent").html(content.noticeFieldValue);
					}
				}else if("03"==content.noticeType){
					if("main_content"==content.noticeFieldCode){
						$("#notPassContent").html(content.noticeFieldValue);
					}
				}
			});
			
        } 
   });
}

//编辑通知模板
/*function editTemp(obj){
	var tempType=$(obj).parent().prevAll().eq(1);
	$(tempType).removeAttr("disabled");
	var tempMain=$(obj).parent().prevAll().eq(0);
	$(tempMain).removeAttr("disabled");
}*/

//保存通知模板
function saveAdmisTemp(){
	var admisTempArray=new Array();
	var beginTime=new Object();
	beginTime.noticeFieldCode="report_begin_time";
	beginTime.noticeFieldValue=$("#tzhz_start").val();
	admisTempArray.push(beginTime);
	var endTime=new Object();
	endTime.noticeFieldCode="report_end_time";
	endTime.noticeFieldValue=$("#tzhz_end").val();
	admisTempArray.push(endTime);
	var location=new Object();
	location.noticeFieldCode="report_location";
	location.noticeFieldValue=$("#location").val();
	admisTempArray.push(location);
	var remark=new Object();
	remark.noticeFieldCode="remarks";
	remark.noticeFieldValue=$("#remarks").val();
	admisTempArray.push(remark);
	if(fileSrc!=null&&fileSrc!=''){
		var attachment=new Object();
		attachment.noticeFieldCode="attachment";
		attachment.noticeFieldValue=fileSrc;
		admisTempArray.push(attachment);
	}
	Core.AjaxRequest({
		url :ws_url + "/rest/notice/saveAdmisNoticeTemp", 
		type:"POST",
		params:admisTempArray,
		callback : function (data) {
			
      	} 
   });
}

//上传图片
function uploadAdmmis(obj,imageId){
		console.log($(obj).prev().val());
		//上传图片
		var fileId=$(obj).prev().attr("id");
		uploadWord(fileId,imageId);
};

var fileSrc = null;
function uploadWord(fileId,imageId){
	$.ajaxFileUpload({
			url:ws_url + "/rest/upload/uploadAdmmisWord/"+medEduPartSid,
			secureuri:false,
			fileElementId:''+fileId+'',
			dataType: 'json',
			success: function (data, status){
				fileSrc = data.filesrc;
				fileType=data.fileType;
				
				if("doc"==fileType||"docx"==fileType){
					$("#"+imageId).attr("src",ctx+"/img/word.png");
				}else if("pdf"==fileType){
					$("#"+imageId).attr("src",ctx+"/img/pdf.png");
				}
				//切换图片
			},
			error: function(data, status, e) {  
				alert(data.a);
				console.log(data);
                   alert("系统异常,请稍后再试!");  
               }
		}
	);
};
