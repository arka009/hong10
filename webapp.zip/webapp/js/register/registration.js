$(function(){
    
	
	// ----------------------------------------------
	// english 鼠标悬浮 提示升级
	$('.en').hover(
			function(){
				
				$(".sy_update").animate({
					"top" : "0px"
				});
				},function(){
				
				$(".sy_update").animate({
					"top" : "-25px"
				});
				
			}
		)
		
	// ----------------------------------------------
    // 会员类型显示隐藏	
   $('input[type="radio"]').click(function () {
                var index = $(this).data('index');
                $('.con').hide();
                $('.con' + index).show();
            });
	
})

// ----------------------------------------------
// 登录框显示隐藏
function showBg() { 
var bh = $("body").height(); 
var bw = $("body").width(); 
$("#fullbg").css({ 
height:bh, 
width:bw, 
display:"block" 
}); 
$("#dialog").show(); 
} 
//关闭灰色 jQuery 遮罩 
function closeBg() { 
$("#fullbg,#dialog").hide(); 
} 


// ----------------------------------------------
// 用户协议显示隐藏
function showProtocol() { 
var bh = $("body").height(); 
var bw = $("body").width(); 
$("#fullbg").css({ 
height:bh, 
width:bw, 
display:"block" 
}); 
$("#protocol").show(); 
} 
//关闭灰色 jQuery 遮罩 
function closeProtocol() { 
$("#fullbg,#protocol").hide(); 
} 