
//用户注册
function registUser(){
	var mail=$("#mail").val();
	var psw=$("#confirmPsw").val();
	Core.AjaxRequest({
		url : ws_url + "/rest/user/register",
		type:"POST",
		params:{
			registMail:mail,
			password:psw,
			registerType:'emailReg'
		},
		callback : function (data) {
			console.log(data);
			if(specType!=null){
				selectLeranBySpec(data);
			}
			
		}
	});
}