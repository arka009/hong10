
//用户注册
function registUser(){
	var mail=$("#mail").val();
	var psw=$("#confirmPsw").val();
	Core.AjaxRequest({
		url : ws_url + "/rest/user/register",
		type:"POST",
		params:{
			registMail:mail,
			password:psw,
			registerType:'emailReg'
		},
		callback : function (data) {
			//跳转到第二步页面
			location.href="registration-email-step2.jsp?mail="+mail;
		}
	});
}

//根据邮箱跳转邮箱登录页面
function goToMailLoginByMail(mail){
	
	//截取字符串
	var domain=mail.split("@")[1].split(".")[0];
	if("163"==domain){
		location.href="http://mail.163.com/";
	}
}