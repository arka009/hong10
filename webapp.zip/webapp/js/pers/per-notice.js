var resumeData=null;
//根据用户获取简历
function selectResumeByUserSid(){
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/getResumeByUserSid/"+userSid, 
		type:"GET",
		callback : function (data) {
			selectUserNotice(data.userSid);
		}
	});
}

var persflag=true;
//确认申请
function selectUserNotice(userSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/user/selectUserNotice/"+userSid, 
		type:"GET",
		callback : function (data) {
			console.log(data);
			$.each(data,function(index,content){
				if("01"==content.noticeType){
					var confirmHtml="<div class='station_info'>" +
										"<div class='title'>" +
											"<span>您已被<em>1</em>所医院录取，请确认</span>" +
											"<strong>"+content.noticeDate+"</strong>" +
											"</div>" +
											"<div class='con clearfix'>" +
											"<p class='first'>"+content.noticeMain+"</p>" +
											"<p class='second'>"+content.noticeFrom+"</p>" +
										"</div>" +	
									"</div>";
					$("#userNotice").append(confirmHtml);
				}else if("02"==content.noticeType){
					var enrollHtml="<div class='station_info'>" +
										"<div class='title'>" +
											"<span>您的简历被<em>1</em>所医院通过，请查看</span>" +
											"<strong>"+content.noticeDate+"</strong>" +
										"</div>"+
										"<div class='con luqu clearfix'>" +
											"<h1>录取通知</h1>" +
											"<div>"+content.noticeMain+"</div>"+
//											"<p>"+content.noticeFrom+"：</p>" +
//											"<p class='p2'>"+content.noticeMain+"</p>" +
//											"<p class='wei'>此致    敬礼！</p>" +
//											"<p class='wei'>"+content.noticeDate+"</p>" +
//											"<p class='wei'>2015年7月19日</p>" +
//											"<p class='last'>注：请查看您简历中填写的邮箱，下载附件并打印，盖章后于报到时上交本院</p>" +
										"</div>" +
									"</div>";
					$("#userNotice").append(enrollHtml);
				}else if("03"==content.noticeType){
					var refuseHtml="<div class='station_info'>" +
										"<div class='title'>" +
											"<span>您的简历被<em>1</em>所医院拒绝</span>" +
											"<strong>"+content.noticeDate+"</strong>" +
											"</div>" +
											"<div class='con clearfix'>" +
											"<p class='first'>"+content.noticeMain+"</p>" +
											"<p class='second'>"+content.noticeFrom+"</p>" +
										"</div>" +
									"</div>";
					$("#userNotice").append(refuseHtml);
				}else if("04"==content.noticeType){
					var trainNoticeHtml="<div class='station_info'>" +
											"<div class='title'>" +
												"<span>您的简历被<em>1</em>所医院拒绝</span>" +
												"<strong>2015-9-16 11:35:34</strong>" +
												"</div>" +
												"<div class='con clearfix'>" +
												"<p class='first'>尊敬的<em>陈童瑶</em> 医生，感谢您对我院的信任，很抱歉的通知您，您的简历在<a href=''>未通过审核</a>，祝您尽快找到合适您的进修。</p>" +
												"<p class='second'>复旦大学附属中山医院</p>" +
											"</div>" +
										"</div>";
					$("#userNotice").append(trainNoticeHtml);
				}
			});
			
			//个人中心-站内消息 展开、收缩功能	
			$(".station_info .title").bind("click",function(){
				if(persflag){
					$(this).next(".con").slideUp(200);
					$(this).children("strong").css({
						"background":"url("+ctx+"/img/pers_sj.png) no-repeat right -45px"
					});
					
					persflag=false;
				}else{
					$(this).next(".con").slideDown(200);
					$(this).children("strong").css({
						"background":"url("+ctx+"/img/pers_sj.png) no-repeat right 15px"
					});
					persflag=true;
				}
				
			});
			
      } 
   });
}