

var spIndex=0;
//初始化数据
selectNationCode();
selectProvinceCode();
//selectCityCode($("#pers_province").val());
selectPolityTypeCode();
selectHealthStatusCode();
selectComputeLevelCode();
selectEduBackCode();
selectCollageLengthCode();
selectResumeByUserSid();
var resumeData=null;
//根据用户获取简历
function selectResumeByUserSid(){
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/getResumeByUserSid/"+userSid, 
		type:"GET",
		callback : function (data) {
			console.log(data);
			setFirstResumePageValues(data);
		}
	});
}
$(".addEdu a").bind("click",function(){
	   spIndex++;
	   var cutOff='{"cutOff":12}';
	   var ul="<ul>" +
		"<li>" +
			"<p>" +
			"<i>最高学历</i>" +
			"</p>" +
			"<div class='pers_div'>" +
				"<select tabindex='6' class='dropdown ' id='eduBack"+spIndex+"'data-settings='"+cutOff+">" +
				"<option value='01'>博士</option>"+
				"<option value='02'>研究生</option>"+
				"<option value='03'>本科</option>"+
				"<option value='04'>专科</option>"+
				"</select>" +
			"</div>" +
			"<p>" +
			"<i>学制</i>" +
			"</p>" +
			"<div class='pers_div'>" +
				"<select tabindex='6' class='dropdown ' id='collageLength"+spIndex+"'" +
						"data-settings='"+cutOff+">" +
						"<option value='01'>四年制</option>"+
						"<option value='02'>五年制</option>"+
						"<option value='03'>七年制</option>"+
						"<option value='04'>八年制</option>"+
						"<option value='05'>全日制</option>"+
						"</select>" +
			"</div>" +
		"</li>" +
		"<li>" +
			"<p>" +
			"<i>学校名称</i>" +
			"</p>" +
			"<div class='pers_div'>" +
				"<input type='text' name='' id='collageName"+spIndex+"' />" +
			"</div>" +
			"<p>" +
			"<i>所学专业</i>" +
			"</p>" +
			"<div class='pers_div'>" +
				"<input type='text' name='' id='majorName"+spIndex+"' />" +
			"</div>" +
		"</li>" +
		"<li class='admission_date'>" +
			"<p>" +
			"<i>入学时间</i>" +
			"</p>" +
			"<div class='pers_div'>" +
				"<select tabindex='6' class='dropdown ' id='collageBeginDateYear"+spIndex+"'data-settings='"+cutOff+">" +
				"<option value='2015'>2015</option>"+
				"<option value='2014'>2014</option>"+
				"<option value='2013'>2013</option>"+
				"<option value='2012'>2012</option>"+
				"<option value='2011'>2011</option>"+
				"<option value='2010'>2010</option>"+
				"<option value='2009'>2009</option>"+
				"<option value='2008'>2008</option>"+
				"<option value='2007'>2007</option>"+
				"<option value='2006'>2006</option>"+
				"<option value='2005'>2005</option>"+
				"<option value='2004'>2004</option>"+
				"<option value='2003'>2003</option>"+
				"<option value='2002'>2002</option>"+
				"<option value='2001'>2001</option>"+
				"<option value='2000'>2000</option>"+
				"<option value='1999'>1999</option>"+
				"<option value='1998'>1998</option>"+
				"<option value='1997'>1997</option>"+
				"<option value='1996'>1996</option>"+
				"<option value='1995'>1995</option>"+
				"<option value='1994'>1994</option>"+
				"<option value='1993'>1993</option>"+
				"<option value='1992'>1992</option>"+
				"<option value='1991'>1991</option>"+
				"<option value='1990'>1990</option>"+
				"<option value='1989'>1989</option>"+
				"<option value='1988'>1988</option>"+
				"<option value='1987'>1987</option>"+
				"<option value='1986'>1986</option>"+
				"<option value='1985'>1985</option>"+
				"<option value='1984'>1984</option>"+
				"<option value='1983'>1983</option>"+
				"<option value='1982'>1982</option>"+
				"<option value='1981'>1981</option>"+
				"<option value='1980'>1980</option>"+
				
			"</select>" +
			"</div>" +
			"<div class='pers_div'>" +
				"<select tabindex='6' class='dropdown ' id='collageBeginDateMonth"+spIndex+"'data-settings='"+cutOff+">" +
				"<option value='1'>1</option>"+
				"<option value='2'>2</option>"+
				"<option value='3'>3</option>"+
				"<option value='4'>4</option>"+
				"<option value='5'>5</option>"+
				"<option value='6'>6</option>"+
				"<option value='7'>7</option>"+
				"<option value='8'>8</option>"+
				"<option value='9'>9</option>"+
				"<option value='10'>10</option>"+
				"<option value='11'>11</option>"+
				"<option value='12'>12</option>"+
				"</select>" +
			"</div>" +
			"<p>" +
			"<i>毕业时间</i>" +
			"</p>" +
			"<div class='pers_div'>" +
				"<select tabindex='6' class='dropdown ' id='collageEndDateYear"+spIndex+"'data-settings='"+cutOff+">" +
				"<option value='2015'>2015</option>"+
				"<option value='2014'>2014</option>"+
				"<option value='2013'>2013</option>"+
				"<option value='2012'>2012</option>"+
				"<option value='2011'>2011</option>"+
				"<option value='2010'>2010</option>"+
				"<option value='2009'>2009</option>"+
				"<option value='2008'>2008</option>"+
				"<option value='2007'>2007</option>"+
				"<option value='2006'>2006</option>"+
				"<option value='2005'>2005</option>"+
				"<option value='2004'>2004</option>"+
				"<option value='2003'>2003</option>"+
				"<option value='2002'>2002</option>"+
				"<option value='2001'>2001</option>"+
				"<option value='2000'>2000</option>"+
				"<option value='1999'>1999</option>"+
				"<option value='1998'>1998</option>"+
				"<option value='1997'>1997</option>"+
				"<option value='1996'>1996</option>"+
				"<option value='1995'>1995</option>"+
				"<option value='1994'>1994</option>"+
				"<option value='1993'>1993</option>"+
				"<option value='1992'>1992</option>"+
				"<option value='1991'>1991</option>"+
				"<option value='1990'>1990</option>"+
				"<option value='1989'>1989</option>"+
				"<option value='1988'>1988</option>"+
				"<option value='1987'>1987</option>"+
				"<option value='1986'>1986</option>"+
				"<option value='1985'>1985</option>"+
				"<option value='1984'>1984</option>"+
				"<option value='1983'>1983</option>"+
				"<option value='1982'>1982</option>"+
				"<option value='1981'>1981</option>"+
				"<option value='1980'>1980</option>"+
			"</select>" +
			"</div>" +
			"<div class='pers_div'>" +
				"<select tabindex='6' class='dropdown ' id='collageEndMonth"+spIndex+"'data-settings='"+cutOff+">" +
				"<option value='1'>1</option>"+
				"<option value='2'>2</option>"+
				"<option value='3'>3</option>"+
				"<option value='4'>4</option>"+
				"<option value='5'>5</option>"+
				"<option value='6'>6</option>"+
				"<option value='7'>7</option>"+
				"<option value='8'>8</option>"+
				"<option value='9'>9</option>"+
				"<option value='10'>10</option>"+
				"<option value='11'>11</option>"+
				"<option value='12'>12</option>"+
			"</select>" +
			"</div>" +
		"</li>" +
	"</ul>";
$("#resumeSp").append(ul);
  

});

//查询民族
function selectNationCode(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/NATION", 
		type:"GET",
		callback : function (data) {
			$.each(data,function(index,content){
				var option=$("<option value='"+content.codeValue+"' class='label'>"+content.codeDisplay+"</option>");
				$("#pers_nations").append(option);
			});
		}
	});
}

//查询省
function selectProvinceCode(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/PROVINCE", 
		type:"GET",
		callback : function (data) {
			$.each(data,function(index,content){
				var option="<option value='"+content.codeValue+"' class='label'>"+content.codeDisplay+"</option>";
				$("#pers_province").append(option);
			});
		}
	});
}

//查询市
function selectCityCode(parentCodeValue){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/getCodeByParams", 
		type:"POST",
		params:{
			codeCategory:"CITY",
			parentCodeValue:parentCodeValue
		},
		callback : function (data) {
			$.each(data,function(index,content){
				var option="<option value='"+content.codeValue+"' class='label'>"+content.codeDisplay+"</option>";
				$("#pers_city").append(option);
			});
		}
	});
}

//查询政治面貌
function selectPolityTypeCode(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/POLITY_TYPE", 
		type:"GET",
		callback : function (data) {
			$.each(data,function(index,content){
				var option="<option value='"+content.codeValue+"' class='label'>"+content.codeDisplay+"</option>";
				$("#polityType").append(option);
			});
		}
	});
}

//查询健康状况
function selectHealthStatusCode(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/HEALTH_STATUS", 
		type:"GET",
		callback : function (data) {
			$.each(data,function(index,content){
				var option="<option value='"+content.codeValue+"' class='label'>"+content.codeDisplay+"</option>";
				$("#healthStatus").append(option);
			});
		}
	});
}

//查询外语水平
function selectComputeLevelCode(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/COMPUTE_LEVEL", 
		type:"GET",
		callback : function (data) {
			$.each(data,function(index,content){
				var option="<option value='"+content.codeValue+"' class='label'>"+content.codeDisplay+"</option>";
				$("#computeLevel").append(option);
			});
		}
	});
}
//查询学历
function selectEduBackCode(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/EDU_BACK", 
		type:"GET",
		callback : function (data) {
			$.each(data,function(index,content){
				var option="<option value='"+content.codeValue+"' class='label'>"+content.codeDisplay+"</option>";
				$("#eduBack").append(option);
			});
		}
	});
}
//查询学制
function selectCollageLengthCode(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/COLLAGE_LENGTH", 
		type:"GET",
		callback : function (data) {
			$.each(data,function(index,content){
				var option="<option value='"+content.codeValue+"' class='label'>"+content.codeDisplay+"</option>";
				$("#collageLength").append(option);
			});
		}
	});
}

//设置简历第一页值
function setFirstResumePageValues(data){
	//姓名
	$("#realName").val(data.realName);
	console.log("@@@@@@@@@"+data.faceImage);
	//姓名
	$("#faceimage").attr("src",data.faceImage);
	
	//性别
	if("01"==data.sex){
		$("#sexId").find("label").removeClass("checked");
		$("#sexId").find("label").eq(0).attr("class","checked"); 
	}else{
		$("#sexId").find("label").removeClass("checked");
		$("#sexId").find("label").eq(1).attr("class","checked"); 
	}
	
	//民族
	$("#pers_nations").val(data.nation);
	
	//籍贯 省
	$("#pers_province").val(data.nationPlace);
	
	//籍贯 市
//	$("#pers_city").val(data.nation);
	
	//身份证
	$("#idCard").val(data.cardId);
	
	//TODO 根据身份证计算出生年月
	
	$("#age").val(data.age);
	
	//婚否
	$("#isMary").val(data.isMary);
	
	//政治面貌
	$("#polityType").val(data.polityStatus);
	
	//健康状态
	$("#healthStatus").val(data.healthStatus);
	
	//外文水平
	$("#computeLevel").val(data.computeLevel);
	
	//手机号码
	$("#mobile").val(data.mobile);
	
	//手机号码
	$("#mail").val(data.mail);
	
	var cutOff='{"cutOff":12}';
	if(data.resumeSPList!=null&&data.resumeSPList.length>0){
		spIndex=data.resumeSPList.length-1;
		$.each(data.resumeSPList,function(index,content){
			var ul="<ul>" +
						"<li>" +
							"<p>" +
							"<i>最高学历</i>" +
							"</p>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown ' id='eduBack"+index+"' data-settings="+cutOff+">" +
								"<option value='01'>博士</option>"+
								"<option value='02'>研究生</option>"+
								"<option value='03'>本科</option>"+
								"<option value='04'>专科</option>"+
								"</select>" +
							"</div>" +
							"<p>" +
							"<i>学制</i>" +
							"</p>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown ' id='collageLength"+index+"'" +
										"data-settings="+cutOff+">" +
										"<option value='01'>四年制</option>"+
										"<option value='02'>五年制</option>"+
										"<option value='03'>七年制</option>"+
										"<option value='04'>八年制</option>"+
										"<option value='05'>全日制</option>"+
										"</select>" +
							"</div>" +
						"</li>" +
						"<li>" +
							"<p>" +
							"<i>学校名称</i>" +
							"</p>" +
							"<div class='pers_div'>" +
								"<input type='text' name='' id='collageName"+index+"' />" +
							"</div>" +
							"<p>" +
							"<i>所学专业</i>" +
							"</p>" +
							"<div class='pers_div'>" +
								"<input type='text' name='' id='majorName"+index+"' />" +
							"</div>" +
						"</li>" +
						"<li class='admission_date'>" +
							"<p>" +
							"<i>入学时间</i>" +
							"</p>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown ' id='collageBeginDateYear"+index+"'data-settings="+cutOff+">" +
								"<option value='2015'>2015</option>"+
								"<option value='2014'>2014</option>"+
								"<option value='2013'>2013</option>"+
								"<option value='2012'>2012</option>"+
								"<option value='2011'>2011</option>"+
								"<option value='2010'>2010</option>"+
								"<option value='2009'>2009</option>"+
								"<option value='2008'>2008</option>"+
								"<option value='2007'>2007</option>"+
								"<option value='2006'>2006</option>"+
								"<option value='2005'>2005</option>"+
								"<option value='2004'>2004</option>"+
								"<option value='2003'>2003</option>"+
								"<option value='2002'>2002</option>"+
								"<option value='2001'>2001</option>"+
								"<option value='2000'>2000</option>"+
								"<option value='1999'>1999</option>"+
								"<option value='1998'>1998</option>"+
								"<option value='1997'>1997</option>"+
								"<option value='1996'>1996</option>"+
								"<option value='1995'>1995</option>"+
								"<option value='1994'>1994</option>"+
								"<option value='1993'>1993</option>"+
								"<option value='1992'>1992</option>"+
								"<option value='1991'>1991</option>"+
								"<option value='1990'>1990</option>"+
								"<option value='1989'>1989</option>"+
								"<option value='1988'>1988</option>"+
								"<option value='1987'>1987</option>"+
								"<option value='1986'>1986</option>"+
								"<option value='1985'>1985</option>"+
								"<option value='1984'>1984</option>"+
								"<option value='1983'>1983</option>"+
								"<option value='1982'>1982</option>"+
								"<option value='1981'>1981</option>"+
								"<option value='1980'>1980</option>"+
								
							"</select>" +
							"</div>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown ' id='collageBeginDateMonth"+index+"'data-settings="+cutOff+">" +
								"<option value='1'>1</option>"+
								"<option value='2'>2</option>"+
								"<option value='3'>3</option>"+
								"<option value='4'>4</option>"+
								"<option value='5'>5</option>"+
								"<option value='6'>6</option>"+
								"<option value='7'>7</option>"+
								"<option value='8'>8</option>"+
								"<option value='9'>9</option>"+
								"<option value='10'>10</option>"+
								"<option value='11'>11</option>"+
								"<option value='12'>12</option>"+
								"</select>" +
							"</div>" +
							"<p>" +
							"<i>毕业时间</i>" +
							"</p>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown ' id='collageEndDateYear"+index+"'data-settings="+cutOff+">" +
								"<option value='2015'>2015</option>"+
								"<option value='2014'>2014</option>"+
								"<option value='2013'>2013</option>"+
								"<option value='2012'>2012</option>"+
								"<option value='2011'>2011</option>"+
								"<option value='2010'>2010</option>"+
								"<option value='2009'>2009</option>"+
								"<option value='2008'>2008</option>"+
								"<option value='2007'>2007</option>"+
								"<option value='2006'>2006</option>"+
								"<option value='2005'>2005</option>"+
								"<option value='2004'>2004</option>"+
								"<option value='2003'>2003</option>"+
								"<option value='2002'>2002</option>"+
								"<option value='2001'>2001</option>"+
								"<option value='2000'>2000</option>"+
								"<option value='1999'>1999</option>"+
								"<option value='1998'>1998</option>"+
								"<option value='1997'>1997</option>"+
								"<option value='1996'>1996</option>"+
								"<option value='1995'>1995</option>"+
								"<option value='1994'>1994</option>"+
								"<option value='1993'>1993</option>"+
								"<option value='1992'>1992</option>"+
								"<option value='1991'>1991</option>"+
								"<option value='1990'>1990</option>"+
								"<option value='1989'>1989</option>"+
								"<option value='1988'>1988</option>"+
								"<option value='1987'>1987</option>"+
								"<option value='1986'>1986</option>"+
								"<option value='1985'>1985</option>"+
								"<option value='1984'>1984</option>"+
								"<option value='1983'>1983</option>"+
								"<option value='1982'>1982</option>"+
								"<option value='1981'>1981</option>"+
								"<option value='1980'>1980</option>"+
							"</select>" +
							"</div>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown ' id='collageEndDateMonth"+index+"'data-settings="+cutOff+">" +
								"<option value='1'>1</option>"+
								"<option value='2'>2</option>"+
								"<option value='3'>3</option>"+
								"<option value='4'>4</option>"+
								"<option value='5'>5</option>"+
								"<option value='6'>6</option>"+
								"<option value='7'>7</option>"+
								"<option value='8'>8</option>"+
								"<option value='9'>9</option>"+
								"<option value='10'>10</option>"+
								"<option value='11'>11</option>"+
								"<option value='12'>12</option>"+
							"</select>" +
							"</div>" +
						"</li>" +
					"</ul>";
			$("#resumeSp").append(ul);
			
			//设置学习经历
			$("#eduBack"+index).val(content.collegeDegree);
			$("#collageLength"+index).val(content.collageLength);
			$("#collageName"+index).val(content.collageName);
			$("#majorName"+index).val(content.majorName);
			var beginDate=content.collageBeginDate;
			var beginYearIndex=beginDate.indexOf("年");
			var beginMonthIndex=beginDate.indexOf("月");
			var beginYear=beginDate.substring(0,beginYearIndex);
			var beginMonth=beginDate.substring(beginYearIndex+1,beginMonthIndex);
			$("#collageBeginDateYear"+index).val(beginYear);
			$("#collageBeginDateMonth"+index).val(beginMonth);
			
			var endDate=content.collageEndDate;
			var endYearIndex=endDate.indexOf("年");
			var endMonthIndex=endDate.indexOf("月");
			var endYear=beginDate.substring(0,endYearIndex);
			var endMonth=beginDate.substring(endYearIndex+1,endMonthIndex);
			$("#collageEndDateYear"+index).val(endYear);
			$("#collageEndMonth"+index).val(endMonth);
		});
	}else{
		var ul="<ul>" +
			"<li>" +
				"<p>" +
				"<i>最高学历</i>" +
				"</p>" +
				"<div class='pers_div'>" +
					"<select tabindex='6' class='dropdown ' id='eduBack0'data-settings="+cutOff+">" +
					"<option value='01'>博士</option>"+
					"<option value='02'>研究生</option>"+
					"<option value='03'>本科</option>"+
					"<option value='04'>专科</option>"+
					"</select>" +
				"</div>" +
				"<p>" +
				"<i>学制</i>" +
				"</p>" +
				"<div class='pers_div'>" +
					"<select tabindex='6' class='dropdown ' id='collageLength0'" +
							"data-settings='"+cutOff+">" +
							"<option value='01'>四年制</option>"+
							"<option value='02'>五年制</option>"+
							"<option value='03'>七年制</option>"+
							"<option value='04'>八年制</option>"+
							"<option value='05'>全日制</option>"+
							"</select>" +
				"</div>" +
			"</li>" +
			"<li>" +
				"<p>" +
				"<i>学校名称</i>" +
				"</p>" +
				"<div class='pers_div'>" +
					"<input type='text' name='' id='collageName0' />" +
				"</div>" +
				"<p>" +
				"<i>所学专业</i>" +
				"</p>" +
				"<div class='pers_div'>" +
					"<input type='text' name='' id='majorName0' />" +
				"</div>" +
			"</li>" +
			"<li class='admission_date'>" +
				"<p>" +
				"<i>入学时间</i>" +
				"</p>" +
				"<div class='pers_div'>" +
					"<select tabindex='6' class='dropdown ' id='collageBeginDateYear0'data-settings="+cutOff+">" +
					"<option value='2015'>2015</option>"+
					"<option value='2014'>2014</option>"+
					"<option value='2013'>2013</option>"+
					"<option value='2012'>2012</option>"+
					"<option value='2011'>2011</option>"+
					"<option value='2010'>2010</option>"+
					"<option value='2009'>2009</option>"+
					"<option value='2008'>2008</option>"+
					"<option value='2007'>2007</option>"+
					"<option value='2006'>2006</option>"+
					"<option value='2005'>2005</option>"+
					"<option value='2004'>2004</option>"+
					"<option value='2003'>2003</option>"+
					"<option value='2002'>2002</option>"+
					"<option value='2001'>2001</option>"+
					"<option value='2000'>2000</option>"+
					"<option value='1999'>1999</option>"+
					"<option value='1998'>1998</option>"+
					"<option value='1997'>1997</option>"+
					"<option value='1996'>1996</option>"+
					"<option value='1995'>1995</option>"+
					"<option value='1994'>1994</option>"+
					"<option value='1993'>1993</option>"+
					"<option value='1992'>1992</option>"+
					"<option value='1991'>1991</option>"+
					"<option value='1990'>1990</option>"+
					"<option value='1989'>1989</option>"+
					"<option value='1988'>1988</option>"+
					"<option value='1987'>1987</option>"+
					"<option value='1986'>1986</option>"+
					"<option value='1985'>1985</option>"+
					"<option value='1984'>1984</option>"+
					"<option value='1983'>1983</option>"+
					"<option value='1982'>1982</option>"+
					"<option value='1981'>1981</option>"+
					"<option value='1980'>1980</option>"+
					
				"</select>" +
				"</div>" +
				"<div class='pers_div'>" +
					"<select tabindex='6' class='dropdown ' id='collageBeginDateMonth0'data-settings="+cutOff+">" +
					"<option value='1'>1</option>"+
					"<option value='2'>2</option>"+
					"<option value='3'>3</option>"+
					"<option value='4'>4</option>"+
					"<option value='5'>5</option>"+
					"<option value='6'>6</option>"+
					"<option value='7'>7</option>"+
					"<option value='8'>8</option>"+
					"<option value='9'>9</option>"+
					"<option value='10'>10</option>"+
					"<option value='11'>11</option>"+
					"<option value='12'>12</option>"+
					"</select>" +
				"</div>" +
				"<p>" +
				"<i>毕业时间</i>" +
				"</p>" +
				"<div class='pers_div'>" +
					"<select tabindex='6' class='dropdown ' id='collageEndDateYear0'data-settings="+cutOff+">" +
					"<option value='2015'>2015</option>"+
					"<option value='2014'>2014</option>"+
					"<option value='2013'>2013</option>"+
					"<option value='2012'>2012</option>"+
					"<option value='2011'>2011</option>"+
					"<option value='2010'>2010</option>"+
					"<option value='2009'>2009</option>"+
					"<option value='2008'>2008</option>"+
					"<option value='2007'>2007</option>"+
					"<option value='2006'>2006</option>"+
					"<option value='2005'>2005</option>"+
					"<option value='2004'>2004</option>"+
					"<option value='2003'>2003</option>"+
					"<option value='2002'>2002</option>"+
					"<option value='2001'>2001</option>"+
					"<option value='2000'>2000</option>"+
					"<option value='1999'>1999</option>"+
					"<option value='1998'>1998</option>"+
					"<option value='1997'>1997</option>"+
					"<option value='1996'>1996</option>"+
					"<option value='1995'>1995</option>"+
					"<option value='1994'>1994</option>"+
					"<option value='1993'>1993</option>"+
					"<option value='1992'>1992</option>"+
					"<option value='1991'>1991</option>"+
					"<option value='1990'>1990</option>"+
					"<option value='1989'>1989</option>"+
					"<option value='1988'>1988</option>"+
					"<option value='1987'>1987</option>"+
					"<option value='1986'>1986</option>"+
					"<option value='1985'>1985</option>"+
					"<option value='1984'>1984</option>"+
					"<option value='1983'>1983</option>"+
					"<option value='1982'>1982</option>"+
					"<option value='1981'>1981</option>"+
					"<option value='1980'>1980</option>"+
				"</select>" +
				"</div>" +
				"<div class='pers_div'>" +
					"<select tabindex='6' class='dropdown ' id='collageEndDateMonth0' data-settings="+cutOff+">" +
					"<option value='1'>1</option>"+
					"<option value='2'>2</option>"+
					"<option value='3'>3</option>"+
					"<option value='4'>4</option>"+
					"<option value='5'>5</option>"+
					"<option value='6'>6</option>"+
					"<option value='7'>7</option>"+
					"<option value='8'>8</option>"+
					"<option value='9'>9</option>"+
					"<option value='10'>10</option>"+
					"<option value='11'>11</option>"+
					"<option value='12'>12</option>"+
				"</select>" +
				"</div>" +
			"</li>" +
		"</ul>";
	$("#resumeSp").append(ul);
	}
}

var resumeFirstPage=function(){
	this.realName=$("#realName").val();
	if("checked"==$("#sexId").find("label").eq(0).attr("class")){
		this.sex="01";
	}else{
		this.sex="02";
	}; 
	this.nation=$("#pers_nations").val();
	this.nativePlace=$("#pers_province").val();
	this.cardId=$("#idCard").val();
	this.birthDate=$("#birthDate").val();
	this.age=$("#age").val();
	this.isMary=$("#isMary").val();
	this.polityStatus=$("#polityType").val();
	this.healthStatus=$("#healthStatus").val();
	
	var resumeLanArray=new Array();
	var lan=new Object();
	lan.languageName=$("#lanName").val();
	lan.languageLevel=$("#computeLevel").val();
	resumeLanArray.push(lan);
	this.resumeLanList=resumeLanArray;
	this.mobile=$("#mobile").val();
	this.mail=$("#mail").val();
	this.faceImage=$("#faceimage").attr("src");
	var resumeSPArray=new Array();
	if(spIndex>0){
		for(var i=0;i<spIndex;i++){
			var sp=new Object();
			sp.collegeDegree=$("#eduBack"+i).val();
			sp.collageLength=$("#collageLength"+i).val();
			sp.collageName=$("#collageName"+i).val();
			sp.majorName=$("#majorName"+i).val();
			sp.collageBeginDate=$("#collageBeginDateYear"+i).val()+"年"+$("#collageBeginDateMonth"+i).val()+"月";
			sp.collageEndDate=$("#collageEndDateYear"+i).val()+"年"+$("#collageEndDateMonth"+i).val()+"月";
			resumeSPArray.push(sp);
		}
	}else{
		var sp=new Object();
		sp.collegeDegree=$("#eduBack0").val();
		sp.collageLength=$("#collageLength0").val();
		sp.collageName=$("#collageName0").val();
		sp.majorName=$("#majorName0").val();
		sp.collageBeginDate=$("#collageBeginDateYear0").val()+"年"+$("#collageBeginDateMonth0").val()+"月";
		sp.collageEndDate=$("#collageEndDateYear0").val()+"年"+$("#collageEndDateMonth0").val()+"月";
		resumeSPArray.push(sp);
	}
	this.resumeSPList=resumeSPArray;
};
//保存简历第一页值 并跳转第二页
function saveFirstPageValue(){
	var resumeFirst=new resumeFirstPage();
	console.log(resumeFirst);
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/insOrUpdResume", 
		type:"POST",
		params:resumeFirst,
		callback : function (data) {
			//跳转第二页
			$("#perContent").load("pers/pers_resume_basic_info_work.jsp");
		}
	});
}

function uploadImg(fileId,imageId){
	$.ajaxFileUpload({
			url:ws_url + "/rest/upload/uploadUserImage/11",
			secureuri:false,
			fileElementId:''+fileId+'',
			dataType: 'json',
			success: function (data, status){
				file = data.filesrc;
				$("#"+imageId).attr("src",file);
			},
			error: function(data, status, e) {  
				alert(data.a);
				console.log(data);
                   alert("系统异常,请稍后再试!");  
               }
		}
	);
};