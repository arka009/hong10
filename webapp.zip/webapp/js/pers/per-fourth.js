selectResumeByUserSid();
var resumeData=null;
//根据用户获取简历
function selectResumeByUserSid(){
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/getResumeByUserSid/"+userSid, 
		type:"GET",
		callback : function (data) {
			setFourthPageValues(data);
		}
	});
}
//设置页面值
function setFourthPageValues(data){
	console.log(data);
	var resumeWp=data.resumeCerList;
	$.each(resumeWp,function(index,content){
		 if('07'==content.cerType){
			$("#sealImage").attr("src",content.cerPhoteUrl);
		}else if('08'==content.cerType){
			$("#hosLevelImage").attr("src",content.cerPhoteUrl);
		}else if('09'==content.cerType){
			$("#introImage").attr("src",content.cerPhoteUrl);
		}
	});
}

//上传图片
function uploadImage(obj,type,imageId){
		//上传图片
		var fileId=$(obj).prev().attr("id");
		uploadImg(fileId,type,imageId);
};

var imageSeal = null;
var imageHosLevel = null;
var imageIntro = null;
function uploadImg(fileId,type,imageId){
	$.ajaxFileUpload({
			url:ws_url + "/rest/upload/uploadUserImage/"+type,
			secureuri:false,
			fileElementId:''+fileId+'',
			dataType: 'json',
			success: function (data, status){
				file = data.filesrc;
				if('07'==type){
					imageSeal=file;
				}else if('08'==type){
					imageHosLevel=file;
				}else if('09'==type){
					imageIntro=file;
				}
				$("#"+imageId).attr("src",file);
			},
			error: function(data, status, e) {  
				alert(data.a);
				console.log(data);
                   alert("系统异常,请稍后再试!");  
               }
		}
	);
};

var resumeFourthPage=function(obj){
	var quaCer=new Object();
	quaCer.cerPhoteUrl=$("#sealImage").attr("src");
	quaCer.cerType="07";
	obj.push(quaCer);
	
	var proCerNum=new Object();
	proCerNum.cerType="08";
	proCerNum.cerPhoteUrl=$("#hosLevelImage").attr("src");
	obj.push(proCerNum);
	
	var proCerScope=new Object();
	proCerScope.cerType="09";
	proCerScope.cerPhoteUrl=$("#introImage").attr("src");
	obj.push(proCerScope);
	this.resumeCerList=obj;
};

function saveFourthPageValue(){
	var resumeFourth=new resumeFourthPage(thirdPageValue);
	console.log(resumeFourth);
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/insOrUpdResume", 
		type:"POST",
		params:resumeFourth,
		callback : function (data) {
//			alert(1);
			//跳转第二页
//			$("#perContent").load("pers/pers_upload_file_3.jsp");
		}
	});
}