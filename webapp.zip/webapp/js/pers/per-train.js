

var resumeData=null;
//根据用户获取简历
function selectResumeByUserSid(){
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/getResumeByUserSid/"+userSid, 
		type:"GET",
		callback : function (data) {
			resumeData=data;
			selectResumeProcess(null);	
		}
	});
}
function selectResumeProcess(status){
	console.log(status);
	if('in'==status){
		status="'01','08','02','03','06'";
	}else if('confirmed'==status){
		status="'12','13'";
	}else if('invalid'==status){
		status="'05','04','07','09','10','11','14','15'";
	}
	//根据用户获取简历
		Core.AjaxRequest({
			url :ws_url + "/rest/resume/selectResumeDeliveryStatus", 
			params:{
				resumeSid:resumeData.resumeSid,
				status:status
			},
			callback : function (data) {
				console.log(data);
				$("#resumeProcessDiv").empty();
				$.each(data,function(index,content){
					//处理特色技术
					var feaTech=content.feaTechName;
					if(feaTech!=null&&feaTech!=''){
						feaTech=feaTech.replace(",","   ");
					}else{
						feaTech="无";
					}
					var proDiv="<div class='reco_jx clearfix'>" +
					"<dl class='reco_tj_con'>" +
						"<dt>"+content.deptName+"</dt>" +
						"<dd class='first'>" +
							"<p>" +
								"<i>进修医院：</i>" +
								"<span>"+content.hospitalName+"</span>" +
							"</p>" +
							"<p>" +
								"<i>学科带头人：</i>" +
								"<span>"+content.realName+"</span>" +
							"</p>" +
						"</dd>" +
						"<dd>" +
							"<p>" +
								"<i>最低学历：</i>" +
								"<span>"+content.requireEducate+"</span>" +
							"</p>" +
							"<p>" +
								"<i>工作年限：</i>" +
								"<span>"+content.workExperise+"</span>" +
							"</p>" +
						"</dd>" +
						"<dd>" +
							"<p>" +
								"<i>进修时长：</i>" +
								"<span>"+content.cycleLength+"个月</span>" +
							"</p>" +
							"<p>" +
								"<i>是否考试：</i>" +
								"<span>"+content.isRetest+"</span>" +
							"</p>" +
						"</dd>" +
						"<dd>" +
							"<p>" +
								"<i>开课时间：</i>" +
								"<span>"+content.learnBeginDateYear+"年"+content.learnBeginDateMonth+"月</span>" +
							"</p>" +
						"</dd>" +
						"<dd>" +
							"<p>" +
								"<i>特色技术：</i>" +
								"<span>"+feaTech+"</span>" +
							"</p>" +
						"</dd>" +
					"</dl>" +
					"<div class='reco_jdt clearfix'>" +
						"<div class='jdt_name'>" +
							"<span class='first'>投递简历</span>" +
							"<span id='medEduApp"+index+"'>医教科接收</span>" +
							"<span id='deptApp"+index+"'>科室审批</span>" +
							"<span id='medEduAgaApp"+index+"'>通过审批</span>" +
							"<span id='userCon"+index+"'>等待确认</span>" +
							"<span id='userConfirmed"+index+"'>已确认</span>" +
						"</div>" +
						"<div class='jdt_state_wrap'>" +
							"<div class='jdt_state' id='jdt_state"+index+"'></div>" +
						"</div>" +
						"<div class='luqu_mes'>" +
							"<p><span id='message"+index+"'></span></p>" +
						"</div>" +
						"<div class='control' id='processButton"+index+"'>" +
							
						"</div>" +
					"</div>" +
				"</div>";
				$("#resumeProcessDiv").append(proDiv);
				console.log(content.status);
				var confirmClick="confirmResume('"+content.resDeptSid+"')";
				var cancelClick="cancelResume('"+content.resDeptSid+"')";
				//医教科已接收未审核
				if('01'==content.status){
					$("#jdt_state"+index).width(146);
					
					var buttons="<a class='button confirmdisable'>确认</a><a  class='button cancle'>取消申请</a>";
					$("#processButton"+index).append(buttons);
					//医教科已通过
				}else if('02'==content.status){
					$("#jdt_state"+index).width(270);
					var buttons="<a class='button confirmdisable'>确认</a><a  class='button cancle'>取消申请</a>";
					$("#processButton"+index).append(buttons);
					//科室通过
				}else if('03'==content.status){
					$("#jdt_state"+index).width(383);
					var buttons="<a class='button confirmdisable'>确认</a><a class='button cancle'>取消申请</a>";
					$("#processButton"+index).append(buttons);
					//科室拒绝
				}else if('04'==content.status||'10'==content.status){
					$("#jdt_state"+index).width(273);
					$("#jdt_state"+index).css("background","#b5b5b6");
					
					$("#deptApp"+index).html("未通过审核");
					$("#message"+index).html("很遗憾您的本次申请未能通过医院审批<br>请等待下次招生，或查看平台其他进修职位");
					$("#message"+index).css("color","#e1685c");
					
					var buttons="<a class='button cancle'>查看其他进修职位</a>";
					$("#processButton"+index).append(buttons);
					//医教科拒绝
				}else if('05'==content.status||'09'==content.status){
					$("#jdt_state"+index).width(146);
					$("#jdt_state"+index).css("background","#b5b5b6");
					$("#medEduApp"+index).html("未通过审核");
					$("#message"+index).html("很遗憾您的本次申请未能通过医院审批<br>请等待下次招生，或查看平台其他进修职位");
					$("#message"+index).css("color","#e1685c");
					var buttons="<a class='button cancle'>查看其他进修职位</a>";
					$("#processButton"+index).append(buttons);
					//用户通过
				}else if('06'==content.status){
					$("#jdt_state"+index).width("100%");
					$("#message"+index).html("您已确认参加本次进修，请等待医院发送正式录取通知，录取通知可通过站内信及邮件查找");
					$("#message"+index).css("color","#e1685c");
					var buttons="<a class='button cancle'>点击查看报道须知</a>";
					$("#processButton"+index).append(buttons);
					//用户拒绝
				}else if('07'==content.status){
					$("#jdt_state"+index).width("100%");
					$("#jdt_state"+index).css("background","#b5b5b6");
					
					$("#userConfirmed"+index).html("用户已拒绝");
					var buttons="<a class='button cancle'>查看其他进修职位</a>";
					$("#processButton"+index).append(buttons);
					//科室未审核
				}else if('08'==content.status){
					$("#jdt_state"+index).width(270);
					
					var buttons="<a class='button confirmdisable'>确认</a><a class='button cancle' onclick='cancelResume('"+content.resumeDeptSid+"')>取消申请</a>";
					$("#processButton"+index).append(buttons);
					//自动过滤
				}else if('11'==content.status){
					$("#jdt_state"+index).width(146);
					$("#jdt_state"+index).css("background","#b5b5b6");
					$("#medEduApp"+index).html("未通过审核");
					$("#message"+index).html("很遗憾您的本次申请未能通过医院审批<br>请等待下次招生，或查看平台其他进修职位");
					$("#message"+index).css("color","#e1685c");
					
					var buttons="<a class='button cancle'>查看其他进修职位</a>";
					$("#processButton"+index).append(buttons);
					//已发送用户确认
				}else if('12'==content.status){
					$("#jdt_state"+index).width(498);
//					$("#jdt_state"+index).css("background","#b5b5b6");
					
					var buttons="<a class='button confirm' onclick="+confirmClick+">确认</a><a class='button cancle' onclick="+cancelClick+">取消申请</a>";
					$("#processButton"+index).append(buttons);
					//已发送录取通知
				}else if('13'==content.status){
					var click="downAdmisNotice('"+content.deptSid+"')";
					$("#jdt_state"+index).width("100%");
					$("#message"+index).html("您已确认参加本次进修，请等待医院发送正式录取通知，录取通知可通过站内信及邮件查找");
					$("#message"+index).css("color","#e1685c");
					
					
					
					var downAdmisNotice="<a class='button cancle' onclick="+click+">下载录取通知书</a>";
					var buttons="<a class='button cancle'>点击查看报道须知</a>";
					//判断医教科是否上传录取通知书模板
					var flag=checkMedIsUploadAdmisNotice(content.deptSid);
					if(flag){
						$("#processButton"+index).append(downAdmisNotice);
					}
					$("#processButton"+index).append(buttons);
					
					//科室通过医教科拒绝
				}else if('14'==content.status){
					$("#jdt_state"+index).width(383);
					$("#jdt_state"+index).css("background","#b5b5b6");
					$("#message"+index).html("很遗憾您的本次申请未能通过医院审批<br>请等待下次招生，或查看平台其他进修职位");
					$("#message"+index).css("color","#e1685c");
					$("#medEduAgaApp"+index).html("未通过审核");
					var buttons="<a class='button cancle'>查看其他进修职位</a>";
					$("#processButton"+index).append(buttons);
				}
				});
			}
		});
}

//下载录取通知书
function downAdmisNotice(deptSid){
	window.location = ws_url + "/rest/upload/downloadAdmmisWord/"+deptSid;
}

//检查医教科是否上传模板
function checkMedIsUploadAdmisNotice(deptSid){
	var flag=false;
	Core.AjaxRequest({
		url :ws_url + "/rest/upload/checkMedIsUploadAdmisNotice/"+deptSid, 
		type:"GET",
		async:false,
		callback : function (data) {
			if("success"==data.status){
				flag= true;
			}
      } 
   });
	return flag;
}

//确认申请
function confirmResume(resDeptSid){
	var resDeptSidArray=new Array();
	resDeptSidArray.push(resDeptSid);
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/oprateResume", 
		type:"POST",
		params:{
			resumeDeptSids:resDeptSidArray,
			status:"06"
		},
		callback : function (data) {
			selectResumeProcess(null);	
      } 
   });
}
//取消申请
function cancelResume(resDeptSid){
	var resDeptSidArray=new Array();
	resDeptSidArray.push(resDeptSid);
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/oprateResume", 
		type:"POST",
		params:{
			resumeDeptSids:resDeptSidArray,
			status:"07"
		},
		callback : function (data) {
			selectResumeProcess(null);	
		} 
	});
}