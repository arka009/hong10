selectResumeByUserSid();
var resumeData=null;
//根据用户获取简历
function selectResumeByUserSid(){
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/getResumeByUserSid/"+userSid, 
		type:"GET",
		callback : function (data) {
			setThirdPageValues(data);
		}
	});
}

function addOtherCer(){
	otherIndex++;
	var click="uploadImage(this,'10','otherImage"+otherIndex+"')";
	var onchange="document.getElementById('otherPathDisplay"+otherIndex+"').value=this.files[0].name";
	var otherCerDiv="<div class='upload_part'>" +
						"<div class='photo fl'>" +
							"<a href=''><img id='otherImage"+otherIndex+"' src='"+ctx+"/img/pers_default_photo_upload.png' alt='' height='100px' width='86px'></a>" +
						"</div>" +
						"<div class='upload fr'>" +
						"<div class='upload_title_2'>" +
							"<span>其他相关证书</span>" +
						"</div>" +
						"<div class='file-box'>" +
							 "<input type='text' name='text_sm' id='otherPathDisplay"+otherIndex+"' class='txt' /> " +
							 "<input type='button' class='btn' value='浏览...' />" +
							 "<input type='file' name='file_sm' class='file' id='otherfile"+otherIndex+"' size='28' onchange="+onchange+" />" +
					 		" <input type='submit' name='submit' class='btn sbt' value='上传' onclick="+click+">" +
						"</div>" +
						"<div class='upload_bot'>" +
							"注：扫描件小于4M，支持jpg、gif、png格式" +
						"</div>" +
						"</div>"+
					"</div>";
	$("#otherCers").append(otherCerDiv);
};
var otherIndex=0;
//设置页面值
function setThirdPageValues(data){
	
	console.log(data);
	var resumeWp=data.resumeCerList;
	$.each(resumeWp,function(index,content){
		if('01'==content.cerType){
			$("#quaCerNum").val(content.cerNo);
			$("#quaCerGetDate").val(content.cerAwardDate);
			$("#imageQua").attr("src",content.cerPhoteUrl);
		}else if('02'==content.cerType){
			$("#proType").val(content.cerPraType);
			$("#proScope").val(content.cerPraScope);
			$("#proLocation").val(content.cerPraLocation);
			$("#proNum").val(content.cerNo);
			$("#proGetDate").val(content.cerAwardDate);
			$("#imageProNum").attr("src",content.cerPhoteUrl);
			
		}else if('03'==content.cerType){
			$("#imageProScope").attr("src",content.cerPhoteUrl);
		}else if('04'==content.cerType){
			$("#graduImage").attr("src",content.cerPhoteUrl);
		}else if('05'==content.cerType){
			$("#titleImage").attr("src",content.cerPhoteUrl);
		}else if('06'==content.cerType){
			$("#cardImage").attr("src",content.cerPhoteUrl);
		}else if('10'==content.cerType){
			otherIndex++;
			var click="uploadImage(this,'10','otherImage"+otherIndex+"')";
			var onchange="document.getElementById('otherPathDisplay"+otherIndex+"').value=this.files[0].name";
			var otherCerDiv="<div class='upload_part'>" +
								"<div class='photo fl'>" +
									"<a href=''><img id='otherImage"+otherIndex+"' src='"+ctx+"/img/pers_default_photo_upload.png' alt='' height='100px' width='86px'></a>" +
								"</div>" +
								"<div class='upload fr'>" +
								"<div class='upload_title_2'>" +
									"<span>其他相关证书</span>" +
								"</div>" +
								"<div class='file-box'>" +
									 "<input type='text' name='text_sm' id='otherPathDisplay"+otherIndex+"' class='txt' /> " +
									 "<input type='button' class='btn' value='浏览...' />" +
									 "<input type='file' name='file_sm' class='file' id='otherfile"+otherIndex+"' size='28' onchange="+onchange+" />" +
							 		" <input type='submit' name='submit' class='btn sbt' value='上传' onclick="+click+">" +
								"</div>" +
								"<div class='upload_bot'>" +
									"注：扫描件小于4M，支持jpg、gif、png格式" +
								"</div>" +
								"</div>"+
							"</div>";
			$("#otherCers").append(otherCerDiv);
			$("#otherImage"+otherIndex).attr("src",content.cerPhoteUrl);
		}
	});
	if(otherIndex==0){
		var click="uploadImage(this,'10','otherImage"+otherIndex+"')";
		var onchange="document.getElementById('otherPathDisplay"+otherIndex+"').value=this.files[0].name";
		var otherCerDiv="<div class='upload_part'>" +
							"<div class='photo fl'>" +
								"<a href=''><img id='otherImage"+otherIndex+"' src='"+ctx+"/img/pers_default_photo_upload.png' alt='' height='100px' width='86px'></a>" +
							"</div>" +
							"<div class='upload fr'>" +
							"<div class='upload_title_2'>" +
								"<span>其他相关证书</span>" +
							"</div>" +
							"<div class='file-box'>" +
								 "<input type='text' name='text_sm' id='otherPathDisplay"+otherIndex+"' class='txt' /> " +
								 "<input type='button' class='btn' value='浏览...' />" +
								 "<input type='file' name='file_sm' class='file' id='otherfile"+otherIndex+"' size='28' onchange="+onchange+" />" +
						 		" <input type='submit' name='submit' class='btn sbt' value='上传'onclick="+click+">" +
							"</div>" +
							"<div class='upload_bot'>" +
								"注：扫描件小于4M，支持jpg、gif、png格式" +
							"</div>" +
							"</div>"+
						"</div>";
		$("#otherCers").append(otherCerDiv);
	}
}

//上传图片
function uploadImage(obj,type,imageId){
	console.log($(obj).prev().val());
		//上传图片
		var fileId=$(obj).prev().attr("id");
		uploadImg(fileId,type,imageId);
};

var imageQua = null;
var imageProNum = null;
var imageProScope = null;
var graduImage = null;
var cardImage = null;
var titleImage = null;
function uploadImg(fileId,type,imageId){
	$.ajaxFileUpload({
			url:ws_url + "/rest/upload/uploadUserImage/"+type,
			secureuri:false,
			fileElementId:''+fileId+'',
			dataType: 'json',
			success: function (data, status){
				file = data.filesrc;
				if('01'==type){
					imageQua=file;
				}else if('02'==type){
					imageProNum=file;
				}else if('03'==type){
					imageProScope=file;
				}else if('04'==type){
					graduImage=file;
				}else if('05'==type){
					titleImage=file;
				}else if('06'==type){
					cardImage=file;
				}else if('06'==type){
					cardImage=file;
				}
				$("#"+imageId).attr("src",file);
			},
			error: function(data, status, e) {  
				alert(data.a);
				console.log(data);
                   alert("系统异常,请稍后再试!");  
               }
		}
	);
};

var resumeThirdPage=function(){
	var cerArray=new Array();
	var quaCer=new Object();
	quaCer.cerNo=$("#quaCerNum").val();
	quaCer.cerAwardDate=$("#quaCerGetDate").val();
	quaCer.cerPhoteUrl=$("#imageQua").attr("src");
	quaCer.cerType="01";
	cerArray.push(quaCer);
	
	var proCerNum=new Object();
	proCerNum.cerPraType=$("#proType").val();
	proCerNum.cerPraScope=$("#proScope").val();
	proCerNum.cerPraLocation=$("#proLocation").val();
	proCerNum.cerNo=$("#proNum").val();
	proCerNum.cerAwardDate=$("#proGetDate").val();
	proCerNum.cerType="02";
	proCerNum.cerPhoteUrl=$("#imageProNum").attr("src");
	cerArray.push(proCerNum);
	
	var proCerScope=new Object();
	proCerScope.cerPraType=$("#proType").val();
	proCerScope.cerPraScope=$("#proScope").val();
	proCerScope.cerPraLocation=$("#proLocation").val();
	proCerScope.cerNo=$("#proNum").val();
	proCerScope.cerAwardDate=$("#proGetDate").val();
	proCerScope.cerType="03";
	proCerScope.cerPhoteUrl=$("#imageProScope").attr("src");
	cerArray.push(proCerScope);
	
	var graCer=new Object();
	graCer.cerPhoteUrl=$("#graduImage").attr("src");
	graCer.cerType="04";
	cerArray.push(graCer);
	
	var titleCer=new Object();
	titleCer.cerPhoteUrl=$("#titleImage").attr("src");
	titleCer.cerType="05";
	cerArray.push(titleCer);
	
	var cardCer=new Object();
	cardCer.cerPhoteUrl=$("#cardImage").attr("src");
	cardCer.cerType="06";
	cerArray.push(cardCer);
	
	if(otherIndex>0){
		for(var i=0;i<otherIndex;i++){
			var otherCer=new Object();
			otherCer.cerPhoteUrl=$("#otherImage"+i).attr("src");
			otherCer.cerType="10";
			cerArray.push(otherCer);
		}
	}else{
		var otherCer=new Object();
		otherCer.cerPhoteUrl=$("#otherImage0").attr("src");
		otherCer.cerType="10";
		cerArray.push(otherCer);
	}
	
	this.resumeCerList=cerArray;
};

function saveThirdPageValue(){
	var resumeThird=new resumeThirdPage();
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/insOrUpdResume", 
		type:"POST",
		params:resumeThird,
		callback : function (data) {
			//跳转第二页
			var thirdData={"resumeThirdValue":JSON.stringify(resumeThird.resumeCerList)};
			$("#perContent").load("pers/pers_upload_file_3.jsp",thirdData);
		}
	});
}