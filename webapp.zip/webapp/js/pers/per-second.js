
//selectHosLevelCode();
//selectWorkTitleCode();
//selectWorkDutyCode();
//selectWorkExpCode();
//selectWorkExpCode();
selectResumeByUserSid();
var resumeData=null;
//根据用户获取简历
function selectResumeByUserSid(){
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/getResumeByUserSid/"+userSid, 
		type:"GET",
		callback : function (data) {
			setSecondPageValues(data);
		}
	});
}
var wpIndex=0;
function addWp(){
		wpIndex++;
		var cutOff='{"cutOff":12}';
		var ul="<ul>" +
		"<li>" +
			"<p><i>工作单位</i></p>" +
			"<div class='pers_div'>" +
			"<input type='text' name='' id='oldHosName"+wpIndex+"'/>" +
			"</div>" +
		"</li>" +
		"<li>" +
			"<p><i>科室名称</i></p>" +
			"<div class='pers_div'>" +
			"<input type='text' name='' id='oldDeptName"+wpIndex+"'/>" +
			"</div>" +
		"</li>" +
		"<li class='admission_date'>" +
			"<p><i>开始日期</i></p>" +
			"<div class='pers_div'>" +
				"<select tabindex='6' class='dropdown sel_option' id='workBeginDateYear"+wpIndex+"' data-settings="+cutOff+" >" +
				"<option value='2015'>2015</option>"+
				"<option value='2014'>2014</option>"+
				"<option value='2013'>2013</option>"+
				"<option value='2012'>2012</option>"+
				"<option value='2011'>2011</option>"+
				"<option value='2010'>2010</option>"+
				"<option value='2009'>2009</option>"+
				"<option value='2008'>2008</option>"+
				"<option value='2007'>2007</option>"+
				"<option value='2006'>2006</option>"+
				"<option value='2005'>2005</option>"+
				"<option value='2004'>2004</option>"+
				"<option value='2003'>2003</option>"+
				"<option value='2002'>2002</option>"+
				"<option value='2001'>2001</option>"+
				"<option value='2000'>2000</option>"+
				"<option value='1999'>1999</option>"+
				"<option value='1998'>1998</option>"+
				"<option value='1997'>1997</option>"+
				"<option value='1996'>1996</option>"+
				"<option value='1995'>1995</option>"+
				"<option value='1994'>1994</option>"+
				"<option value='1993'>1993</option>"+
				"<option value='1992'>1992</option>"+
				"<option value='1991'>1991</option>"+
				"<option value='1990'>1990</option>"+
				"<option value='1989'>1989</option>"+
				"<option value='1988'>1988</option>"+
				"<option value='1987'>1987</option>"+
				"<option value='1986'>1986</option>"+
				"<option value='1985'>1985</option>"+
				"<option value='1984'>1984</option>"+
				"<option value='1983'>1983</option>"+
				"<option value='1982'>1982</option>"+
				"<option value='1981'>1981</option>"+
				"<option value='1980'>1980</option>"+
			"</select>" +
			"</div>" +
			"<div class='pers_div'>" +
				"<select tabindex='6' class='dropdown sel_option' id='workBeginDateMonth"+wpIndex+"' data-settings="+cutOff+" >" +
				"<option value='1'>1</option>"+
				"<option value='2'>2</option>"+
				"<option value='3'>3</option>"+
				"<option value='4'>4</option>"+
				"<option value='5'>5</option>"+
				"<option value='6'>6</option>"+
				"<option value='7'>7</option>"+
				"<option value='8'>8</option>"+
				"<option value='9'>9</option>"+
				"<option value='10'>10</option>"+
				"<option value='11'>11</option>"+
				"<option value='12'>12</option>"+
			"</select>" +
			"</div>" +
			"<p><i>结束日期</i></p>" +
			"<div class='pers_div'>" +
				"<select tabindex='6' class='dropdown sel_option' id='workEndDateYear"+wpIndex+"' data-settings="+cutOff+" >" +
				"<option value='2015'>2015</option>"+
				"<option value='2014'>2014</option>"+
				"<option value='2013'>2013</option>"+
				"<option value='2012'>2012</option>"+
				"<option value='2011'>2011</option>"+
				"<option value='2010'>2010</option>"+
				"<option value='2009'>2009</option>"+
				"<option value='2008'>2008</option>"+
				"<option value='2007'>2007</option>"+
				"<option value='2006'>2006</option>"+
				"<option value='2005'>2005</option>"+
				"<option value='2004'>2004</option>"+
				"<option value='2003'>2003</option>"+
				"<option value='2002'>2002</option>"+
				"<option value='2001'>2001</option>"+
				"<option value='2000'>2000</option>"+
				"<option value='1999'>1999</option>"+
				"<option value='1998'>1998</option>"+
				"<option value='1997'>1997</option>"+
				"<option value='1996'>1996</option>"+
				"<option value='1995'>1995</option>"+
				"<option value='1994'>1994</option>"+
				"<option value='1993'>1993</option>"+
				"<option value='1992'>1992</option>"+
				"<option value='1991'>1991</option>"+
				"<option value='1990'>1990</option>"+
				"<option value='1989'>1989</option>"+
				"<option value='1988'>1988</option>"+
				"<option value='1987'>1987</option>"+
				"<option value='1986'>1986</option>"+
				"<option value='1985'>1985</option>"+
				"<option value='1984'>1984</option>"+
				"<option value='1983'>1983</option>"+
				"<option value='1982'>1982</option>"+
				"<option value='1981'>1981</option>"+
				"<option value='1980'>1980</option>"+
			"</select>" +
			"</div>" +
			"<div class='pers_div'>" +
				"<select tabindex='6' class='dropdown sel_option' id='workEndDateMonth"+wpIndex+"' data-settings="+cutOff+" >" +
				"<option value='1'>1</option>"+
				"<option value='2'>2</option>"+
				"<option value='3'>3</option>"+
				"<option value='4'>4</option>"+
				"<option value='5'>5</option>"+
				"<option value='6'>6</option>"+
				"<option value='7'>7</option>"+
				"<option value='8'>8</option>"+
				"<option value='9'>9</option>"+
				"<option value='10'>10</option>"+
				"<option value='11'>11</option>"+
				"<option value='12'>12</option>"+
			"</select>" +
			"</div>" +
		"</li>" +
	"</ul>";
	$("#oldWorkExp").append(ul);
};

//查询医院等级
function selectHosLevelCode(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/HOSPITAL_LEVEL", 
		type:"GET",
		callback : function (data) {
			$.each(data,function(index,content){
				var option=$("<option value='"+content.codeValue+"' class='label'>"+content.codeDisplay+"</option>");
				$("#currentHosLevel").append(option);
			});
		}
	});
}

//查询职称
function selectWorkTitleCode(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/WORK_TITLE", 
		type:"GET",
		callback : function (data) {
			$.each(data,function(index,content){
				var option=$("<option value='"+content.codeValue+"' class='label'>"+content.codeDisplay+"</option>");
				$("#workTitle").append(option);
			});
		}
	});
}

//查询职务
function selectWorkDutyCode(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/WORK_DUTY", 
		type:"GET",
		callback : function (data) {
			$.each(data,function(index,content){
				var option=$("<option value='"+content.codeValue+"' class='label'>"+content.codeDisplay+"</option>");
				$("#workDuty").append(option);
			});
		}
	});
}	
//查询工作年限
function selectWorkExpCode(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/WORK_EXPERISE", 
		type:"GET",
		callback : function (data) {
			$.each(data,function(index,content){
				var option=$("<option value='"+content.codeValue+"' class='label'>"+content.codeDisplay+"</option>");
				$("#workExp").append(option);
			});
		}
	});
}

//设置简历第二页值
function setSecondPageValues(data){
	var resumeWp=data.resumeWPList;
	$("#learnPurposeRequire").val(data.learnPurposeRequire);
	$("#currentState").val(data.currentState);
	var cutOff='{"cutOff":12}';
	if(resumeWp!=null&&resumeWp.length>0){
		$.each(resumeWp,function(index,content){
			if('current'==content.workEndDate){
				$("#currentHosName").val(content.hospitalName);
				$("#currentHosLevel").val('02');
				$("#currentMedEduMobile").val(content.medEduTelephone);
				$("#currentMedEduMobile").val(content.medEduTelephone);
				$("#currentDeptName").val(content.partName);
				$("#currentDeptBedNum").val(content.deptBedNum);
				$("#detpMobile").val(content.deptTelephone);
				$("#workDuty").val(content.workDuty);
				$("#workTitle").val(content.hospitalTitle);
				
				var titleGetDate=content.dutyGetDate;
				var getYearIndex=titleGetDate.indexOf("年");
				var getMonthIndex=titleGetDate.indexOf("月");
				var getYear=titleGetDate.substring(0,getYearIndex);
				var getinMonth=titleGetDate.substring(getYearIndex+1,getMonthIndex);
				$("#titleGetDateYear").val(getYear);
				$("#titleGetDateMonth").val(getinMonth);
				
				var workBeginDate=content.workBeginDate;
				var beginYearIndex=workBeginDate.indexOf("年");
				var beginMonthIndex=workBeginDate.indexOf("月");
				var beginYear=workBeginDate.substring(0,beginYearIndex);
				var beginMonth=workBeginDate.substring(beginYearIndex+1,beginMonthIndex);
				$("#workBeginDateYear").val(beginYear);
				$("#workBeginDateMonth").val(beginMonth);
				$("#workExp").val(content.workMajorLength);
				if(resumeWp.length==1){
					var ul="<ul>" +
					"<li>" +
						"<p><i>工作单位</i></p>" +
						"<div class='pers_div'>" +
						"<input type='text' name='' id='oldHosName0'/>" +
						"</div>" +
					"</li>" +
					"<li>" +
						"<p><i>科室名称</i></p>" +
						"<div class='pers_div'>" +
						"<input type='text' name='' id='oldDeptName0'/>" +
						"</div>" +
					"</li>" +
					"<li class='admission_date'>" +
						"<p><i>开始日期</i></p>" +
						"<div class='pers_div'>" +
							"<select tabindex='6' class='dropdown sel_option' id='workBeginDateYear0' data-settings="+cutOff+" >" +
							"<option value='2015'>2015</option>"+
							"<option value='2014'>2014</option>"+
							"<option value='2013'>2013</option>"+
							"<option value='2012'>2012</option>"+
							"<option value='2011'>2011</option>"+
							"<option value='2010'>2010</option>"+
							"<option value='2009'>2009</option>"+
							"<option value='2008'>2008</option>"+
							"<option value='2007'>2007</option>"+
							"<option value='2006'>2006</option>"+
							"<option value='2005'>2005</option>"+
							"<option value='2004'>2004</option>"+
							"<option value='2003'>2003</option>"+
							"<option value='2002'>2002</option>"+
							"<option value='2001'>2001</option>"+
							"<option value='2000'>2000</option>"+
							"<option value='1999'>1999</option>"+
							"<option value='1998'>1998</option>"+
							"<option value='1997'>1997</option>"+
							"<option value='1996'>1996</option>"+
							"<option value='1995'>1995</option>"+
							"<option value='1994'>1994</option>"+
							"<option value='1993'>1993</option>"+
							"<option value='1992'>1992</option>"+
							"<option value='1991'>1991</option>"+
							"<option value='1990'>1990</option>"+
							"<option value='1989'>1989</option>"+
							"<option value='1988'>1988</option>"+
							"<option value='1987'>1987</option>"+
							"<option value='1986'>1986</option>"+
							"<option value='1985'>1985</option>"+
							"<option value='1984'>1984</option>"+
							"<option value='1983'>1983</option>"+
							"<option value='1982'>1982</option>"+
							"<option value='1981'>1981</option>"+
							"<option value='1980'>1980</option>"+
						"</select>" +
						"</div>" +
						"<div class='pers_div'>" +
							"<select tabindex='6' class='dropdown sel_option' id='workBeginDateMonth0' data-settings="+cutOff+" >" +
							"<option value='1'>1</option>"+
							"<option value='2'>2</option>"+
							"<option value='3'>3</option>"+
							"<option value='4'>4</option>"+
							"<option value='5'>5</option>"+
							"<option value='6'>6</option>"+
							"<option value='7'>7</option>"+
							"<option value='8'>8</option>"+
							"<option value='9'>9</option>"+
							"<option value='10'>10</option>"+
							"<option value='11'>11</option>"+
							"<option value='12'>12</option>"+
						"</select>" +
						"</div>" +
						"<p><i>结束日期</i></p>" +
						"<div class='pers_div'>" +
							"<select tabindex='6' class='dropdown sel_option' id='workEndDateYear0' data-settings="+cutOff+" >" +
							"<option value='2015'>2015</option>"+
							"<option value='2014'>2014</option>"+
							"<option value='2013'>2013</option>"+
							"<option value='2012'>2012</option>"+
							"<option value='2011'>2011</option>"+
							"<option value='2010'>2010</option>"+
							"<option value='2009'>2009</option>"+
							"<option value='2008'>2008</option>"+
							"<option value='2007'>2007</option>"+
							"<option value='2006'>2006</option>"+
							"<option value='2005'>2005</option>"+
							"<option value='2004'>2004</option>"+
							"<option value='2003'>2003</option>"+
							"<option value='2002'>2002</option>"+
							"<option value='2001'>2001</option>"+
							"<option value='2000'>2000</option>"+
							"<option value='1999'>1999</option>"+
							"<option value='1998'>1998</option>"+
							"<option value='1997'>1997</option>"+
							"<option value='1996'>1996</option>"+
							"<option value='1995'>1995</option>"+
							"<option value='1994'>1994</option>"+
							"<option value='1993'>1993</option>"+
							"<option value='1992'>1992</option>"+
							"<option value='1991'>1991</option>"+
							"<option value='1990'>1990</option>"+
							"<option value='1989'>1989</option>"+
							"<option value='1988'>1988</option>"+
							"<option value='1987'>1987</option>"+
							"<option value='1986'>1986</option>"+
							"<option value='1985'>1985</option>"+
							"<option value='1984'>1984</option>"+
							"<option value='1983'>1983</option>"+
							"<option value='1982'>1982</option>"+
							"<option value='1981'>1981</option>"+
							"<option value='1980'>1980</option>"+
						"</select>" +
						"</div>" +
						"<div class='pers_div'>" +
							"<select tabindex='6' class='dropdown sel_option' id='workEndDateMonth0' data-settings="+cutOff+" >" +
							"<option value='1'>1</option>"+
							"<option value='2'>2</option>"+
							"<option value='3'>3</option>"+
							"<option value='4'>4</option>"+
							"<option value='5'>5</option>"+
							"<option value='6'>6</option>"+
							"<option value='7'>7</option>"+
							"<option value='8'>8</option>"+
							"<option value='9'>9</option>"+
							"<option value='10'>10</option>"+
							"<option value='11'>11</option>"+
							"<option value='12'>12</option>"+
						"</select>" +
						"</div>" +
					"</li>" +
				"</ul>";
				$("#oldWorkExp").append(ul);
				}
				return false;
			}
		});
				if(resumeWp!=null&&resumeWp.length>0){
					var wpadd=0;
					$.each(resumeWp,function(index,content){
						if('current'!=content.workEndDate){
						var ul="<ul>" +
						"<li>" +
							"<p><i>工作单位</i></p>" +
							"<div class='pers_div'>" +
							"<input type='text' name='' id='oldHosName"+wpadd+"'>" +
							"</div>" +
						"</li>" +
						"<li>" +
							"<p><i>科室名称</i></p>" +
							"<div class='pers_div'>" +
							"<input type='text' name='' id='oldDeptName"+wpadd+"'>" +
							"</div>" +
						"</li>" +
						"<li class='admission_date'>" +
							"<p><i>开始日期</i></p>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown sel_option' id='workBeginDateYear"+wpadd+"' data-settings="+cutOff+" >" +
								"<option value='2015'>2015</option>"+
								"<option value='2014'>2014</option>"+
								"<option value='2013'>2013</option>"+
								"<option value='2012'>2012</option>"+
								"<option value='2011'>2011</option>"+
								"<option value='2010'>2010</option>"+
								"<option value='2009'>2009</option>"+
								"<option value='2008'>2008</option>"+
								"<option value='2007'>2007</option>"+
								"<option value='2006'>2006</option>"+
								"<option value='2005'>2005</option>"+
								"<option value='2004'>2004</option>"+
								"<option value='2003'>2003</option>"+
								"<option value='2002'>2002</option>"+
								"<option value='2001'>2001</option>"+
								"<option value='2000'>2000</option>"+
								"<option value='1999'>1999</option>"+
								"<option value='1998'>1998</option>"+
								"<option value='1997'>1997</option>"+
								"<option value='1996'>1996</option>"+
								"<option value='1995'>1995</option>"+
								"<option value='1994'>1994</option>"+
								"<option value='1993'>1993</option>"+
								"<option value='1992'>1992</option>"+
								"<option value='1991'>1991</option>"+
								"<option value='1990'>1990</option>"+
								"<option value='1989'>1989</option>"+
								"<option value='1988'>1988</option>"+
								"<option value='1987'>1987</option>"+
								"<option value='1986'>1986</option>"+
								"<option value='1985'>1985</option>"+
								"<option value='1984'>1984</option>"+
								"<option value='1983'>1983</option>"+
								"<option value='1982'>1982</option>"+
								"<option value='1981'>1981</option>"+
								"<option value='1980'>1980</option>"+
							"</select>" +
							"</div>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown sel_option' id='workBeginDateMonth"+wpadd+"' data-settings="+cutOff+" >" +
								"<option value='1'>1</option>"+
								"<option value='2'>2</option>"+
								"<option value='3'>3</option>"+
								"<option value='4'>4</option>"+
								"<option value='5'>5</option>"+
								"<option value='6'>6</option>"+
								"<option value='7'>7</option>"+
								"<option value='8'>8</option>"+
								"<option value='9'>9</option>"+
								"<option value='10'>10</option>"+
								"<option value='11'>11</option>"+
								"<option value='12'>12</option>"+
							"</select>" +
							"</div>" +
							"<p><i>结束日期</i></p>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown sel_option' id='workEndDateYear"+wpadd+"' data-settings="+cutOff+" >" +
								"<option value='2015'>2015</option>"+
								"<option value='2014'>2014</option>"+
								"<option value='2013'>2013</option>"+
								"<option value='2012'>2012</option>"+
								"<option value='2011'>2011</option>"+
								"<option value='2010'>2010</option>"+
								"<option value='2009'>2009</option>"+
								"<option value='2008'>2008</option>"+
								"<option value='2007'>2007</option>"+
								"<option value='2006'>2006</option>"+
								"<option value='2005'>2005</option>"+
								"<option value='2004'>2004</option>"+
								"<option value='2003'>2003</option>"+
								"<option value='2002'>2002</option>"+
								"<option value='2001'>2001</option>"+
								"<option value='2000'>2000</option>"+
								"<option value='1999'>1999</option>"+
								"<option value='1998'>1998</option>"+
								"<option value='1997'>1997</option>"+
								"<option value='1996'>1996</option>"+
								"<option value='1995'>1995</option>"+
								"<option value='1994'>1994</option>"+
								"<option value='1993'>1993</option>"+
								"<option value='1992'>1992</option>"+
								"<option value='1991'>1991</option>"+
								"<option value='1990'>1990</option>"+
								"<option value='1989'>1989</option>"+
								"<option value='1988'>1988</option>"+
								"<option value='1987'>1987</option>"+
								"<option value='1986'>1986</option>"+
								"<option value='1985'>1985</option>"+
								"<option value='1984'>1984</option>"+
								"<option value='1983'>1983</option>"+
								"<option value='1982'>1982</option>"+
								"<option value='1981'>1981</option>"+
								"<option value='1980'>1980</option>"+
							"</select>" +
							"</div>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown sel_option' id='workEndDateMonth"+wpadd+"' data-settings="+cutOff+" >" +
								"<option value='1'>1</option>"+
								"<option value='2'>2</option>"+
								"<option value='3'>3</option>"+
								"<option value='4'>4</option>"+
								"<option value='5'>5</option>"+
								"<option value='6'>6</option>"+
								"<option value='7'>7</option>"+
								"<option value='8'>8</option>"+
								"<option value='9'>9</option>"+
								"<option value='10'>10</option>"+
								"<option value='11'>11</option>"+
								"<option value='12'>12</option>"+
							"</select>" +
							"</div>" +
						"</li>" +
					"</ul>";
						$("#oldWorkExp").append(ul);
						$("#oldHosName"+wpadd).val(content.hospitalName);
						$("#oldDeptName"+wpadd).val(content.partName);
						
						
						var workBeginDate=content.workBeginDate;
						var beginYearIndex=workBeginDate.indexOf("年");
						var beginMonthIndex=workBeginDate.indexOf("月");
						var beginYear=workBeginDate.substring(0,beginYearIndex);
						var beginMonth=workBeginDate.substring(beginYearIndex+1,beginMonthIndex);
						$("#workBeginDateYear"+wpadd).val(beginYear);
						$("#workBeginDateMonth"+wpadd).val(beginMonth);

						var workEndDate=content.workEndDate;
						var endYearIndex=workEndDate.indexOf("年");
						var endMonthIndex=workEndDate.indexOf("月");
						var endYear=workEndDate.substring(0,endYearIndex);
						var endinMonth=workEndDate.substring(endYearIndex+1,endMonthIndex);
						$("#workEndDateYear"+wpadd).val(endYear);
						$("#workEndDateMonth"+wpadd).val(endinMonth);
						wpadd++;
						}
					});
					wpIndex=wpadd;
				}else{
					var ul="<ul>" +
					"<li>" +
						"<p><i>工作单位</i></p>" +
						"<div class='pers_div'>" +
						"<input type='text' name='' id='oldHosName0'/>" +
						"</div>" +
					"</li>" +
					"<li>" +
						"<p><i>科室名称</i></p>" +
						"<div class='pers_div'>" +
						"<input type='text' name='' id='oldDeptName0'/>" +
						"</div>" +
					"</li>" +
					"<li class='admission_date'>" +
						"<p><i>开始日期</i></p>" +
						"<div class='pers_div'>" +
							"<select tabindex='6' class='dropdown sel_option' id='workBeginDateYear0' data-settings="+cutOff+" >" +
							"<option value='2015'>2015</option>"+
							"<option value='2014'>2014</option>"+
							"<option value='2013'>2013</option>"+
							"<option value='2012'>2012</option>"+
							"<option value='2011'>2011</option>"+
							"<option value='2010'>2010</option>"+
							"<option value='2009'>2009</option>"+
							"<option value='2008'>2008</option>"+
							"<option value='2007'>2007</option>"+
							"<option value='2006'>2006</option>"+
							"<option value='2005'>2005</option>"+
							"<option value='2004'>2004</option>"+
							"<option value='2003'>2003</option>"+
							"<option value='2002'>2002</option>"+
							"<option value='2001'>2001</option>"+
							"<option value='2000'>2000</option>"+
							"<option value='1999'>1999</option>"+
							"<option value='1998'>1998</option>"+
							"<option value='1997'>1997</option>"+
							"<option value='1996'>1996</option>"+
							"<option value='1995'>1995</option>"+
							"<option value='1994'>1994</option>"+
							"<option value='1993'>1993</option>"+
							"<option value='1992'>1992</option>"+
							"<option value='1991'>1991</option>"+
							"<option value='1990'>1990</option>"+
							"<option value='1989'>1989</option>"+
							"<option value='1988'>1988</option>"+
							"<option value='1987'>1987</option>"+
							"<option value='1986'>1986</option>"+
							"<option value='1985'>1985</option>"+
							"<option value='1984'>1984</option>"+
							"<option value='1983'>1983</option>"+
							"<option value='1982'>1982</option>"+
							"<option value='1981'>1981</option>"+
							"<option value='1980'>1980</option>"+
						"</select>" +
						"</div>" +
						"<div class='pers_div'>" +
							"<select tabindex='6' class='dropdown sel_option' id='workBeginDateMonth0' data-settings="+cutOff+" >" +
							"<option value='1'>1</option>"+
							"<option value='2'>2</option>"+
							"<option value='3'>3</option>"+
							"<option value='4'>4</option>"+
							"<option value='5'>5</option>"+
							"<option value='6'>6</option>"+
							"<option value='7'>7</option>"+
							"<option value='8'>8</option>"+
							"<option value='9'>9</option>"+
							"<option value='10'>10</option>"+
							"<option value='11'>11</option>"+
							"<option value='12'>12</option>"+
						"</select>" +
						"</div>" +
						"<p><i>结束日期</i></p>" +
						"<div class='pers_div'>" +
							"<select tabindex='6' class='dropdown sel_option' id='workEndDateYear0' data-settings="+cutOff+" >" +
							"<option value='2015'>2015</option>"+
							"<option value='2014'>2014</option>"+
							"<option value='2013'>2013</option>"+
							"<option value='2012'>2012</option>"+
							"<option value='2011'>2011</option>"+
							"<option value='2010'>2010</option>"+
							"<option value='2009'>2009</option>"+
							"<option value='2008'>2008</option>"+
							"<option value='2007'>2007</option>"+
							"<option value='2006'>2006</option>"+
							"<option value='2005'>2005</option>"+
							"<option value='2004'>2004</option>"+
							"<option value='2003'>2003</option>"+
							"<option value='2002'>2002</option>"+
							"<option value='2001'>2001</option>"+
							"<option value='2000'>2000</option>"+
							"<option value='1999'>1999</option>"+
							"<option value='1998'>1998</option>"+
							"<option value='1997'>1997</option>"+
							"<option value='1996'>1996</option>"+
							"<option value='1995'>1995</option>"+
							"<option value='1994'>1994</option>"+
							"<option value='1993'>1993</option>"+
							"<option value='1992'>1992</option>"+
							"<option value='1991'>1991</option>"+
							"<option value='1990'>1990</option>"+
							"<option value='1989'>1989</option>"+
							"<option value='1988'>1988</option>"+
							"<option value='1987'>1987</option>"+
							"<option value='1986'>1986</option>"+
							"<option value='1985'>1985</option>"+
							"<option value='1984'>1984</option>"+
							"<option value='1983'>1983</option>"+
							"<option value='1982'>1982</option>"+
							"<option value='1981'>1981</option>"+
							"<option value='1980'>1980</option>"+
						"</select>" +
						"</div>" +
						"<div class='pers_div'>" +
							"<select tabindex='6' class='dropdown sel_option' id='workEndDateMonth0' data-settings="+cutOff+" >" +
							"<option value='1'>1</option>"+
							"<option value='2'>2</option>"+
							"<option value='3'>3</option>"+
							"<option value='4'>4</option>"+
							"<option value='5'>5</option>"+
							"<option value='6'>6</option>"+
							"<option value='7'>7</option>"+
							"<option value='8'>8</option>"+
							"<option value='9'>9</option>"+
							"<option value='10'>10</option>"+
							"<option value='11'>11</option>"+
							"<option value='12'>12</option>"+
						"</select>" +
						"</div>" +
					"</li>" +
				"</ul>";
				$("#oldWorkExp").append(ul);
				}
	}else{
		var ul="<ul>" +
		"<li>" +
			"<p><i>工作单位</i></p>" +
			"<div class='pers_div'>" +
			"<input type='text' name='' id='oldHosName0'/>" +
			"</div>" +
		"</li>" +
		"<li>" +
			"<p><i>科室名称</i></p>" +
			"<div class='pers_div'>" +
			"<input type='text' name='' id='oldDeptName0'/>" +
			"</div>" +
		"</li>" +
		"<li class='admission_date'>" +
			"<p><i>开始日期</i></p>" +
			"<div class='pers_div'>" +
				"<select tabindex='6' class='dropdown sel_option' id='workBeginDateYear0' data-settings="+cutOff+" >" +
				"<option value='2015'>2015</option>"+
				"<option value='2014'>2014</option>"+
				"<option value='2013'>2013</option>"+
				"<option value='2012'>2012</option>"+
				"<option value='2011'>2011</option>"+
				"<option value='2010'>2010</option>"+
				"<option value='2009'>2009</option>"+
				"<option value='2008'>2008</option>"+
				"<option value='2007'>2007</option>"+
				"<option value='2006'>2006</option>"+
				"<option value='2005'>2005</option>"+
				"<option value='2004'>2004</option>"+
				"<option value='2003'>2003</option>"+
				"<option value='2002'>2002</option>"+
				"<option value='2001'>2001</option>"+
				"<option value='2000'>2000</option>"+
				"<option value='1999'>1999</option>"+
				"<option value='1998'>1998</option>"+
				"<option value='1997'>1997</option>"+
				"<option value='1996'>1996</option>"+
				"<option value='1995'>1995</option>"+
				"<option value='1994'>1994</option>"+
				"<option value='1993'>1993</option>"+
				"<option value='1992'>1992</option>"+
				"<option value='1991'>1991</option>"+
				"<option value='1990'>1990</option>"+
				"<option value='1989'>1989</option>"+
				"<option value='1988'>1988</option>"+
				"<option value='1987'>1987</option>"+
				"<option value='1986'>1986</option>"+
				"<option value='1985'>1985</option>"+
				"<option value='1984'>1984</option>"+
				"<option value='1983'>1983</option>"+
				"<option value='1982'>1982</option>"+
				"<option value='1981'>1981</option>"+
				"<option value='1980'>1980</option>"+
			"</select>" +
			"</div>" +
			"<div class='pers_div'>" +
				"<select tabindex='6' class='dropdown sel_option' id='workBeginDateMonth0' data-settings="+cutOff+" >" +
				"<option value='1'>1</option>"+
				"<option value='2'>2</option>"+
				"<option value='3'>3</option>"+
				"<option value='4'>4</option>"+
				"<option value='5'>5</option>"+
				"<option value='6'>6</option>"+
				"<option value='7'>7</option>"+
				"<option value='8'>8</option>"+
				"<option value='9'>9</option>"+
				"<option value='10'>10</option>"+
				"<option value='11'>11</option>"+
				"<option value='12'>12</option>"+
			"</select>" +
			"</div>" +
			"<p><i>结束日期</i></p>" +
			"<div class='pers_div'>" +
				"<select tabindex='6' class='dropdown sel_option' id='workEndDateYear0' data-settings="+cutOff+" >" +
				"<option value='2015'>2015</option>"+
				"<option value='2014'>2014</option>"+
				"<option value='2013'>2013</option>"+
				"<option value='2012'>2012</option>"+
				"<option value='2011'>2011</option>"+
				"<option value='2010'>2010</option>"+
				"<option value='2009'>2009</option>"+
				"<option value='2008'>2008</option>"+
				"<option value='2007'>2007</option>"+
				"<option value='2006'>2006</option>"+
				"<option value='2005'>2005</option>"+
				"<option value='2004'>2004</option>"+
				"<option value='2003'>2003</option>"+
				"<option value='2002'>2002</option>"+
				"<option value='2001'>2001</option>"+
				"<option value='2000'>2000</option>"+
				"<option value='1999'>1999</option>"+
				"<option value='1998'>1998</option>"+
				"<option value='1997'>1997</option>"+
				"<option value='1996'>1996</option>"+
				"<option value='1995'>1995</option>"+
				"<option value='1994'>1994</option>"+
				"<option value='1993'>1993</option>"+
				"<option value='1992'>1992</option>"+
				"<option value='1991'>1991</option>"+
				"<option value='1990'>1990</option>"+
				"<option value='1989'>1989</option>"+
				"<option value='1988'>1988</option>"+
				"<option value='1987'>1987</option>"+
				"<option value='1986'>1986</option>"+
				"<option value='1985'>1985</option>"+
				"<option value='1984'>1984</option>"+
				"<option value='1983'>1983</option>"+
				"<option value='1982'>1982</option>"+
				"<option value='1981'>1981</option>"+
				"<option value='1980'>1980</option>"+
			"</select>" +
			"</div>" +
			"<div class='pers_div'>" +
				"<select tabindex='6' class='dropdown sel_option' id='workEndDateMonth0' data-settings="+cutOff+" >" +
				"<option value='1'>1</option>"+
				"<option value='2'>2</option>"+
				"<option value='3'>3</option>"+
				"<option value='4'>4</option>"+
				"<option value='5'>5</option>"+
				"<option value='6'>6</option>"+
				"<option value='7'>7</option>"+
				"<option value='8'>8</option>"+
				"<option value='9'>9</option>"+
				"<option value='10'>10</option>"+
				"<option value='11'>11</option>"+
				"<option value='12'>12</option>"+
			"</select>" +
			"</div>" +
		"</li>" +
	"</ul>";
	$("#oldWorkExp").append(ul);
	}
}


var resumeSecondPage=function(){
	var wpArray=new Array();
	var currentWp=new Object();
	currentWp.hospitalName=$("#currentHosName").val();
	currentWp.hospitalLevel=$("#currentHosLevel").val();
	currentWp.medEduTelephone=$("#currentMedEduMobile").val();
	currentWp.partName=$("#currentDeptName").val();
	currentWp.deptBedNum=$("#currentDeptBedNum").val();
	currentWp.deptTelephone=$("#detpMobile").val();
	currentWp.workDuty=$("#workDuty").val();
	currentWp.hospitalTitle=$("#workTitle").val();
	currentWp.dutyGetDate=$("#titleGetDateYear").val()+"年"+$("#titleGetDateMonth").val()+"月";
	currentWp.workBeginDate=$("#workBeginDateYear").val()+"年"+$("#workBeginDateMonth").val()+"月";
	currentWp.workEndDate='current';
	currentWp.workMajorLength=$("#workExp").val();
	wpArray.push(currentWp);
	
	if(wpIndex>0){
		for(var i=0;i<wpIndex;i++){
			var wp=new Object();
			wp.hospitalName=$("#oldHosName"+i).val();
			wp.partName=$("#oldDeptName"+i).val();
			wp.workBeginDate=$("#workBeginDateYear"+i).val()+"年"+$("#workBeginDateMonth"+i).val()+"月";
			wp.workEndDate=$("#workEndDateYear"+i).val()+"年"+$("#workEndDateMonth"+i).val()+"月";
			wpArray.push(wp);
		}
	}else{
		var wp=new Object();
		wp.hospitalName=$("#oldHosName0").val();
		wp.partName=$("#oldDeptName0").val();
		wp.workBeginDate=$("#workBeginDateYear0").val()+"年"+$("#workBeginDateMonth"+i).val()+"月";
		wp.workEndDate=$("#workEndDateYear0").val()+"年"+$("#workEndDateMonth"+i).val()+"月";
		wpArray.push(wp);
	}
	this.resumeWPList=wpArray;
	this.learnPurposeRequire=$("#learnPurposeRequire").val();
	this.currentState=$("#currentState").val();
};

function saveSecondPageValue(){
	var resumeSecond=new resumeSecondPage();
	console.log(resumeSecond);
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/insOrUpdResume", 
		type:"POST",
		params:resumeSecond,
		callback : function (data) {
//			alert(1);
			//跳转第二页
			$("#perContent").load("pers/pers_upload_file_2.jsp");
		}
	});
}