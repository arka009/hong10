$(function(){	
		
	
		/*$('input[type=checkbox]').tzCheckbox({labels:['Enable','Disable']});
	*/	
		//初始化滑动div
	/*	loadSwitchBox('.boxwrap',loadData,'#sub-frameMain','tab_1.html');*/
	
	
//个人中心-站内消息 展开、收缩功能	
	
	var persflag=true;
	$(".station_info .title").bind("click",function(){
		if(persflag){
			$(this).next(".con").slideUp(200);
			$(this).children("strong").css({
				"background":"url(../../img/pers_sj.png) no-repeat right -45px"
			});
			
			persflag=false;
		}else{
			$(this).next(".con").slideDown(200);
			$(this).children("strong").css({
				"background":"url(../../img/pers_sj.png) no-repeat right 15px"
			});
			persflag=true;
		}
		
	});
	

    $(".title_show").each(function(){
       var flag=false;
        $(this).click(function(){
          if(flag==false){


            $(this).text("收缩");
            $(this).parents().next(".upload_title").hide(500);
            $(this).parents().siblings('.upload_part').show(500);
            flag=true;
          }else{
            $(this).text("请展开填写完整信息");
            $(this).parents().next(".upload_title").show(500);
            $(this).parents().siblings('.upload_part').hide(500);
            flag=false;
          }
            
        })
          
    })
   // $(".title_show").each(function(){
        // $(this).click(function(){
        // $(this).text("收缩")
        // $(".upload_title").eq($(this).index()).hide(500)


        // $(".upload_part").eq($(this).index()).show(500)
       // alert(1)
        
       
   //})


   // })
		// 初始化进度条
		var ncCount = 50;
        // var myStat3Color = ncCount > 50 ? '#f00' : '#ccc';                       
        $('#myStat3').circliful({
            dimension: 144,
            endPercent: ncCount,
            showValue: "ncText",
        });

        // 简历部分进度条
        $("#jdt_state").width(300);

       // 个人中心左侧
       $(".p_info ul li").click(function(){
       		$(".p_info ul li").removeAttr("class","active");
       		$(this).attr("class","active");
       })

      /* // 个人中心右侧顶部
       $(".tab_pers li").click(function(){
       		$(".tab_pers li").removeClass('active')
       		$(this).addClass("active");
       		$(".tab_pers li").find("em").css("display","none");
       		$(this).find("em").css("display","block")
       });*/


       
      
    var arrNation=["蒙古族", "彝族", "侗族", "哈萨克族", "畲族", "纳西族", "仫佬族", "仡佬族", "怒族", "保安族", "鄂伦春族", "回族", "壮族", "瑶族", "傣族", "高山族", "景颇族", "羌族", "锡伯族", "乌孜别克族", "裕固族", "赫哲族", "藏族", "布依族", "白族", "黎族", "拉祜族", "柯尔克孜族", "布朗族", "阿昌族", "俄罗斯族", "京族", "门巴族", "维吾尔族", "朝鲜族", "土家族", "傈僳族", "水族", "土族", "撒拉族", "普米族", "鄂温克族", "塔塔尔族", "珞巴族", "苗族", "满族", "哈尼族", "佤族", "东乡族", "达斡尔族", "毛南族", "塔吉克族", "德昂族", "独龙族", "基诺族"];
    	
//    var arrProvince =["北京市", "天津市", "河北省", "山西省", "内蒙古", "辽宁省", "吉林省", "黑龙江省", "上海市", "江苏省", "浙江省", "安徽省", "福建省", "江西省", "山东省", "河南省", "湖北省", "湖南省", "广东省", "广西自治区", "海南省", "重庆市", "四川省", "贵州省", "云南省", "西藏自治区", "陕西省", "甘肃省", "青海省", "宁夏回族自治区", "新疆维吾尔自治区", "香港特别行政区", "澳门特别行政区", "台湾省", "其它"]

//    var arrYear_born= ["2000年","1999年","1998年","1997年","1996年","1995年"];
//    var pp= ["2000年","1999年","1998年","1997年","1996年","1995年"];

    getSelectVal(arrNation,".sel_option"); 
   $(".addEdu a").bind("click",function(){
      var str= $(".basic_edu ul").html();
   $(".basic_edu").append("<ul>"+str+"</ul>")
     

   });

});

//加载页面数据
function loadData(){
	var obj = arguments[0];
	var params = "";
	var url ="tab_1.html?";
	if(obj){
		var value = obj.value;
		var type  = obj.type;
		var param =type+"="+value;
		params = param+"&";
		$('[typeId="'+type+'"]').siblings().each(function(){
			var param = $(this).attr('typeId')+"="+$(this).attr('selVal');
			params+=param+"&";
		});
	}
	url = url + params;
	loadUrl('#sub-frameMain', url);
}
