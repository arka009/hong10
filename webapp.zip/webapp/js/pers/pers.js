$(function(){	
		
	
		/*$('input[type=checkbox]').tzCheckbox({labels:['Enable','Disable']});
	*/	
		//初始化滑动div
	/*	loadSwitchBox('.boxwrap',loadData,'#sub-frameMain','tab_1.html');*/

    $(".title_show").each(function(){
       var flag=false;
        $(this).click(function(){
          if(flag==false){


            $(this).text("收缩");
            $(this).parents().next(".upload_title").hide(500);
            $(this).parents().siblings('.upload_part').show(500);
            flag=true;
          }else{
            $(this).text("请展开填写完整信息");
            $(this).parents().next(".upload_title").show(500);
            $(this).parents().siblings('.upload_part').hide(500);
            flag=false;
          }
            
        })
          
    })
   // $(".title_show").each(function(){
        // $(this).click(function(){
        // $(this).text("收缩")
        // $(".upload_title").eq($(this).index()).hide(500)


        // $(".upload_part").eq($(this).index()).show(500)
       // alert(1)
        
       
   //})


   // })
//		// 初始化进度条
//		var ncCount = 50;
//        // var myStat3Color = ncCount > 50 ? '#f00' : '#ccc';                       
//        $('#myStat3').circliful({
//            dimension: 144,
//            endPercent: ncCount,
//            showValue: "ncText",
//        });

        // 简历部分进度条
//        $("#jdt_state").width(300);

       // 个人中心左侧
       $(".p_info ul li").click(function(){
       		$(".p_info ul li").removeAttr("class","active");
       		$(this).attr("class","active");
       })

      /* // 个人中心右侧顶部
       $(".tab_pers li").click(function(){
       		$(".tab_pers li").removeClass('active')
       		$(this).addClass("active");
       		$(".tab_pers li").find("em").css("display","none");
       		$(this).find("em").css("display","block")
       });*/


       
      
    var arrNation=["蒙古族", "彝族", "侗族", "哈萨克族", "畲族", "纳西族", "仫佬族", "仡佬族", "怒族", "保安族", "鄂伦春族", "回族", "壮族", "瑶族", "傣族", "高山族", "景颇族", "羌族", "锡伯族", "乌孜别克族", "裕固族", "赫哲族", "藏族", "布依族", "白族", "黎族", "拉祜族", "柯尔克孜族", "布朗族", "阿昌族", "俄罗斯族", "京族", "门巴族", "维吾尔族", "朝鲜族", "土家族", "傈僳族", "水族", "土族", "撒拉族", "普米族", "鄂温克族", "塔塔尔族", "珞巴族", "苗族", "满族", "哈尼族", "佤族", "东乡族", "达斡尔族", "毛南族", "塔吉克族", "德昂族", "独龙族", "基诺族"];
    	
//    var arrProvince =["北京市", "天津市", "河北省", "山西省", "内蒙古", "辽宁省", "吉林省", "黑龙江省", "上海市", "江苏省", "浙江省", "安徽省", "福建省", "江西省", "山东省", "河南省", "湖北省", "湖南省", "广东省", "广西自治区", "海南省", "重庆市", "四川省", "贵州省", "云南省", "西藏自治区", "陕西省", "甘肃省", "青海省", "宁夏回族自治区", "新疆维吾尔自治区", "香港特别行政区", "澳门特别行政区", "台湾省", "其它"]

//    var arrYear_born= ["2000年","1999年","1998年","1997年","1996年","1995年"];
//    var pp= ["2000年","1999年","1998年","1997年","1996年","1995年"];

    getSelectVal(arrNation,".sel_option"); 
//   selectResumeByUserSid();
});

//加载页面数据
function loadData(){
	var obj = arguments[0];
	var params = "";
	var url ="tab_1.html?";
	if(obj){
		var value = obj.value;
		var type  = obj.type;
		var param =type+"="+value;
		params = param+"&";
		$('[typeId="'+type+'"]').siblings().each(function(){
			var param = $(this).attr('typeId')+"="+$(this).attr('selVal');
			params+=param+"&";
		});
	}
	url = url + params;
	loadUrl('#sub-frameMain', url);
}

//加载个人中心内容页面
function loadConPertent(url){
	$("#perContent").load(url);
}
//var resumeData=null;
////根据用户获取简历
//function selectResumeByUserSid(){
//	Core.AjaxRequest({
//		url :ws_url + "/rest/resume/getResumeByUserSid/"+userSid, 
//		type:"GET",
//		callback : function (data) {
//			console.log(data);
//			//设置简历值
//			resumeData=data;
//		}
//	});
//}

//设置简历第一页值
function setFirstResumePageValues(data){
	//姓名
	$("#realName").val(data.realName);
	
	//性别
	if("01"==data.sex){
		$("#sexId").find("label").removeClass("checked");
		$("#sexId").find("label").eq(0).attr("class","checked"); 
	}else{
		$("#sexId").find("label").removeClass("checked");
		$("#sexId").find("label").eq(1).attr("class","checked"); 
	}
	
	//民族
	$("#pers_nations").val(data.nation);
	
	//籍贯 省
	$("#pers_province").val(data.nationPlace);
	
	//籍贯 市
//	$("#pers_city").val(data.nation);
	
	//身份证
	$("#idCard").val(data.cardId);
	
	//TODO 根据身份证计算出生年月
	
	$("#age").val(data.age);
	
	//婚否
	$("#isMary").val(data.isMary);
	
	//政治面貌
	$("#polityType").val(data.polityStatus);
	
	//健康状态
	$("#healthStatus").val(data.healthStatus);
	
	//外文水平
	$("#computeLevel").val(data.computeLevel);
	
	//手机号码
	$("#mobile").val(data.mobile);
	
	//手机号码
	$("#mail").val(data.mail);
	
	if(data.resumeSPList!=null&&data.resumeSPList.length>0){
		spIndex=data.resumeSPList.length-1;
		$.each(data.resumeSPList,function(index,content){
			var ul="<ul>" +
						"<li>" +
							"<p>" +
							"<i>最高学历</i>" +
							"</p>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown ' id='eduBack"+index+"'data-settings='{'cutOff': 12}'>" +
								"<option value='01'>博士</option>"+
								"<option value='02'>研究生</option>"+
								"<option value='03'>本科</option>"+
								"<option value='04'>专科</option>"+
								"</select>" +
							"</div>" +
							"<p>" +
							"<i>学制</i>" +
							"</p>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown ' id='collageLength"+index+"'" +
										"data-settings='{'cutOff': 12}'>" +
										"<option value='01'>四年制</option>"+
										"<option value='02'>五年制</option>"+
										"<option value='03'>七年制</option>"+
										"<option value='04'>八年制</option>"+
										"<option value='05'>全日制</option>"+
										"</select>" +
							"</div>" +
						"</li>" +
						"<li>" +
							"<p>" +
							"<i>学校名称</i>" +
							"</p>" +
							"<div class='pers_div'>" +
								"<input type='text' name='' id='collageName"+index+"'>" +
							"</div>" +
							"<p>" +
							"<i>所学专业</i>" +
							"</p>" +
							"<div class='pers_div'>" +
								"<input type='text' name='' id='majorName"+index+"'>" +
							"</div>" +
						"</li>" +
						"<li class='admission_date'>" +
							"<p>" +
							"<i>入学时间</i>" +
							"</p>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown ' id='collageBeginDateYear"+index+"'data-settings='{'cutOff': 12}'>" +
								"<option value='2015'>2015</option>"+
								"<option value='2014'>2014</option>"+
								"<option value='2013'>2013</option>"+
								"<option value='2012'>2012</option>"+
								"<option value='2011'>2011</option>"+
								"<option value='2010'>2010</option>"+
								"<option value='2009'>2009</option>"+
								"<option value='2008'>2008</option>"+
								"<option value='2007'>2007</option>"+
								"<option value='2006'>2006</option>"+
								"<option value='2005'>2005</option>"+
								"<option value='2004'>2004</option>"+
								"<option value='2003'>2003</option>"+
								"<option value='2002'>2002</option>"+
								"<option value='2001'>2001</option>"+
								"<option value='2000'>2000</option>"+
								"<option value='1999'>1999</option>"+
								"<option value='1998'>1998</option>"+
								"<option value='1997'>1997</option>"+
								"<option value='1996'>1996</option>"+
								"<option value='1995'>1995</option>"+
								"<option value='1994'>1994</option>"+
								"<option value='1993'>1993</option>"+
								"<option value='1992'>1992</option>"+
								"<option value='1991'>1991</option>"+
								"<option value='1990'>1990</option>"+
								"<option value='1989'>1989</option>"+
								"<option value='1988'>1988</option>"+
								"<option value='1987'>1987</option>"+
								"<option value='1986'>1986</option>"+
								"<option value='1985'>1985</option>"+
								"<option value='1984'>1984</option>"+
								"<option value='1983'>1983</option>"+
								"<option value='1982'>1982</option>"+
								"<option value='1981'>1981</option>"+
								"<option value='1980'>1980</option>"+
								
							"</select>" +
							"</div>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown ' id='collageBeginDateMonth"+index+"'data-settings='{'cutOff': 12}'>" +
								"<option value='1'>1</option>"+
								"<option value='2'>2</option>"+
								"<option value='3'>3</option>"+
								"<option value='4'>4</option>"+
								"<option value='5'>5</option>"+
								"<option value='6'>6</option>"+
								"<option value='7'>7</option>"+
								"<option value='8'>8</option>"+
								"<option value='9'>9</option>"+
								"<option value='10'>10</option>"+
								"<option value='11'>11</option>"+
								"<option value='12'>12</option>"+
								"</select>" +
							"</div>" +
							"<p>" +
							"<i>毕业时间</i>" +
							"</p>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown ' id='collageEndDateYear"+index+"'data-settings='{'cutOff': 12}'>" +
								"<option value='2015'>2015</option>"+
								"<option value='2014'>2014</option>"+
								"<option value='2013'>2013</option>"+
								"<option value='2012'>2012</option>"+
								"<option value='2011'>2011</option>"+
								"<option value='2010'>2010</option>"+
								"<option value='2009'>2009</option>"+
								"<option value='2008'>2008</option>"+
								"<option value='2007'>2007</option>"+
								"<option value='2006'>2006</option>"+
								"<option value='2005'>2005</option>"+
								"<option value='2004'>2004</option>"+
								"<option value='2003'>2003</option>"+
								"<option value='2002'>2002</option>"+
								"<option value='2001'>2001</option>"+
								"<option value='2000'>2000</option>"+
								"<option value='1999'>1999</option>"+
								"<option value='1998'>1998</option>"+
								"<option value='1997'>1997</option>"+
								"<option value='1996'>1996</option>"+
								"<option value='1995'>1995</option>"+
								"<option value='1994'>1994</option>"+
								"<option value='1993'>1993</option>"+
								"<option value='1992'>1992</option>"+
								"<option value='1991'>1991</option>"+
								"<option value='1990'>1990</option>"+
								"<option value='1989'>1989</option>"+
								"<option value='1988'>1988</option>"+
								"<option value='1987'>1987</option>"+
								"<option value='1986'>1986</option>"+
								"<option value='1985'>1985</option>"+
								"<option value='1984'>1984</option>"+
								"<option value='1983'>1983</option>"+
								"<option value='1982'>1982</option>"+
								"<option value='1981'>1981</option>"+
								"<option value='1980'>1980</option>"+
							"</select>" +
							"</div>" +
							"<div class='pers_div'>" +
								"<select tabindex='6' class='dropdown ' id='collageEndMonth"+index+"'data-settings='{'cutOff': 12}'>" +
								"<option value='1'>1</option>"+
								"<option value='2'>2</option>"+
								"<option value='3'>3</option>"+
								"<option value='4'>4</option>"+
								"<option value='5'>5</option>"+
								"<option value='6'>6</option>"+
								"<option value='7'>7</option>"+
								"<option value='8'>8</option>"+
								"<option value='9'>9</option>"+
								"<option value='10'>10</option>"+
								"<option value='11'>11</option>"+
								"<option value='12'>12</option>"+
							"</select>" +
							"</div>" +
						"</li>" +
					"</ul>";
			$("#resumeSp").append(ul);
			
			//设置学习经历
			$("#eduBack"+index).val(content.collegeDegree);
			$("#collageLength"+index).val(content.collageLength);
			$("#collageName"+index).val(content.collageName);
			$("#majorName"+index).val(content.majorName);
			var beginDate=content.collageBeginDate;
			var beginYearIndex=beginDate.indexOf("年");
			var beginMonthIndex=beginDate.indexOf("月");
			var beginYear=beginDate.substring(0,beginYearIndex);
			var beginMonth=beginDate.substring(beginYearIndex+1,beginMonthIndex);
			$("#collageBeginDateYear"+index).val(beginYear);
			$("#collageBeginDateMonth"+index).val(beginMonth);
			
			var endDate=content.collageEndDate;
			var endYearIndex=endDate.indexOf("年");
			var endMonthIndex=endDate.indexOf("月");
			var endYear=beginDate.substring(0,endYearIndex);
			var endMonth=beginDate.substring(endYearIndex+1,endMonthIndex);
			$("#collageEndDateYear"+index).val(endYear);
			$("#collageEndMonth"+index).val(endMonth);
		});
	}else{
		var ul="<ul>" +
			"<li>" +
				"<p>" +
				"<i>最高学历</i>" +
				"</p>" +
				"<div class='pers_div'>" +
					"<select tabindex='6' class='dropdown ' id='eduBack0'data-settings='{'cutOff': 12}'>" +
					"<option value='01'>博士</option>"+
					"<option value='02'>研究生</option>"+
					"<option value='03'>本科</option>"+
					"<option value='04'>专科</option>"+
					"</select>" +
				"</div>" +
				"<p>" +
				"<i>学制</i>" +
				"</p>" +
				"<div class='pers_div'>" +
					"<select tabindex='6' class='dropdown ' id='collageLength0'" +
							"data-settings='{'cutOff': 12}'>" +
							"<option value='01'>四年制</option>"+
							"<option value='02'>五年制</option>"+
							"<option value='03'>七年制</option>"+
							"<option value='04'>八年制</option>"+
							"<option value='05'>全日制</option>"+
							"</select>" +
				"</div>" +
			"</li>" +
			"<li>" +
				"<p>" +
				"<i>学校名称</i>" +
				"</p>" +
				"<div class='pers_div'>" +
					"<input type='text' name='' id='collageName0'>" +
				"</div>" +
				"<p>" +
				"<i>所学专业</i>" +
				"</p>" +
				"<div class='pers_div'>" +
					"<input type='text' name='' id='majorName0'>" +
				"</div>" +
			"</li>" +
			"<li class='admission_date'>" +
				"<p>" +
				"<i>入学时间</i>" +
				"</p>" +
				"<div class='pers_div'>" +
					"<select tabindex='6' class='dropdown ' id='collageBeginDateYear0'data-settings='{'cutOff': 12}'>" +
					"<option value='2015'>2015</option>"+
					"<option value='2014'>2014</option>"+
					"<option value='2013'>2013</option>"+
					"<option value='2012'>2012</option>"+
					"<option value='2011'>2011</option>"+
					"<option value='2010'>2010</option>"+
					"<option value='2009'>2009</option>"+
					"<option value='2008'>2008</option>"+
					"<option value='2007'>2007</option>"+
					"<option value='2006'>2006</option>"+
					"<option value='2005'>2005</option>"+
					"<option value='2004'>2004</option>"+
					"<option value='2003'>2003</option>"+
					"<option value='2002'>2002</option>"+
					"<option value='2001'>2001</option>"+
					"<option value='2000'>2000</option>"+
					"<option value='1999'>1999</option>"+
					"<option value='1998'>1998</option>"+
					"<option value='1997'>1997</option>"+
					"<option value='1996'>1996</option>"+
					"<option value='1995'>1995</option>"+
					"<option value='1994'>1994</option>"+
					"<option value='1993'>1993</option>"+
					"<option value='1992'>1992</option>"+
					"<option value='1991'>1991</option>"+
					"<option value='1990'>1990</option>"+
					"<option value='1989'>1989</option>"+
					"<option value='1988'>1988</option>"+
					"<option value='1987'>1987</option>"+
					"<option value='1986'>1986</option>"+
					"<option value='1985'>1985</option>"+
					"<option value='1984'>1984</option>"+
					"<option value='1983'>1983</option>"+
					"<option value='1982'>1982</option>"+
					"<option value='1981'>1981</option>"+
					"<option value='1980'>1980</option>"+
					
				"</select>" +
				"</div>" +
				"<div class='pers_div'>" +
					"<select tabindex='6' class='dropdown ' id='collageBeginDateMonth0'data-settings='{'cutOff': 12}'>" +
					"<option value='1'>1</option>"+
					"<option value='2'>2</option>"+
					"<option value='3'>3</option>"+
					"<option value='4'>4</option>"+
					"<option value='5'>5</option>"+
					"<option value='6'>6</option>"+
					"<option value='7'>7</option>"+
					"<option value='8'>8</option>"+
					"<option value='9'>9</option>"+
					"<option value='10'>10</option>"+
					"<option value='11'>11</option>"+
					"<option value='12'>12</option>"+
					"</select>" +
				"</div>" +
				"<p>" +
				"<i>毕业时间</i>" +
				"</p>" +
				"<div class='pers_div'>" +
					"<select tabindex='6' class='dropdown ' id='collageEndDateYear0'data-settings='{'cutOff': 12}'>" +
					"<option value='2015'>2015</option>"+
					"<option value='2014'>2014</option>"+
					"<option value='2013'>2013</option>"+
					"<option value='2012'>2012</option>"+
					"<option value='2011'>2011</option>"+
					"<option value='2010'>2010</option>"+
					"<option value='2009'>2009</option>"+
					"<option value='2008'>2008</option>"+
					"<option value='2007'>2007</option>"+
					"<option value='2006'>2006</option>"+
					"<option value='2005'>2005</option>"+
					"<option value='2004'>2004</option>"+
					"<option value='2003'>2003</option>"+
					"<option value='2002'>2002</option>"+
					"<option value='2001'>2001</option>"+
					"<option value='2000'>2000</option>"+
					"<option value='1999'>1999</option>"+
					"<option value='1998'>1998</option>"+
					"<option value='1997'>1997</option>"+
					"<option value='1996'>1996</option>"+
					"<option value='1995'>1995</option>"+
					"<option value='1994'>1994</option>"+
					"<option value='1993'>1993</option>"+
					"<option value='1992'>1992</option>"+
					"<option value='1991'>1991</option>"+
					"<option value='1990'>1990</option>"+
					"<option value='1989'>1989</option>"+
					"<option value='1988'>1988</option>"+
					"<option value='1987'>1987</option>"+
					"<option value='1986'>1986</option>"+
					"<option value='1985'>1985</option>"+
					"<option value='1984'>1984</option>"+
					"<option value='1983'>1983</option>"+
					"<option value='1982'>1982</option>"+
					"<option value='1981'>1981</option>"+
					"<option value='1980'>1980</option>"+
				"</select>" +
				"</div>" +
				"<div class='pers_div'>" +
					"<select tabindex='6' class='dropdown ' id='collageEndMonth0'data-settings='{'cutOff': 12}'>" +
					"<option value='1'>1</option>"+
					"<option value='2'>2</option>"+
					"<option value='3'>3</option>"+
					"<option value='4'>4</option>"+
					"<option value='5'>5</option>"+
					"<option value='6'>6</option>"+
					"<option value='7'>7</option>"+
					"<option value='8'>8</option>"+
					"<option value='9'>9</option>"+
					"<option value='10'>10</option>"+
					"<option value='11'>11</option>"+
					"<option value='12'>12</option>"+
				"</select>" +
				"</div>" +
			"</li>" +
		"</ul>";
	$("#resumeSp").append(ul);
	}
}

//保存简历第一页值 并跳转第二页
function saveFirstPageValue(){
	
}
