$(function() {
	$(".userAreaUl li").eq(0).nextAll().hide();

	$(".userAreaUl li").hover(function(){
		$(this).addClass("active");
		if($(this).index()==0){
			$(this).css({
				background:"#fff",
				
			}).children("a").css("color","#1395D8");
		}else{
			$(this).css({
				backgroundColor:"#0073b8",
				color:"#fff"
			});
		}
		$(".userAreaUl li").eq(0).nextAll().show();
	
		
	},function(){
		
		$(".userAreaUl li").eq(0).nextAll().hide();
		if($(this).index()==0){
			$(this).css({
				background:"#fff",
				
			}).children("a").css("color","#1395D8");
		}else{
			$(this).removeClass("active");
			$(this).css({
				backgroundColor:"#00a5e8",
				color:"#fff"
			});
		}
		
	});
	
	$(".userAreaUl").mouseleave(function(){
		$(this).children('li').eq(0).css({
			background:"none",
			
		}).children("a").css("color","#fff");
	});
	

    $('label').click(function() {
        var radioId = $(this).attr('name');
        $('label').removeAttr('class') && $(this).attr('class', 'checked');
        $('input[type="radio"]').removeAttr('checked') && $('#' + radioId).attr('checked', 'checked');
    });

    $(".aside ul").find("li").hover(function(){
    	$(this).css({
    		"background":"#f7f8f8"
    	});
    },function(){
    	$(this).css({
    		"background":"#efefef"
    	});
    });
    $(".aside ul").find("li:last").css("border","none");

    

    // english 鼠标悬浮 提示升级
    $('.en').hover(function() {

        $(".sy_update2").animate({
            "top": "0px"
        });
    },
    function() {

        $(".sy_update2").animate({
            "top": "-25px"
        });

    });

});

// 信息框居中
function getPositionCenter(obj) {
    var d_w = $(obj).width();
    var d_h = $(obj).height();
    $(obj).css({
        "position": "fixed",
        "left": "50%",
        "top": "50%",
        "margin-left": -d_w / 2,
        "margin-top": -d_h / 2
    });
}

// 向select option填充内容
function getSelectVal(arrObj, idObj) {
    $.each(arrObj,
    function(s) {
        $(idObj).append('<option value="' + s + '">' + arrObj[s] + '</option>');
    })
}

function getAllcheckbox(obj, ele) {

    $(obj).click(function() {
        if ($(this).attr("checked", "checked")) {
            $(ele).each(function() {
                $(this).attr("checked", true);
            });

        } else {
            $(ele).each(function() {
                $(this).attr("checked", false);
            });
        }

    });
}
// checkbox样式
function mCheck() {
	
    $('input').iCheck({

        checkboxClass: 'icheckbox_square-blue',
        // 注意square和blue的对应关系,用于type=checkbox

        increaseArea: '10%' // 增大可以点击的区域
    });
}

function getTab(obj, obj2) {
    $(obj).click(function() {
        $(obj).attr("class", "");
        $(this).attr("class", "active");

        $(obj2).css("display", "none");
        $(obj2).eq($(this).index()).css("display", "block");
    });
}



function alert_box(load_ele, data) {
	
    var b_h = $(document).height();

    var creBox = $("<div class='aler_bg'>").css({
        "width": "100%",
        "height": b_h,
        "position": "absolute",
        "left": 0,
        "top": 0,

        "background": "rgba(0,0,0,.5)",

        "z-index": 300
    });
    
    $(creBox).appendTo($("body"));
    $(creBox).load(load_ele, data,function(){
    	creBox.click(function(event){
    		$(this).remove();
    		event.stopPropagation();   		
    	});
    	var obb=$(creBox).children(":first");
    	obb.click(function(event){
    		event.stopPropagation();
    	});
    });
   
}
function removeBox(obj, obj_parent) {
   $(obj).parent(obj_parent).parents(".aler_bg").remove();	
}

// console.log在IE低版本中显示错误 则用log方法即可
function log(msg){
	if (window["console"]){
		console.log(msg);
	}
}


function getxbox(obj, ele) {

    $(obj).load(ele);
}

function getScroll() {
    var bodyTop = 0;
    if (typeof window.pageYOffset != 'undefined') {
        bodyTop = window.pageYOffset;
    } else if (typeof document.compatMode != 'undefined' && document.compatMode != 'BackCompat') {
        bodyTop = document.documentElement.scrollTop;
    } else if (typeof document.body != 'undefined') {
        bodyTop = document.body.scrollTop;
    }
    return bodyTop;
}
function getPage(fy_ym, fy_contents, nums) {
    $(fy_ym).jPages({
        containerID: fy_contents,
        perPage: nums,
        previous: "上一页",
        next: "下一页"
    });
}



function getAsideStyle(){
	var nums=0;
	$(".aside h1 span").each(function(){
		nums++;
		$(this).attr("class","sp"+nums+"");
	});
	$(".aside h1").bind("click",function(){
		var nextUl = $(this).next();
		if(nextUl.length>0 && nextUl.children('li').length>0){
			return;
		}
		$(".aside h1").removeClass("active");
		$(this).addClass("active");
		$(".aside ul li a").removeClass("active");
}); 

$(".aside ul li a").bind("click",function(){
	$(".aside ul li a").removeClass("active");
	$(".aside ul li a").parent().parent("ul").prev("h1").removeClass("active");
	$(".aside ul li a").parent().parent("ul").prev("h1").siblings("h1").removeClass("active");
	$(this).parent().parent("ul").prev("h1").addClass("active");
	$(this).addClass("active");
});
}

//鼠标移入效果  创建阴影层
function createShadow(obj){	
	
	$(obj).hover(function(){
		$(this).css("position","relative");
		var oSpan=$("<span>");
			oSpan.css({
				width:$(this).children("img").width(),
				height:$(this).children("img").height(),
				display:"block",
				background:"rgba(0,0,0,.3)",
				position:"absolute",
				left:0,
				top:0,
				padding:0,
				zIndex:999
			});
			oSpan.appendTo($(this));
	},function(){
		$(this).children("span").remove();
	});
}

//datepicker 显示中文
function getLanDatePicker(){
	$.datepicker.regional['zh-CN'] = {
	        closeText: '关闭',
	        prevText: '<上月',
	        nextText: '下月>',
	        currentText: '今天',
	        monthNames: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
	        monthNamesShort: ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '十一', '十二'],
	        dayNames: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
	        dayNamesShort: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'],
	        dayNamesMin: ['日', '一', '二', '三', '四', '五', '六'],
	        weekHeader: '周',
	        dateFormat: 'yy-mm-dd',
	        firstDay: 1,
	        isRTL: false,
	        showMonthAfterYear: true,
	        yearSuffix: '年'
	    };
	    $.datepicker.setDefaults($.datepicker.regional['zh-CN']);
}
