var timer;
$(function() {

	
    //发布确认信息框居中

    $('label').click(function() {
        var radioId = $(this).attr('name');
        $('label').removeAttr('class') && $(this).attr('class', 'checked');
        $('input[type="radio"]').removeAttr('checked') && $('#' + radioId).attr('checked', 'checked');
    });

    $(".aside ul").find("li").hover(function(){
    	$(this).css({
    		"background":"#f7f8f8"
    	});
    },function(){
    	$(this).css({
    		"background":"#efefef"
    	});
    });
    $(".aside ul").find("li:last").css("border","none");
    
  

    //var b_h= $(document).height();
    //$(".alert_box").height(b_h)
    //		
    //
    //		$(window).scroll(function(){
    //            clearInterval(timer);
    //            var topScroll=getScroll();
    //            var topDiv="150px";
    //            var top=topScroll+parseInt(topDiv);
    //            timer=setInterval(function(){
    //                    //$(".test").css("top", top+"px");
    //                     $(".alert_login").animate({"top":top},500);
    //            },500)
    //        })

    $.datepicker.regional['zh-CN'] = {
        closeText: '关闭',
        prevText: '<上月',
        nextText: '下月>',
        currentText: '今天',
        monthNames: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
        monthNamesShort: ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '十一', '十二'],
        dayNames: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
        dayNamesShort: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'],
        dayNamesMin: ['日', '一', '二', '三', '四', '五', '六'],
        weekHeader: '周',
        dateFormat: 'yy-mm-dd',
        firstDay: 1,
        isRTL: false,
        showMonthAfterYear: true,
        yearSuffix: '年'
    };
    $.datepicker.setDefaults($.datepicker.regional['zh-CN']);

    // english 鼠标悬浮 提示升级
    $('.en').hover(function() {

        $(".sy_update2").animate({
            "top": "0px"
        });
    },
    function() {

        $(".sy_update2").animate({
            "top": "-25px"
        });

    });

    // getAllcheckbox("#allcheck","input[name=item]");
});

// 信息框居中
function getPositionCenter(obj) {
    var d_w = $(obj).width();
    var d_h = $(obj).height();
    $(obj).css({
        "position": "fixed",
        "left": "50%",
        "top": "50%",
        "margin-left": -d_w / 2,
        "margin-top": -d_h / 2
    });
}

// 向select option填充内容
function getSelectVal(arrObj, idObj) {
    $.each(arrObj,
    function(s) {
        $(idObj).append('<option value="' + s + '">' + arrObj[s] + '</option>');
    })
}

function getAllcheckbox(obj, ele) {

    $(obj).click(function() {
        if ($(this).attr("checked", "checked")) {
            $(ele).each(function() {
                $(this).attr("checked", true);
            });

        } else {
            $(ele).each(function() {
                $(this).attr("checked", false);
            });
        }

    });
}
// checkbox样式
function mCheck() {
    $('input').iCheck({

        checkboxClass: 'icheckbox_square-blue',
        // 注意square和blue的对应关系,用于type=checkbox

        increaseArea: '10%' // 增大可以点击的区域
    });
}

function getTab(obj, obj2) {
    $(obj).click(function() {
        $(obj).attr("class", "");
        $(this).attr("class", "active");

        $(obj2).css("display", "none");
        $(obj2).eq($(this).index()).css("display", "block");
    });
}



function alert_box(load_ele, data) {

    var b_h = $(document).height();
	//var b_h=$(".viewReusmeDiv").height();

    var creBox = $("<div class='aler_bg'>").css({
        "width": "100%",
        "height": b_h,
        "position": "absolute",
        "left": 0,
        "top": 0,

        "background": "rgba(0,0,0,.5)",

        "z-index": 300
    });
 
    $(creBox).appendTo($("body"));
    $(creBox).load(load_ele, data,function(){
    	mCheck();
    	creBox.click(function(event){
    		
    		$(this).remove();
    		event.stopPropagation();   		
    		
    	});
    	var obb=$(creBox).children(":first");
    	obb.click(function(event){
    		event.stopPropagation();
    	});
    });
    
  

}
function removeBox(obj, obj_parent) {
   $(obj).parent(obj_parent).parents(".aler_bg").remove();	
}



function getxbox(obj, ele) {

    $(obj).load(ele);
}

function getScroll() {
    var bodyTop = 0;
    if (typeof window.pageYOffset != 'undefined') {
        bodyTop = window.pageYOffset;
    } else if (typeof document.compatMode != 'undefined' && document.compatMode != 'BackCompat') {
        bodyTop = document.documentElement.scrollTop;
    } else if (typeof document.body != 'undefined') {
        bodyTop = document.body.scrollTop;
    }
    return bodyTop
}
function getPage(fy_ym, fy_contents, nums) {
    $(fy_ym).jPages({
        containerID: fy_contents,
        perPage: nums,
        previous: "上一页",
        next: "下一页"
    });
}

//弹出层
function popUpViewResumeBox(trigger, popupBlk, closeBtn, x, y) {
    //示例9，综合效果
    var t9 = new PopupLayer({
        trigger: trigger,
        popupBlk: popupBlk,
        closeBtn: closeBtn,
        useOverlay: true,
        useFx: true,
        offsets: {
            x: x,
            y: y
        }
    });
    t9.doEffects = function(way) {
        if (way == "open") {
            this.popupLayer.css({
                opacity: 0.3
            }).show(400,
            function() {
                this.popupLayer.animate({
                    left: ($(document).width() - this.popupLayer.width()) / 2,
                    top: (0),
                    opacity: 0.8
                },
                1000,
                function() {
                    this.popupLayer.css("opacity", 1)
                }.binding(this));
            }.binding(this));
        } else {
            this.popupLayer.animate({
                left: this.trigger.offset().left,
                top: this.trigger.offset().top,
                opacity: 0.1
            },
            {
                duration: 500,
                complete: function() {
                    this.popupLayer.css("opacity", 1);
                    this.popupLayer.hide()
                }.binding(this)
            });
        }
    }
}

//弹出层
function popUpBox(trigger, popupBlk, closeBtn, x, y) {
    //示例9，综合效果
    var t9 = new PopupLayer({
        trigger: trigger,
        popupBlk: popupBlk,
        closeBtn: closeBtn,
        useOverlay: true,
        useFx: true,
        offsets: {
            x: x,
            y: y
        }
    });
    t9.doEffects = function(way) {
        if (way == "open") {
            this.popupLayer.css({
                opacity: 0.3
            }).show(400,
            function() {
                this.popupLayer.animate({
                    left: ($(document).width() - this.popupLayer.width()) / 2,
                    top: (document.documentElement.clientHeight - this.popupLayer.height()) / 2 + $(document).scrollTop(),
                    opacity: 0.8
                },
                1000,
                function() {
                    this.popupLayer.css("opacity", 1)
                }.binding(this));
            }.binding(this));
        } else {
            this.popupLayer.animate({
                left: this.trigger.offset().left,
                top: this.trigger.offset().top,
                opacity: 0.1
            },
            {
                duration: 500,
                complete: function() {
                    this.popupLayer.css("opacity", 1);
                    this.popupLayer.hide()
                }.binding(this)
            });
        }
    }
}