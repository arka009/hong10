
//根据SID查询科室
function getDeptByDeptSid(deptSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/getDeptBySid/"+deptSid, 
		type:"GET",
		callback : function (data) {
			console.log(data);
			$(".deptName").html(data.deptName);
			$(".hospitalName").attr("href",""+ctx+"/pages/hospital/hospital-detail.jsp?hospitalSid="+data.hospitalSid);
			$(".hospitalName").html(data.hosName);
			$("#deptPower").html(data.deptPower);
			$("#deptKeyPoint").html(data.deptKeyPoint);
			$("#deptSciResult").html(data.deptSciResult);
			$("#recruitPorcess").html(data.recruitPorcess);
		}
   });
	
}
//根据科室查询亚科室
function getSubSpecByDeptSid(deptSid,specType){
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selectPosByDeptSid", 
		type:"POST",
		params:{
			specType:specType,
			positionStatus:'01',
			deptSid:deptSid
		},
		callback : function (data) {
			console.log("亚专科"+data);
			if(data!=null&&data.length>0){
				$.each(data,function(index,content){
					var onClick="getWorkRequestBySubDept('"+content.positionSid+"')";
					var a=" <input type='radio'   name='sport' value='"+content.positionSid+"'>" +
							"<label name='nba' onClick="+onClick+" >"+content.learnDirection+"</label>";
					$("#subSpec").append(a);
					if(index==0){
//						var radioId = $('label').attr('name');
						$('label').removeAttr('class') && $('label').attr('class', 'checked');
//						$('input[type="radio"]').removeAttr('checked') && $('#' + radioId).attr('checked', 'checked');
						getWorkRequestBySubDept(content.positionSid);
					}
				});
				
				$('label').click(function(){
//				    var radioId = $(this).attr('name');
				    $('label').removeAttr('class') && $(this).attr('class', 'checked');
//				    $('input[type="radio"]').removeAttr('checked') && $('#' + radioId).attr('checked', 'checked');
				  });
			}
			
		}
   });
}

//根据亚科室查询职业要求
function getWorkRequestBySubDept(positionSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/position/getPosBySid/"+positionSid, 
		type:"GET",
		callback : function (data) {
			console.log("职业要求");
			console.log(data);
			$("#workRequest span").remove();
//			if(data!=null&&data.length>0){
//				for(var i=0;i<data.length;i++){
					
					//学历
					if('01'==data.requireEducate){
						var span="<span>博士以上</span>";
						$("#workRequest").append(span);
					}else if('02'==data.requireEducate){
						var span="<span>研究生以上</span>";
						$("#workRequest").append(span);
					}else if('03'==data.requireEducate){
						var span="<span>本科以上</span>";
						$("#workRequest").append(span);
					}else if('04'==data.requireEducate){
						var span="<span>专科以上</span>";
						$("#workRequest").append(span);
					}
					//职称
					if('01'==data.requireTitle){
						var span="<span>高级职称以上</span>";
						$("#workRequest").append(span);
					}else if('02'==data.requireTitle){
						var span="<span>中级职称以上</span>";
						$("#workRequest").append(span);
					}else if('03'==data.requireTitle||'04'==data.requireTitle){
						var span="<span>初级职称以上</span>";
						$("#workRequest").append(span);
					}
					//工作经验
					if('01'==data.workExperise){
						var span="<span>1-2年临床经验</span>";
						$("#workRequest").append(span);
					}else if('02'==data.workExperise){
						var span="<span>3-5年临床经验</span>";
						$("#workRequest").append(span);
					}else if('03'==data.workExperise){
						var span="<span>5年以上临床经验</span>";
						$("#workRequest").append(span);
					}
					
					//医师资格证
					if('01'==data.isDoctorQuaCer){
						var span="<span>医师资格证</span>";
						$("#workRequest").append(span);
					}
					
					//医技资格证
					if('01'==data.isProPhyCer){
						var span="<span>医技资格证</span>";
						$("#workRequest").append(span);
					}
					
					//护理资格证
					if('01'==data.isNurQuaCer){
						var span="<span>护理资格证</span>";
						$("#workRequest").append(span);
					}
					
					//医师执业证
					if('01'==data.isDoctorPraCer){
						var span="<span>医师执业证</span>";
						$("#workRequest").append(span);
					}
					
					//医技执业证
					if('01'==data.isProPraCer){
						var span="<span>医技执业证</span>";
						$("#workRequest").append(span);
					}
					
					//护理执业证
					if('01'==data.isNurPraCer){
						var span="<span>护理执业证</span>";
						$("#workRequest").append(span);
					}
					//大型仪器上岗证
					if('01'==data.isLarInstCer){
						var span="<span>大型仪器上岗证</span>";
						$("#workRequest").append(span);
					}
//				}
//			}
			getLearnBeginTime(positionSid);
		}
   });
}

//根据亚专科查询开课时间
function getLearnBeginTime(positionSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selectBachByParams", 
		type:"POST",
		params:{
			positionSid:positionSid
		},
		callback : function (data) {
			console.log("开课时间"+data);
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
					var optionValue=""+data[i].learnBeginDateYear+"年"+data[i].learnBeginDateMonth+"月";
					var option="<option value='"+data[i].hosLaranPosBatchSid+"'>"+optionValue+"</option>";
					$("#beginTime").append(option);
					if(i==0){
						getBatchByBeginTime(data[i].hosLaranPosBatchSid,positionSid);
					}
				}
				
				/*$( "#beginTime" ).selectmenu({
					 cutOff:6,
					 change: function( event, ui ) {
						 getBatchByBeginTime(ui.item.value,$("input[name='sport']").val());
					  }
				});*/
				
				$( "#beginTime" ).easyDropDown({
					 cutOff:6,
					 onChange: function( selected){
						 getBatchByBeginTime(selected.value,$("input[name='sport']").val());
				     }
				});
			}
			
		}
   });
}

//根据开课时间查询批次
function getBatchByBeginTime(hosLaranPosBatchSid,positionSid){
	console.log(hosLaranPosBatchSid+"$$$$$$$$"+positionSid);
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selectBachByParams", 
		type:"POST",
		params:{
			hosLaranPosBatchSid:hosLaranPosBatchSid,
			positionSid:positionSid
		},
		callback : function (data) {
			console.log("批次"+data);
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
					$("#recruitDateMonth").html(data[i].recruitDateMonth+"月");
					$("#recruitPeopleNum").html(data[i].recruitPeopleNum+"人");
					$("#otherReuqest").html(data[i].otherReuqest);
					if('01'==data[i].isRetest){
						$("#isRetest").html("是");
					}else{
						$("#isRetest").html("否");
					}
					if(i==0){
						selectCytleByBatchSid(data[i].hosLaranPosBatchSid);
					}
				}
			}
		}
   });
}

//根据批次查询周期
function selectCytleByBatchSid(batchSid){
	console.log("周期"+batchSid);
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selecCytleByParams", 
		type:"POST",
		params:{
			hosLaranPosBatchSid:batchSid,
		},
		callback : function (data) {
			console.log(data);
			if(data!=null&&data.length>0){
				$("#courseLength").children().remove();
				for(var i=0;i<data.length;i++){
					var a="<input type='radio'  class='courseRadioDoc' name='courseRadio' value='"+data[i].hosPosBatchCycleSid+"'>" +
					"<label name='courseLable' class='courseLableDoc'id='courseLengthLabel"+i+"'>"+data[i].cycleLength+"个月</label>";
					$("#courseLength").append(a);
					if(i==0){
						getCytleByCytleSid(data[i].hosPosBatchCycleSid);
						  $("label[name='courseLable']").removeAttr('class') && $("#courseLengthLabel0").attr('class', 'checked');
					}
				}
					$("label[name='courseLable']").click(function(){
						getCytleByCytleSid($(this).prev().eq(0).val());
						 $("label[name='courseLable']").removeAttr('class') && $(this).attr('class', 'checked');
					  });
				
			}
			
		}
   });
}
//根据周期SID查询费用
function getCytleByCytleSid(cytleSid){
	console.log(cytleSid);
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selecCytleBySid/"+cytleSid, 
		type:"GET",
		callback : function (data) {
			console.log("费用"+data);
			$("#cost").html(data.cost+"元");
				
			
		}
   });
}

//根据周期SID查询费用
function getLeaderByDeptSid(deptSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/user/selectTutorBySpec", 
		type:"POST",
		params:{
			deptSid:deptSid,
			isLeader:'01'
		},
		callback : function (data) {
			console.log("leader@@@@@@@@@"+data);
			if(data!=null&&data.length>0){
				$.each(data,function(index,content){
					$("#expertPage").attr("href",ctx+"/pages/expert/expert-personal.jsp?userSid="+content.userSid);
					$(".expertPage").attr("href",ctx+"/pages/expert/expert-personal.jsp?userSid="+content.userSid);
					$("#leaderName").html(content.realName);
					$("#leaderWork").html(content.workTitle);
					$("#leaderfaceImage").attr("src",ctx+"/"+content.faceImage);
					var skill=content.keySkills.split(",");
					if(skill!=null&&skill.length>0){
						$.each(skill,function(index,content){
							var a="<a href='javascript:void(0);'>"+content+"</a>";
							$("#leaderKeySkill").append(a);
						});
					}
				});
			}
		}
	});
}

//根据周期SID查询费用
function getTourByDeptSid(deptSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/user/selectTutorBySpec", 
		type:"POST",
		params:{
			deptSid:deptSid,
			isTour:'01'
		},
		callback : function (data) {
			console.log("tour#########"+data);
			if(data!=null&&data.length>0){
				$.each(data,function(index,content){
					if(index==0){
						var point = "<span class='active'></span>";
						$("#point").append(point);
					}else{
						var point = "<span></span>";
						$("#point").append(point);
					}
					
					var li="<li>" +
								"<a class='rw_face' href='"+ctx+"/pages/expert/expert-personal.jsp?userSid="+content.userSid+"'><img style='width:95px;height:97px;border-radius:50%;' src='"+ctx+"/"+content.faceImage+"'  alt=''></a>" +
								"<dl class='title1'>" +
									"<dt>学科导师</dt>" +
									"<dd>"+content.realName+"</dd>" +
									"<dd>"+content.workTitle+"</dd>" +
								"</dl>" +
								"<dl class='title2'>" +
									"<dt>擅长：</dt>" +
									"<dd id='tourKeySkill"+index+"'>" +
									"</dd>" +
								"</dl>" +
							"</li>";
					$("#zk_arousel").append(li);
					
					var skill=content.keySkills.split(",");
					if(skill!=null&&skill.length>0){
						$.each(skill,function(index,content){
							var a="<a href=''>"+content+"</a>";
							$("#tourKeySkill"+index).append(a);
						});
					}
				});
			}
		}
	});
}

//查询专科下特色技术
function selectTechByDeptSid(deptSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectTechByDeptSid/"+deptSid, 
		type:"GET",
		callback : function (data) {
			if(data!=null&&data.length>0){
				$.each(data,function(index,content){
					var a="<a href='javaScript:;'>"+content.hosSpecFeaTechName+"</a>";
					$("#deptTech").append(a);
				});
			}
		}
   });
}

//投递简历到医教科
function sendResumeMedEdu(){
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/deliveryResumeToMedEdu", 
		type:"POST",
		params:{
			deptSid:deptSid,
//			classSid:$("input[name='sport']").val(),
			hosBatchCytleSid:$("input[name='courseRadio']").val()
		},
		callback : function (data) {
		}
	});
}