
//查询所有医院下所有科室
function selectSpec(specType){
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectSpecRelative", 
		type:"POST",
		params:{
			specType:specType,
		},
		callback : function (data) {
			
			$("#parentSpec").children().remove();
			$(".type_ks").remove();
			for(var i=0;i<data.length;i++){
				var a="<a href='#"+data[i].specName+"'>"+data[i].specName+"</a>";
				$("#parentSpec").append(a);
				var childSpec=data[i].childSpecs;
				if(childSpec!=null&&childSpec.length>0){
					var div=$("<div class='type_ks'></div>");
					$(".tab_box").append(div);
					var h3=$("<h3><a name='"+data[i].specName+"'>"+data[i].specName+"</a></h3>");
					div.append(h3);
					var p=$("<p></p>");
					div.append(p);
					for(var j=0;j<childSpec.length;j++){
						var click="loadSpecFilterPage('/pages/spec/spec-filter.jsp','"+childSpec[j].specSid+"')";
						var span=$("<span onClick="+click+"><a>"+childSpec[j].specName+"</a></span>");
						p.append(span);
					};
				};
			};
      }
   });
};

//加载专科过滤页面
function loadSpecFilterPage(url,specSid){
	var data={specSid:specSid};
	$("#contentArea").load(ctx+url,data);
}

/*$(function () {
    var arrUserName = ["冥哥", "名哥", "鸣哥", "瞑哥", "大黄", "二黄", "三黄","名人", "鸣人", "李小四", "刘促明", "李渊", "张小三", "王小明"];
    $("#txtSearch").autocomplete(arrUserName,{
        minChars: 0, //双击空白文本框时显示全部提示数据
        width: 771,
       
        max: 10,
        
        formatItem: function (data, i, total) {
            return "<I>" + data[0] + "</I>"; //改变匹配数据显示的格式
        },
        formatMatch: function (data, i, total) {
            return data[0];
        },
        formatResult: function (data) {
            return data[0];
        }
    }).result(SearchCallback); 
    function SearchCallback(event, data, formatted) {
       location.href="https://www.baidu.com";
    }
});*/