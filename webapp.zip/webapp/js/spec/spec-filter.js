
//根据专科SID查询专科信息
function getSpecBySid(specSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/getSpecBySid/"+specSid, 
		type:"GET",
		callback : function (data) {
			$(".specName").html(data.specName);
		}
   });
}

//根据专科SID查询专科信息
function getPosBySpecSid(specSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/getSpecBySid/"+specSid, 
		type:"GET",
		callback : function (data) {
			$(".specName").html(data.specName);
		}
   });
}

//查询所有医院下所有科室
function selectSpec(){
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectSpecRelative", 
		type:"POST",
		params:{
		},
		callback : function (data) {
//			$("#parentSpec").children().remove();
//			$(".type_ks").remove();
			for(var i=0;i<data.length;i++){
				var optGroup=$("<optgroup label="+data[i].specName+">");
				$("#specName").append(optGroup);
				var childSpec=data[i].childSpecs;
				if(childSpec!=null&&childSpec.length>0){
					for(var j=0;j<childSpec.length;j++){
						var option=$("<option value='"+childSpec[j].specSid+"'>"+childSpec[j].specName+"</option>");
						optGroup.append(option);
					};
				};
			};
      }
   });
};

//查询专科下疾病
function selectDiseaseBySpecSid(specSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectDiseaseBySpecSid/"+specSid, 
		type:"GET",
		callback : function (data) {
			console.log("疾病"+data);
			if(data!=null&&data.length>0){
				$.each(data,function(index,content){
					var onClick="selectPosByParams('"+content.hosSpecDiseaseSid+"',null,null,null,null,null,null,null)";
					var a="<a href='javaScript:;'onClick="+onClick+">"+content.hosSpecDiseaseName+"</a>";
					$("#diseases").append(a);
				});
			}
			
		}
   });
}

//查询专科下特色技术
function selectTechBySpecSid(specSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectTechBySpecSid/"+specSid, 
		type:"GET",
		callback : function (data) {
			if(data!=null&&data.length>0){
				$.each(data,function(index,content){
					if(index<5){
						var onClick="selectPosByParams(null,'"+content.hosSpecFeaTechSid+"',null,null,null,null,null,null)";
						var a="<a href='javaScript:;' onClick="+onClick+">"+content.hosSpecFeaTechName+"</a>";
						$("#technologys").append(a);	
					}
					
				});
			}
		}
   });
}
//查询专科下知名专家
function selectLeaderBySpecSid(specSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/user/selectTutorBySpec", 
		type:"POST",
		params:{
			specSid:specSid
		},
		callback : function (data) {
			console.log(data);
			if(data!=null&&data.length>0){
				$.each(data,function(index,content){
					var onClick="selectPosByParams(null,null,'"+content.userSid+"',null,null,null,null,null)";
					var a="<a href='"+ctx+"/pages/expert/expert-personal.jsp?userSid="+content.userSid+"' onClick="+onClick+">" +
								"<li>" +
									"<img src='"+ctx+"/"+content.faceImage+"' alt=''>" +
									"<p>" +
										"<span class='zj_name'>"+content.realName+"</span>" +
										"<span class='hospital'>"+content.hosName+"</span>	" +
									"</p>" +
								"</li>" +
							"</a>";
					$("#leaderSpec").append(a);
				});
			}
		}
	});
}
//查询学历
function selectEduBack(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/EDU_BACK", 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
						var onClick="selectPosByParams(null,null,null,null,null,'"+data[i].codeValue+"',null,null)";
						var option="<span onClick="+onClick+">"+data[i].codeDisplay+"</span>";
						$("#eduBack").append(option);
				}
			}
		} 
	});
}
//查询学历
function selectWorkLength(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/WORK_EXPERISE", 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
					var onClick="selectPosByParams(null,null,null,null,null,null,'"+data[i].codeValue+"',null)";
						var option="<span onClick="+onClick+">"+data[i].codeDisplay+"</span>";
						$("#workLength").append(option);
				}
			}
		} 
	});
}

//查询省
function selectProvince(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/PROVINCE", 
		type:"get",
		async:false,
		callback : function (data) {
			if(data!=null&&data.length>0){
				for(var i=0;i<data.length;i++){
						var onClick="selectPosByParams(null,null,null,null,null,null,null,'"+data[i].codeValue+"')";
						var option="<span onClick="+onClick+">"+data[i].codeDisplay+"</span>";
						$(".province_p").append(option);
						if(i==16){
							break;
						}
				}
			}
        } 
     });
}

//查询条件
var selectParams=function(){
//	this.hospitalSid=hospitalSid;
	this.positionStatus='01';
};

//点击科室查询进修
function selectPosByParams(diseaseSid,feaTechSid,userSid,beginTimeType,courseLength,lowEduBack,workLength,province){
	if('00'==beginTimeType){
		params.halfYearFlag=null; 
		params.courseBenginYear=null; 
	}else if('01'==beginTimeType){
		params.courseBenginYear='2015'; 
		params.halfYearFlag="'02'"; 
	}else if('02'==beginTimeType){
		params.courseBenginYear='2016'; 
		params.halfYearFlag="'01'"; 
	}else if('03'==beginTimeType){
		params.courseBenginYear='2016'; 
		params.halfYearFlag="'02'"; 
	}else if('04'==beginTimeType){
		params.courseBenginYear='2017'; 
		params.halfYearFlag="'01'"; 
	}
	if('00'!=courseLength&&courseLength!='twelveAbove'){
		params.courseLength=courseLength; 
	}else if(courseLength=='twelveAbove'){
		params.isAboveOneYear="'01'";
	}else{
		params.courseLength=null; 
	}
	if('00'!=lowEduBack){
		params.requireEducate=lowEduBack; 
	}else{
		params.requireEducate=null;
	}
	if('00'!=workLength){
		params.workExperise=workLength; 
	}else{
		params.workExperise=null;
	}
	if('00'!=province){
		params.hospitalProvince=province; 
	}else{
		params.hospitalProvince=null;
	}
	
	params.userSid=userSid; 
	params.deptFeaTech=feaTechSid; 
	params.deptDisease=diseaseSid; 
	selectPositionByParams();
	
}
// 条件查询简历
function selectPositionByParams(){
	console.log(params);
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selectPositionInResultByParams", 
		type:"POST",
		params:params,
		callback : function (data) {
			console.log(data);
			$("#positionGrid li").remove();
			if(data!=null&&data.length>0){
			for(var i=0;i<data.length;i++){
				
				//处理进修时长添加”个月“
				if(data[i].courseLength!=null){
					var courseLengthArray=data[i].courseLength.split(",");
					var courseLengthArrayStr="";
					if(courseLengthArray.length>0){
						for(var j=0;j<courseLengthArray.length;j++){
							courseLengthArrayStr+=courseLengthArray[j]+"个月 ";
						}
					}
				}
				if(data[i].courseBeginMonth!=null){
					//处理进修时长添加”个月“
					var courseBeginMonthArray=data[i].courseBeginMonth.split(",");
					var courseBeginMonthArrayStr="";
					if(courseBeginMonthArray.length>0){
						for(var j=0;j<courseBeginMonthArray.length;j++){
							courseBeginMonthArrayStr+=courseBeginMonthArray[j]+"月 ";
						}
					}
				}
				
				//处理特色技术
				var feaTechnologyArrayStr="";
				if(data[i].feaTechnology!=null){
					var feaTechnologyArray=data[i].feaTechnology.split(",");
					if(feaTechnologyArray.length>0){
						for(var j=0;j<feaTechnologyArray.length;j++){
							feaTechnologyArrayStr+=feaTechnologyArray[j]+" ";
						}
					}
				}
				
				//处理是否复试
				var isRetest=data[i].isRetest;
				var isRetestName="";
				if("01"==isRetest){
					isRetestName="是";
				}else{
					isRetestName="否";
				}
				var click="loadSpecDetailPage('/pages/spec/spec-detail.jsp','"+data[i].deptSid+"')";
				//填充按专科查询进修
				var li="<li>" +
							"<ul>" +
								"<li class='first'>" +
								"<a style='background:#f7f8f8;color:#1395d8;font-size: 18px;width:50%;text-align:left'href='javascript:void(0);' onclick="+click+" class='baom'>"+data[i].deptName+"--"+data[i].learnDirection+"</a>" +
									"<p>［无界推荐］ 学习机会多、易申请、导师好</p>" +
								"</li>" +
								"<li>" +
									"<p class='p1'>" +
										"<span>进修医院：</span>" +
										"<span>"+data[i].hospitalName+"</span>" +
									"</p>" +
									"<p class='p2'>" +
										"<span>学科带头人：</span>" +
										"<span>"+data[i].realName+"</span>" +
									"</p>" +
								"</li>" +
								"<li>" +
									"<p class='p1'>" +
										"<span>最低学历：</span>" +
										"<span>"+data[i].requireDegreeName+"</span>" +
									"</p>" +
									"<p class='p2'>" +
										"<span>工作年限：</span>" +
										"<span>"+data[i].workExperiseName+"</span>" +
									"</p>" +
								"</li>" +
								"<li>" +
									"<p class='p1 p_jx_time'>" +
										"<span class='p_sp1'>进修时长：</span>" +
										"<span>"+courseLengthArrayStr+"</span>" +
									"</p>" +
									"<p class='p2'>" +
										"<span>是否考试：</span>" +
										"<span>"+isRetestName+"</span>" +
									"</p>" +
									"<p class='p3'>" +
										"<a href='javascript:void(0);' onclick="+click+" class='baom'>我要报名</a>" +
									"</p>" +
								"</li>" +
								"<li>" +
									"<p class='p_classtime'>" +
										"<span class='p_sp1'>开课时间：</span>" +
										"<span>"+courseBeginMonthArrayStr+"</span>" +
									"</p>" +
								"</li>" +
								"<li class='last'>" +
									"<p class='p1'>" +
										"<span>特色技术：</span>" +
									"</p>"+
									"<p class='p2'>"+
										"<span>"+feaTechnologyArrayStr+"</span> " +
									"</p>" +
								"</li>" +
							"</ul>" +
						"</li>";
				$("#positionGrid").append(li);
			}
			//分页
			getPage('.fenye','positionGrid',4);
			}else{
				var li="<li class='linoData' style='text-align:center;padding-top:20px;height:175px';border-left:none;background:red;>" +
				"<div style='background-color: #FFF;width:660px;height:145px;margin:15px 15px 15px 15px;text-align:center'>" +
				"<div class='nodata'><span style='position:relative;top:90px;color:#7e7d7d'>无数据</span></div>" +
				"</div>" +
				"</li>";
				$("#positionGrid").append(li);
			}
      } 
   });
}
//加载专科详情页
function loadSpecDetailPage(url,deptSid){
	var data={deptSid:deptSid};
	$("#contentArea").load(ctx+url,data);
}
//查询专科
function searchLevelSpec(){
	Core.AjaxRequest({
		url : ws_url + "/rest/dept/selectSpecLevelByParams",
		type:"POST",
		params:{
			parentSpecSidIsNull:'isNull'
		},
		callback : function (data) {
			var docSpes=data.docSpecs;
			var medSpes=data.medDocSpec;
			var nerseSpes=data.nerseSpec;
			if(docSpes.length>0){
				for(var i=0;i<docSpes.length;i++){
					var option="<option value='' class='label'>"+docSpes[i].specName+"</option>";
					$("#specMore").append(option);
				};
			};
			$( "#specMore" ).easyDropDown({
				cutOff:5,
				
			});
		}
	});
}
//查询更多专科
function searchSpec(){
	Core.AjaxRequest({
		url : ws_url + "/rest/dept/selectSpecByParams",
		type:"POST",
		params:{
			parentSpecSidIsNull:'isNull'
		},
		callback : function (data) {
			var docSpes=data.docSpecs;
			if(docSpes.length>0){
				for(var i=0;i<docSpes.length;i++){
					var option="<option value='' class='label'>"+docSpes[i].specName+"</option>";
					$("#specMore").append(option);
				};
			};
			$( "#specMore" ).easyDropDown({
				cutOff:5,
	
			});
		}
	});
}