$(function(){
		var p_h=$(".con_1 .sm_p");
		
		if(p_h.height()>=10){
			getHeight();
		}else{
			$(".con_1 .xq_more").hide();
		}
		
		
	
	
		$(".public_st input").focus(function(){
			
			$(this).siblings("span").removeClass("docarat").addClass('upcarat');
		
		});
		
		$(".public_st input").blur(function(){
			
			$(this).siblings("span").removeClass("upcarat").addClass('docarat');
		
		});
	
	
	// 专科筛选页 筛选
	$(".chose_x>p").siblings().each(function(){
		
		var _this=$(this).find("span").eq(0).nextAll()
		$(this).find("span").eq(0).nextAll().click(function(){
			 $(_this).removeClass("buxian");
			
			$(_this).eq($(this).index()-1).addClass("buxian");
		});	
	});
	$("#province p").eq(1).find("span").click(function(){
			$("#province p").eq(1).find("span").removeClass();
			$(this).addClass("buxian");
	});
	
	

	$(".tab_type ul li").bind("click",function(){
		$(".tab_type ul li").removeClass();
		$(this).addClass("active");
		
	});
	
	// 医生、护理tab切换
	$(".xwk_tab").click(function(){
		$(".xwk_tab").css({"background-position":"0 90px","color":"#fff"}).removeClass("active");
		$(this).css({"background-position":"0 0","color":"#36d3ff"}).addClass("active");
		
		/*$(".xwk_con ul").css("display","none");
		$(".xwk_con ul").eq($(this).index()).css("display","block");*/
			$(".xwk_con ul").siblings("ul").css("display","none");
			$(".xwk_con ul").siblings("ul").eq($(this).index()).css("display","block");
	});

	$(".xq_tab ul li").click(function(){
		$(".xq_tab ul li").removeAttr("class","active");
		$(this).attr("class","active");
		// $(".xq_content").hide(200);
		// $(".xq_content").eq($(this).index()).show(200)
		$(".xq_content").slideUp(200);		
	});
	
	$(".xq_tab ul li").eq(0).click(function(){
		$(".xq_content").slideDown(200);
	});
	$(".xq_tab ul li").eq(1).click(function(){
		$(".xq_content").eq(1).slideDown(200);
	});
	$(".xq_tab ul li").eq(2).click(function(){
		$(".xq_content").eq(2).slideDown(200);
	});
	
	// ----------------------------------------------
    // 所在地区_展开收缩部分
    $("#province a").each(function(i){
		var a=$("#province span").eq(10).nextAll("span");
		a.hide();
		
	});
    
    var flag=false;
    $("#more").click(function(){
    	var a=$("#province span").eq(10).nextAll("span");
    	if(flag){
    		$("#more").html("更多");
    		a.hide();
    		$("#more").removeAttr().attr("class","more");
    		flag=false;
    	}else{
    		$("#more").html("收缩");
    		a.show();
    		$("#more").removeAttr().attr("class","hide");
    		flag=true;
    	}
})
    
//	checkbox 样式切换
//	$('label').click(function(){
//	    var radioId = $(this).attr('name');
//	    $('label').removeAttr('class') && $(this).attr('class', 'checked');
//	    $('input[type="radio"]').removeAttr('checked') && $('#' + radioId).attr('checked', 'checked');
//	  });
	
	/*var oUl = $("#zk_arousel");
	var aLiUl =$("#zk_arousel li");
	
	var oUl = $("#zk_arousel");
	var aLiUl = $("#zk_arousel li");
	
	var oOl = $("#zk_arousel p");
	var aLiOl = $("#zk_arousel p span");
	
	var oneWidth = aLiUl[0].offsetWidth;
	var iNow = 0;
	var bBtn = true;
	
	for(var i=1;i<aLiUl.length;i++){
		aLiUl[i].style.left = oneWidth + 'px';
	}
	
	
	for(var i=0;i<aLiOl.length;i++){
		aLiOl[i].index = i;
		aLiOl[i].onmouseover = function(){
			
			if(bBtn){
				bBtn = false;
			for(var i=0;i<aLiOl.length;i++){
				aLiOl[i].className = '';
			}
			this.className = 'active';
			
			if(iNow < this.index){
				aLiUl[this.index].style.left = oneWidth + 'px';
				startMove( aLiUl[iNow] , { left : - oneWidth } );
			}
			else if(iNow > this.index){
				aLiUl[this.index].style.left = - oneWidth + 'px';
				startMove( aLiUl[iNow] , { left :  oneWidth } );
			}
			
			startMove( aLiUl[this.index] ,{ left : 0 },function(){
				bBtn = true;
				
			} );
			iNow = this.index;
			
			}
			
		};
	}*/
	
	
	

});
function getHeight(){
	var zkflag=true;
	$(".con_1 .xq_more span").bind("click",function(){
		/*$(this).parent().slideDown();*/
		if(zkflag){
			$(this).parent().siblings(".sm_p").css({height:"auto"});
			zkflag=false;
		}else{
			$(this).parent().siblings(".sm_p").css({height:"44px"});
			zkflag=true;
		}
		
	});
}
	


