getHosName('21513257-77bf-11e5-b58a-00ff11c9bcf0');
//getValidLearnNum(1);
getNotApproveReusmeNum('21513257-77bf-11e5-b58a-00ff11c9bcf0');
//getDeptPassResumeNum(1);
//查询医院名称
function getHosName(deptSid) {
    Core.AjaxRequest({
        url: ws_url + "/rest/dept/selectHosByDept/" + deptSid,
        type: "GET",
        callback: function(data) {
            console.log(data);
            $("#hosNameEdu").html(data.hospitalName + "  " + data.deptName + "科室");
        }
    });
}

//查询有效进修数量
function getValidLearnNum(hosEduSid) {
    Core.AjaxRequest({
        url: ws_url + "/rest/learn/selectLearnByParams",
        type: "POST",
        params: {
            medEduSid: hosEduSid
        },
        callback: function(data) {
            console.log(data);
            if (data.length > 0) {
                $("#validLearnNum").html(data.length);
            } else {
                $("#validLearnNum").html(0);
            }
        }
    });
}

//查询待处理进修申请
function getNotApproveReusmeNum(deptSid) {
    Core.AjaxRequest({
        url: ws_url + "/rest/resume/selectResumeByParams",
        type: "POST",
        params: {
            deptSid: deptSid,
            status: '08'
        },
        callback: function(data) {
            console.log(data);
            if (data.length > 0) {
                $("#notApproveReusmeNum").html(data.length);
            } else {
                $("#notApproveReusmeNum").html(0);
            }
        }
    });
}

//查询科室通过进修申请
function getDeptPassResumeNum(hosEduSid) {
    Core.AjaxRequest({
        url: ws_url + "/rest/resume/selectResumeByParams",
        type: "POST",
        params: {
            medicalEduPartSid: hosEduSid,
            status: '03'
        },
        callback: function(data) {
            console.log(data);
            if (data.length > 0) {
                $("#deptPassNum").html(data.length);
            } else {
                $("#deptPassNum").html(0);
            }
        }
    });
}