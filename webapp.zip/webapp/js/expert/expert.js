$(function(){
    
	// ----------------------------------------------
	// 医院新闻列表_隐藏显示部分
	var tabs_i=0
	$('.listhide').click(function(){
		var _self = $(this);
		var j = $('.listhide').index(_self);
		if( tabs_i == j ) return false; tabs_i = j;
		$('.listhide p').each(function(e){
			if(e==tabs_i){
				$('p',_self).removeClass('v01').removeClass('v').addClass('v02');
			}else{
				$(this).removeClass('v02').addClass('v01');
			}
		});
		$('.listshow').slideUp().eq(tabs_i).slideDown();
	});
	
	
	
	// ----------------------------------------------
	// english 鼠标悬浮 提示升级
	$('.en').hover(
			function(){
				
				$(".sy_update").animate({
					"top" : "0px"
				});
				},function(){
				
				$(".sy_update").animate({
					"top" : "-25px"
				});
				
			}
		)
		
		
		
	// ----------------------------------------------
    // 所在地区_展开收缩部分
    $(".condition_box dl dd").each(function(i){
		var a=$(".condition_box dl").children('dd').eq(9).nextAll("dd");
		a.hide();
		$(".more").click(function(){
				a.show();
				$(".more").css("display","none");
				$(".hide").css("display","block");
		})
		$(".hide").click(function(){
				a.hide();
				$(".hide").css("display","none");
				$(".more").css("display","block");
		})
		
	});
	
	
	
	// ----------------------------------------------
	// 专科进修，管理进修，研修班_切换部分
	$("#tab_zk li").click(function(){
		$("#tab_zk li").attr("class","");
		$(this).attr("class","active");
		$(".tab_zk_con").css("display","none");
		$(".tab_zk_con").eq($(this).index()).css("display","block");
	});
	
})

//根据用户SID查询用户
function selectUserBySid(userSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/user/selectUserBySid/"+userSid, 
		type:"get",
		async:false,
		callback : function (data) {
			$("#userImage").attr("src",ctx+"/"+data.faceImage);
			$("#userName").html(data.realName);
			$("#userLocation").html(data.cityName);
			$(".userHos").html(data.hosName);
			$(".userDept").html(data.deptName);
			$(".userTitle").html(data.workTitle);
			if("01"==data.isDean){
				$("#workDuty").html("院长");
			}else{
				$("#workDuty").html(data.workDuty);
			}
			$("#userImage").attr(data.faceImage);
			
			$(".userHos").html(data.hosName);
			$(".speaker").html(data.realName);
			$("#name").html(data.realName);
			
			$("#eduTitle").html(data.teachTitle);
			$("#eduTitle").html(data.teachTitle);
			$("#keySkills").html(data.keySkills);
			$("#keyManSkill").html(data.keyManageSkills);
			$("#thesisNum").html(data.thesisNum+"篇");
			$("#overSeaPro").html(data.overseasExp);
			$("#eduPro").html(data.educateExp);
			$("#cliResult").html(data.clinicalResults);
			$("#workPro").html(data.workExp);
			$("#perHonor").html(data.pessonalHonor);
			
			
			
		} 
	});
}