$(function() {

    $("#province dd").click(function() {
        $("#province dd").removeClass();
        $(this).addClass("active");
    });
    $("#hosLevel dd").click(function() {
        $("#hosLevel dd").removeClass();
        $(this).addClass("active");
    });

    // ----------------------------------------------
    // 医院新闻列表_隐藏显示部分
    var tabs_i = $('.listhide').click(function() {
        var _self = $(this);
        var j = $('.listhide').index(_self);
        if (tabs_i == j) return false;
        tabs_i = j;
        $('.listhide p').each(function(e) {
            if (e == tabs_i) {
                $('p', _self).removeClass('v01').removeClass('v').addClass('v02');
            } else {
                $(this).removeClass('v02').addClass('v01');
            }
        });
        $('.listshow').slideUp().eq(tabs_i).slideDown();
    });

    // ----------------------------------------------
    // english 鼠标悬浮 提示升级
    $('.en').hover(function() {

        $(".sy_update").animate({
            "top": "0px"
        });
    },
    function() {

        $(".sy_update").animate({
            "top": "-25px"
        });

    })

    // ----------------------------------------------
    // 所在地区_展开收缩部分
    $(".condition_box dl dd").each(function(i) {
        var a = $(".condition_box dl").children('dd').eq(8).nextAll("dd");
        a.hide();
        $(".more").click(function() {
            a.show();
            $(".more").css("display", "none");
            $(".hide").css("display", "block");
        }); 
        $(".hide").click(function() {
            a.hide();
            $(".hide").css("display", "none");
            $(".more").css("display", "block");
        });

    });

    // ----------------------------------------------
    // 专科进修，管理进修，研修班_切换部分
    $("#tab_zk li").click(function() {
        $("#tab_zk li").attr("class", "");
        $(this).attr("class", "active");
        $(".tab_zk_con").css("display", "none");
        $(".tab_zk_con").eq($(this).index()).css("display", "block");
    });

});

//查询条件
var params = function() {
    var specSid = $("#specSelect").val();
    if ("00" != specSid) {
        this.specSid = specSid;
    } else {
        this.specSid = null;
    }
    this.hospitalProvince = null;
    this.hospitalLevel = null;
    this.hospitalName = null;
}
var selectParams = new params();
//条件查询
function selectByParams(provinceSid, hosLevelCode) {
    if ("00" != provinceSid && provinceSid != null) {
        selectParams.hospitalProvince = provinceSid;
    } else if ("00" == provinceSid) {
        selectParams.hospitalProvince = null;
    }

    if ("00" != hosLevelCode && hosLevelCode != null) {
        selectParams.hospitalLevel = hosLevelCode;
    } else if ("00" == hosLevelCode) {
        selectParams.hospitalLevel = null;
    }

    selectParams.hospitalName = $("#search_input").val();
    selectHospital();
}
//查询省
function selectProvince() {
    Core.AjaxRequest({
        url: ws_url + "/rest/system/PROVINCE",
        type: "get",
        async: false,
        callback: function(data) {
            if (data != null && data.length > 0) {
                var onClick = "selectByParams('00',null)";
                var option = "<dd class='active'><a href='javascript:;' onClick=" + onClick + ">全国</a></dd>";
                $("#province").append(option).click(function() {

});
                for (var i = 0; i < data.length; i++) {
                    if (i == 8) {
                        var dt = "<dt>&nbsp;</dt>";
                        $("#province").append(dt);
                    } else {
                        var onClick = "selectByParams('" + data[i].codeValue + "',null)";
                        var option = "<dd><a href='javascript:;' onClick=" + onClick + ">" + data[i].codeDisplay + "</a></dd>";
                        $("#province").append(option);
                        if (i == 16) {
                            break;
                        }
                    }
                }
            }
        }

    });
}
//查询医院等级
function selectHosLevel() {
    Core.AjaxRequest({
        url: ws_url + "/rest/system/HOSPITAL_LEVEL",
        type: "get",
        async: false,
        callback: function(data) {
            if (data != null && data.length > 0) {
                var onClick = "selectByParams(null,'00')";
                var option = "<dd class='active'><a href='javascript:;' onClick=" + onClick + ">不限</a></dd>";
                $("#hosLevel").append(option);
                for (var i = 0; i < data.length; i++) {
                    var onClick = "selectByParams(null,'" + data[i].codeValue + "')";
                    var option = "<dd><a href='javascript:;' onClick=" + onClick + ">" + data[i].codeDisplay + "</a></dd>";
                    $("#hosLevel").append(option);
                }
            }
        }
    });
}
//查询专科分类
function selectSpec() {
    Core.AjaxRequest({
        url: ws_url + "/rest/dept/selectDeptBySpec",
        type: "POST",
        params: {},
        callback: function(data) {
            var option = "<option value='00' class='label'>全部</option>";
            $("#specSelect").append(option);
            for (var i = 0; i < data.length; i++) {
                //填充按专科查询进修
                var option = "<option value='" + data[i].specSid + "'>" + data[i].specName + "</option>";
                $("#specSelect").append(option);
            }

            $('#specSelect').easyDropDown({
                cutOff: 10,

            });

        }
    });
}

//查询医院
function selectHospital() {
    console.log(selectParams);
    Core.AjaxRequest({
        url: ws_url + "/rest/dept/selectHospitalByParams",
        type: "POST",
        params: selectParams,
        callback: function(data) {
            $("#hospitals dl").remove();
            if (data != null && data.length > 0) {
                for (var i = 0; i < data.length; i++) {
                    var deptName = data[i].deptName;
                    if (deptName == null) {
                        deptName = '';
                    }
                    var hos = "<dl>" + "<a href='" + ctx + "/pages/hospital/hospital-detail.jsp?hospitalSid=" + data[i].hospitalSid + "'><img src='" + ctx + "/" + data[i].hosImage + "' style='height:130px;width:210px;'></a>" + "<dt><a href='" + ctx + "/pages/hospital/hospital-detail.jsp?hospitalSid=" + data[i].hospitalSid + "'>" + data[i].hospitalName + "</a></dt>" + "<dd>等级：" + data[i].hosLevelName + "</dd>" + "<dd>擅长领域：" + deptName + "</dd>" + "<dd>所在地区：" + data[i].provinceName + "<span class='area'></span></dd>" + " </dl>";
                    $("#hospitals").append(hos);
                }

                //分页
                /*getPage('.fenye','hospitals',3);*/
            } else {
            
                var li = "<li style='text-align:center;padding-top:20px;'>" + "<div style='background-color: #FFF;width:692px;height:145px;margin-top:30px;'>" + "<div class='nodata'><span style='position:relative;top:90px;color:#7e7d7d'>无数据</span></div>" + "</div>" + "</li>";
                $("#hospitals").append(li);
            }
            createShadow("#hospitals dl>a");
           
        }
    
   
    
    });
    
   
}