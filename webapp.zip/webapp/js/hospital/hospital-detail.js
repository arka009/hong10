
//根据医院SID查询医院
function getHosBySid(hospitalSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectHosBySid/"+hospitalSid, 
		type:"get",
		async:false,
		callback : function (data) {
			console.log(data);
			$(".hosName").html(data.hospitalName);
			$("#hosFea").html(data.hosFeature);
			$("#hosSwitchBoard").html(data.switchBorad);
			$("#medCell").html(data.medEduCell);
			$("#hosImage").attr("src",ctx+"/"+data.hosImage);
			
			$("#hosBriefInfo").html(data.hosbirefInfo);
			$("#hosCity").html("城市："+data.provinceName);
			$("#bedNum").html("床位数："+data.bedNum);
			$("#organizePeopleNum").html("在编人数："+data.organizePeopleNum);
			$("#hospitalHomePage").html("主页："+data.hospitalHomePage);
        } 
     });
}

//查询重点学科
function selectKeySpec(hospitalSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectDept", 
		type:"post",
		params:{
			hospitalSid:hospitalSid,
			isKeySpec:'01'
		},
		callback : function (data) {
			var keySpec="";
			$.each(data,function(index,content){
				keySpec+=content.specName+" ";
			});
			$("#keySpec").html(keySpec);
        } 
     });
}

//查询科室
function selectDeptByHosSid(hospitalSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectDept", 
		type:"post",
		params:{
			hospitalSid:hospitalSid
		},
		callback : function (data) {
//			var dd="<dd></dd>";
//			var ul="<ul></ul>";
//			$(dd).append($(ul));
			$.each(data,function(index,content){
				var onClick="selectPosByDept('"+content.deptSid+"')";
				var li="<li><a href='javaScript:;' onClick="+onClick+">"+content.deptName+"</a></li>";
				$("#deptByHosSid").append(li);
//				$(ul).append(li);
			});
        } 
     });
}

//查询条件
var selectParams=function(){
	this.hospitalSid=hospitalSid;
	this.positionStatus='01';
};

//点击科室查询进修
function selectPosByDept(deptSid){
	params.deptSid=deptSid; 
	selectPositionByParams();
	
}
// 条件查询简历
function selectPositionByParams(){
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selectPositionByParams", 
		type:"POST",
		params:params,
		callback : function (data) {
			$("#positionGrid li").remove();
			for(var i=0;i<data.length;i++){
				
				if(data[i].courseLength!=null){
					//处理进修时长添加”个月“
					var courseLengthArray=data[i].courseLength.split(",");
					var courseLengthArrayStr="";
					if(courseLengthArray.length>0){
						for(var j=0;j<courseLengthArray.length;j++){
							courseLengthArrayStr+=courseLengthArray[j]+"个月 ";
						}
					}
				}
			if(data[i].courseBeginMonth!=null){
				//处理进修时长添加”个月“
				var courseBeginMonthArray=data[i].courseBeginMonth.split(",");
				var courseBeginMonthArrayStr="";
				if(courseBeginMonthArray.length>0){
					for(var j=0;j<courseBeginMonthArray.length;j++){
						courseBeginMonthArrayStr+=courseBeginMonthArray[j]+"月 ";
					}
				}
			}
				
				//处理特色技术
				var feaTechnologyArrayStr="";
				if(data[i].feaTechnology!=null){
					var feaTechnologyArray=data[i].feaTechnology.split(",");
					if(feaTechnologyArray.length>0){
						for(var j=0;j<feaTechnologyArray.length;j++){
							feaTechnologyArrayStr+=feaTechnologyArray[j]+" ";
						}
					}
				}
				
				
				//处理是否复试
				var isRetest=data[i].isRetest;
				var isRetestName="";
				if("01"==isRetest){
					isRetestName="是";
				}else{
					isRetestName="否";
				}
				//填充按专科查询进修
				var li="<li>" +
							"<ul>" +
								"<li class='first'>" +
									"<h4><a href='"+ctx+"/pages/spec/spec-detail.jsp?deptSid="+data[i].deptSid+"'>"+data[i].deptName+"</a></h4>" +
									"<p>［无界推荐］ 学习机会多、易申请、导师好</p>" +
								"</li>" +
								"<li>" +
									"<p class='p1'>" +
										"<span>最低学历：</span>" +
										"<span>"+data[i].requireDegreeName+"</span>" +
									"</p>" +
									"<p class='p2'>" +
										"<span>工作年限：</span>" +
										"<span>"+data[i].workExperiseName+"</span>" +
									"</p>" +
								"</li>" +
								"<li>" +
									"<p class='p1 p_jx_time'>" +
										"<span class='p_sp1'>进修时长：</span>" +
										"<span>"+courseLengthArrayStr+"</span>" +
									"</p>" +
									"<p class='p2'>" +
										"<span>是否考试：</span>" +
										"<span>"+isRetestName+"</span>" +
									"</p>" +
									"<p class='p3'>" +
										"<a href='"+ctx+"/pages/spec/spec-detail.jsp?deptSid="+data[i].deptSid+"' class='baom'>我要报名</a>" +
									"</p>" +
								"</li>" +
								"<li>" +
									"<p class='p_classtime'>" +
										"<span class='p_sp1'>开课时间：</span>" +
										"<span>"+courseBeginMonthArrayStr+"</span>" +
									"</p>" +
								"</li>" +
								"<li class='last'>" +
									"<p class='p1'>" +
										"<span>特色技术：</span>" +
										
								
									"</p>" +
									"<p class='p2'>" +
								
									
									"<span class='val'>"+feaTechnologyArrayStr+"</span> " +
								"</p>" +
								"</li>" +
							"</ul>" +
						"</li>";
				$("#positionGrid").append(li);
			}
			//分页
			getPage('.fenye','positionGrid',3);
      } 
   });
}

//查询院长
function getDeanByDeptSid(hospitalSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/user/selectTutorBySpec", 
		type:"POST",
		params:{
			hospitalSid:hospitalSid,
			isDean:'01'
		},
		callback : function (data) {
			console.log("leader@@@@@@@@@"+data);
			if(data!=null&&data.length>0){
				$.each(data,function(index,content){
					$("#deanPer").attr("href",ctx+"/pages/expert/expert-personal.jsp?userSid="+content.userSid);
					$("#deanName").html(content.realName);
					$("#deanInfo").html(content.briefInfo);
					$("#teachTitle").html(content.teachTitle);
					$("#clinicalTitle").html(content.workTitle);
					$("#deanFaceImage").attr("src",ctx+"/"+content.faceImage);
					var keySkills=content.keySkills.split("，");
					$.each(keySkills,function(i,con){
						var span="<span>"+con+"</span>";
						$("#keySkills").append(span);
					});
					var keyManSkills=content.keyManageSkills.split("，");
					$.each(keyManSkills,function(i,con){
						var span="<span>"+con+"</span>";
						$("#keyManSkills").append(span);
					});
				});
			}
		}
	});
}
$(function(){
	$("#tab_zk li").click(function(){
		$("#tab_zk li").attr("class","");
		$(this).attr("class","active");
		$(".tab_zk_con").css("display","none");
		$(".tab_zk_con").eq($(this).index()).css("display","block");

	});
});

