$(function(){
    
	
	// ----------------------------------------------
	// english 鼠标悬浮 提示升级
	$('.en').hover(
			function(){
				
				$(".sy_update").animate({
					"top" : "0px"
				});
				},function(){
				
				$(".sy_update").animate({
					"top" : "-25px"
				});
				
			}
		)
		
		
	// ----------------------------------------------
	// 左侧菜单点击，右侧切换部分
	$("#sbar li").click(function(){
		$("#sbar li").attr("class","");
		$(this).attr("class","active");
		$(".results_all").css("display","none");
		$(".results_all").eq($(this).index()).css("display","block");
	});
	
})
