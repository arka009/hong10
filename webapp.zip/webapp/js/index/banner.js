function checkL() {
    var oMes = $(".message span");
    $("#username").blur(function() {
        var val = $(this).val();
        var regMail = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
        if (val.search(regMail) == -1) {
            oMes.text("邮箱格式不正确！");
        } else if (val == null || val == "") {
            oMes.text("邮箱不得为空！");
        } else {
            oMes.text("1");
            $(this).data({
                "s": 1
            })
        }
    });
    $("#password").blur(function() {
        var val = $(this).val();
        if (val.length > 12 && val.length < 16) {

            $(this).data({
                "s": 1
            })
        } else {
            oMes.text("密码长度必须在12位到16位之间");
        }
    });

    $(":button").click(function() {
        $("#username").blur();
        $("#password").blur();

        var totl = 0;
        $(".auth").each(function() {
            totl += $(this).data("s")
        });
        if (totl == 2) {
            $("form").submit();
        }

    });

}




function getShowHide(obj, obj_son) {
    $(obj).each(function() {
        var a = $(obj).eq(1);
        var flag = true;
        $(obj_son).click(function() {
            if (flag) {
                a.slideUp("fast").hide();
                flag = false;
            } else {
                a.slideDown("fast").show();
                flag = true;
            }

        });
    });
}
//tab切换
/*function getTab(obj, obj2) {
    $(obj).click(function() {
        $(obj).attr("class", "");
        $(this).attr("class", "active");
        //		 $(obj2).css("display","none");
        //		 $(obj2).eq($(this).index()).css("display","block");
    });
}*/

$(function() {
	
//	导航
	$(".head ul a").bind("click",function(){
		$(".head ul a").removeClass("active");
		$(this).addClass("active");
	});
	

    var arrRandomText = ['我们一定要给自己提出这样的任务：第一，学习，第二是学习，第三还是学习。 —— 列宁', '现在，我怕的并不是那艰苦严峻的生活，而是不能再学习和认识我迫切想了解的世界。对我来说，不学习，毋宁死。 —— 罗蒙诺索夫', '如果学习只在于模仿，那么我们就不会有科学，也不会有技术。 —— 高尔基', '生命是一种语言，它为我们转达了某种真理；如果以另一种方式学习它，我们将不能生存。 —— 叔本华'];
    var textP = $(".secret1");
    var index_ = Math.floor((Math.random() * arrRandomText.length));
    textP.text(arrRandomText[index_]);
    $(".hy_box_big,.gljx_box").each(function() {
        $(this).find(".hyjx_box").eq(1).css({
            /*"border-bottom":"1px solid #e5e5e5",*/
            "border-top": "1px solid #e5e5e5"
        });
    });

    // banner
    var bn_id = 0;
    var bn_id2 = 1;
    var speed33 = 5000;
    var qhjg = 1;
    var MyMar33;
    $("#banner .d1").hide();
    $("#banner .d1").eq(0).fadeIn("slow");
    if ($("#banner .d1").length > 1) {
        $("#banner_id li").eq(0).addClass("nuw");
        function Marquee33() {
            bn_id2 = bn_id + 1;
            if (bn_id2 > $("#banner .d1").length - 1) {
                bn_id2 = 0;
            }
            $("#banner .d1").eq(bn_id).css("z-index", "2");
            $("#banner .d1").eq(bn_id2).css("z-index", "1");
            $("#banner .d1").eq(bn_id2).show();
            $("#banner .d1").eq(bn_id).fadeOut("slow");
            $("#banner_id li").removeClass("nuw");
            $("#banner_id li").eq(bn_id2).addClass("nuw");
            bn_id = bn_id2;
        };

        MyMar33 = setInterval(Marquee33, speed33);

        $("#banner_id li").click(function() {
            var bn_id3 = $("#banner_id li").index(this);
            if (bn_id3 != bn_id && qhjg == 1) {
                qhjg = 0;
                $("#banner .d1").eq(bn_id).css("z-index", "2");
                $("#banner .d1").eq(bn_id3).css("z-index", "1");
                $("#banner .d1").eq(bn_id3).show();
                $("#banner .d1").eq(bn_id).fadeOut("slow",
                function() {
                    qhjg = 1;
                });
                $("#banner_id li").removeClass("nuw");
                $("#banner_id li").eq(bn_id3).addClass("nuw");
                bn_id = bn_id3;
            }
        });
        $("#banner_id").hover(function() {
            clearInterval(MyMar33);
        },
        function() {
            MyMar33 = setInterval(Marquee33, speed33);
        });
    } else {
        $("#banner_id").hide();
    }

    // banner end

    // ----------------------------------------------
    // english 鼠标悬浮 提示升级
    $('.en').hover(function() {

        $(".sy_update").animate({
            "top": "0px"
        });
    },
    function() {

        $(".sy_update").animate({
            "top": "-25px"
        });

    });

    // 专科找进修部分  _伸展、收缩部分
    $(".tab_zk_con ul li").each(function(i) {
        var a = $(".tab_zk_con ul").children('li').eq(0).nextAll("li");
        var flag = true;
        $(".zk").click(function() {
            if (flag) {
                a.slideUp("fast").hide();
                flag = false;
            } else {
                a.slideDown("fast").show();
                flag = true;
            }

        });
    });

    //按专科查询进修，收缩	
    var xflag = true;

    $(".xxg").each(function() {
        $(".xxg").click(function() {
            if (xflag) {
                $(".zjjx .zk_con").children('ul').eq(1).show();
                $(this).css({
                    "background": "url(../img/drop_up.png) no-repeat"
                });
                xflag = false;
            } else {
                $(".zjjx .zk_con").children('ul').eq(1).hide();
                $(this).css({
                    "background": "url(../img/drop_down.png) no-repeat"
                });
                xflag = true;
            }

        });
    })

    // 按导师找进修 ___伸展、收缩
    var dsflag = true;
    $(".ds").click(function() {
        var a = $(".dsjx .zk_con").children('ul').eq(1);
        if (dsflag) {
            a.slideUp("fast").hide();
            dsflag = false;
        } else {
            a.slideDown("fast").show();
            dsflag = true;
        }

    });

    getShowHide(".ys_gl .hyjx_box", ".ysgl"); // 医生管理进修部分 __伸展、收缩
    getShowHide(".yxclass .zk_con ul", ".ys"); // 研修班部分 __伸展、收缩
    getShowHide(".gljx_small_box", ".gljxx");

    $(".ys_gl ul li").click(function() {

        $(".ys_gl ul li").attr("class", "");
        $(this).attr("class", "active");
        $(".ys_gl .ys_gl_box").css("display", "none");
        $(".ys_gl .ys_gl_box").eq($(this).index()).css("display", "block");
    });

    //海外进修 ___伸展、收缩
    $(".hy_box_big").each(function(i) {
        var a = $(".hy_box_big").eq(i).children('.hyjx_box').eq(1);
        var flag = true;
        $(".gl").click(function() {
            if (flag) {
                a.slideUp("fast").hide();
                flag = false;
            } else {
                a.slideDown("fast").show();
                flag = true;
            }

        });
    });

    // 专科找进修部分  _切换部分
    $("#tab_zk li").click(function() {
        $("#tab_zk li").attr("class", "");
        $(this).attr("class", "active");
        $(".tab_zk_con").css("display", "none");
        $(".tab_zk_con").eq($(this).index()).css("display", "block");

    });

    getTab("#gljx_city li", ".hy_box_big"); //海外进修部分  _切换部分
    getTab("#tab_yy li", ".tb_city"); //医院找进修部分  _切换部分
   /*getTab("#all_ds li",".dsjx .zk_con"); //导师找进修部分 _切换部分
*/

    $("#gljx").children('li').each(function() {
        $("#gljx li").click(function() {
            $("#gljx li").attr("class", "");
            $(this).attr("class", "active");

            $(".gljx_box ul").css("display", "none");
            $(".gljx_box ul").eq($(this).index()).css("display", "block");
            $(".gljx_banner").children('.gljx_banner_1').css("display", "none");
            $(".gljx_banner").children('.gljx_banner_1').eq($(this).index()).css("display", "block");
        });
    });

    $(".gljx_box ul").each(function() {
        $(".gljx_box ul").children('li').each(function() {
            $(".gljx_box ul").children('li').css("display", "none");
            $(".gljx_box ul").eq($(this).index()).children('li').eq($(this).index()).css("display", "block");
        });
    });

    // $(".gljx_box").children('ul').eq(0).children('li').click(function(){
    // 	$(".gljx_box").children('ul').eq(0).children('li').attr("class","")
    // 	$(this).attr("class","active");
    // });
    // $(".gljx_box").children('ul').eq(1).children('li').click(function(){
    // 	$(".gljx_box").children('ul').eq(1).children('li').attr("class","")
    // 	$(this).attr("class","active");
    // })
    // $(".gljx_box").children('ul').eq(2).children('li').click(function(){
    // 	$(".gljx_box").children('ul').eq(2).children('li').attr("class","")
    // 	$(this).attr("class","active");
    // })
    // $(".gljx_box").children('ul').eq(3).children('li').click(function(){
    // 	$(".gljx_box").children('ul').eq(3).children('li').attr("class","")
    // 	$(this).attr("class","active");
    // })
    // $(".gljx_box").children('ul').eq(4).children('li').click(function(){
    // 	$(".gljx_box").children('ul').eq(4).children('li').attr("class","")
    // 	$(this).attr("class","active");
    // })

});