/**
 * Creator: Vincent
 * Date created: 13-2-17 下午12:09
 * Contact: QQ 77642304
 * Describe: 幻灯片效果
 */

   
searchSpec();
selectLearnByParams("01",null,null);
//selectProvince();
selectHosByProvince("01");
selectSpec();
selectUserBySpec(null);
//查询专科
var dataDocSpec=new Array(
		{"specSid":"30f00616-4d80-11e5-b4fa-480fcf280719","specName":"呼吸内科"},
		{"specSid":"30fa5de2-4d80-11e5-b4fa-480fcf280719","specName":"心血管内科"},
		{"specSid":"310e48ca-4d80-11e5-b4fa-480fcf280719","specName":"神经内科"},
		{"specSid":"3116a039-4d80-11e5-b4fa-480fcf280719","specName":"血液内科"},
		{"specSid":"317c9599-4d80-11e5-b4fa-480fcf280719","specName":"肾内科"},
		{"specSid":"30ff2837-4d80-11e5-b4fa-480fcf280719","specName":"消化内科"},
		{"specSid":"3125aa5d-4d80-11e5-b4fa-480fcf280719","specName":"内分泌科"},
		{"specSid":"3131d436-4d80-11e5-b4fa-480fcf280719","specName":"风湿免疫科"},
		{"specSid":"314c2e5e-4d80-11e5-b4fa-480fcf280719","specName":"变态反应科"},
		{"specSid":"5ec920f4-4d80-11e5-b4fa-480fcf280719","specName":"胸外科"},
		{"specSid":"5ed3c698-4d80-11e5-b4fa-480fcf280719","specName":"心脏外科"},
		{"specSid":"5edafffe-4d80-11e5-b4fa-480fcf280719","specName":"神经外科"},
		{"specSid":"5eec4fb3-4d80-11e5-b4fa-480fcf280719","specName":"骨科"},
		{"specSid":"5f1b322c-4d80-11e5-b4fa-480fcf280719","specName":"泌尿外科"},
		{"specSid":"5ee3b529-4d80-11e5-b4fa-480fcf280719","specName":"普外科"},
		{"specSid":"5f0dd142-4d80-11e5-b4fa-480fcf280719","specName":"血管外科"},
		{"specSid":"5ef6e183-4d80-11e5-b4fa-480fcf280719","specName":"胃肠外科"},
		{"specSid":"5f3b0e73-4d80-11e5-b4fa-480fcf280719","specName":"头颈外科"},
		
		{"specSid":"9f8fb2d2-4d80-11e5-b4fa-480fcf280719","specName":"产科"},
		{"specSid":"c739afe1-4d80-11e5-b4fa-480fcf280719","specName":"儿科"},
		{"specSid":"eff3989d-4d80-11e5-b4fa-480fcf280719","specName":"口腔科"},
		
		{"specSid":"310573ee-4d80-11e5-b4fa-480fcf280719","specName":"肿瘤科"},
		{"specSid":"43484a9b-4d83-11e5-b4fa-480fcf280719","specName":"眼科"},
		{"specSid":"a19f143c-4d83-11e5-b4fa-480fcf280719","specName":"重症医学"},
		{"specSid":"7caac1be-4d83-11e5-b4fa-480fcf280719","specName":"急诊科"},
		{"specSid":"0bf87cb7-4d83-11e5-b4fa-480fcf280719","specName":"中医科"},
		{"specSid":"5e84ef6f-4d83-11e5-b4fa-480fcf280719","specName":"皮肤科"},
		{"specSid":"31e7b682-4d84-11e5-b4fa-480fcf280719","specName":"介入科"},
		{"specSid":"4e4a8bd4-4d84-11e5-b4fa-480fcf280719","specName":"麻醉科"},
		{"specSid":"315841c4-4d80-11e5-b4fa-480fcf280719","specName":"感染科"},
		{"specSid":"5df079e0-4d84-11e5-b4fa-480fcf280719","specName":"烧伤整形科"},
		{"specSid":"9ad909a2-4d84-11e5-b4fa-480fcf280719","specName":"临床心理科"}
        
        );
var dataMedDocSpec=new Array(
		{"specSid":"f8ca4624-4d84-11e5-b4fa-480fcf280719","specName":"超声科"},
		{"specSid":"f8dd7236-4d84-11e5-b4fa-480fcf280719","specName":"放射科"},
		{"specSid":"f8fdc133-4d84-11e5-b4fa-480fcf280719","specName":"磁共振室"},
		{"specSid":"f8d364bc-4d84-11e5-b4fa-480fcf280719","specName":"核医学"},
		{"specSid":"f8a9f8a8-4d84-11e5-b4fa-480fcf280719","specName":"检验科"},
		{"specSid":"f8bb34af-4d84-11e5-b4fa-480fcf280719","specName":"药剂科"},
		{"specSid":"f8c17397-4d84-11e5-b4fa-480fcf280719","specName":"病理科"},
		{"specSid":"f908d9b8-4d84-11e5-b4fa-480fcf280719","specName":"内镜中心"},
		{"specSid":"f8e7dbfb-4d84-11e5-b4fa-480fcf280719","specName":"营养科"},
		{"specSid":"f9206104-4d84-11e5-b4fa-480fcf280719","specName":"PET中心"},
		{"specSid":"f92ba6ed-4d84-11e5-b4fa-480fcf280719","specName":"病案科"}
        );
var dataNerseSpecs=new Array(
		{"specSid":"","specName":"呼吸内科"},
		{"specSid":"","specName":"心血管内科"},
		{"specSid":"","specName":"神经内科"},
		{"specSid":"","specName":"血液内科"},
		{"specSid":"","specName":"肾内科"},
		{"specSid":"","specName":"消化内科"},
		{"specSid":"","specName":"康复医学科"},
		{"specSid":"","specName":"胸外科"},
		{"specSid":"","specName":"心脏外科"},
		{"specSid":"","specName":"神经外科"},
		{"specSid":"","specName":"骨科"},
		{"specSid":"","specName":"泌尿外科"},
		{"specSid":"","specName":"普外科"},
		{"specSid":"","specName":"急诊科"},
		{"specSid":"","specName":"手术室"},
		{"specSid":"","specName":"产科"},
		{"specSid":"","specName":"儿科"},
		{"specSid":"","specName":"肿瘤科"},
		{"specSid":"","specName":"感染科"},
		{"specSid":"","specName":"重症医学"},
		{"specSid":"","specName":"护理管理"}
        
);
function searchSpec(){
	Core.AjaxRequest({
		url : ws_url + "/rest/dept/selectSpecByParams",
		type:"POST",
		params:{
			parentSpecSidIsNull:'isNull'
		},
		callback : function (data) {
			// 生成服务目录表
			console.log("专科");
			console.log(data);
			var doc=$("#doctorLearn");
			var doc1=$("#doctorLearn1");
			var docUl=$("#doctorLearnUl");
			var medDoc=$("#medDocLearn");
			var medDoc1=$("#medDocLearn1");
			var medDocUl=$("#medDocLearnUl");
			var nerse=$("#nursLearn");
			var nerse1=$("#nursLearn1");
			var nerseUl=$("#nursLearnUl");
			var docSpes=dataDocSpec;
//			var medDocSpecs=data.medDocSpecs;
			var medDocSpecs=dataMedDocSpec;
//			var nerseSpecs=data.nerseSpecs;
			var nerseSpecs=dataNerseSpecs;
			if(docSpes.length>0){
				
				var j=0;
				
				for(var i=0;i<docSpes.length;i++){
					var ahref="../pages/spec/spec-filter.jsp?specSid="+docSpes[i].specSid;
					var a="<a class='box1' href='"+ahref+"'>"+docSpes[i].specName+"</a>";
					var a1="<a class='curr' href='"+ahref+"'>"+docSpes[i].specName+"</a>";
				
					//填充菜单栏，欠缺数量控制
					doc.append(a);
					
					//填充菜单弹出栏，欠缺数量控制
					doc1.append(a1);
					
					//填充按专科查询进修
					if(i!=7&&i!=8&&i!=16&&i!=17){
						if(j==0){
							var li=$("<li></li>");
							docUl.append(li);
							j++;
						}else{
							if(j==6){
								j=0;
							}else{
								j++;
							};
						};
						var test='"'+docSpes[i].specSid+'"';
						var onClick="selectLearnByParams('01',null,null,"+test+")";
						var aUl="<a  href='javascript:;'style='width:97px' onclick="+onClick+">"+docSpes[i].specName+"</a>";
						$("#doctorLearnUl li:last").append(aUl);
					}
				};
				
				//填充按专科查询进修
			};
			if(medDocSpecs.length>0){
				var j=0;
				for(var i=0;i<medDocSpecs.length;i++){
					var a="<a class='box1' href='../pages/spec/spec-filter.jsp'>"+medDocSpecs[i].specName+"</a>";
					var a1="<a class='curr' href='../pages/spec/spec-filter.jsp'>"+medDocSpecs[i].specName+"</a>";
					
					//填充菜单栏，欠缺数量控制
					medDoc.append(a); 
					
					//填充菜单弹出栏，欠缺数量控制
					medDoc1.append(a1); 
					
					//填充按专科查询进修
					if(j==0){
						var li="<li></li>";
						medDocUl.append(li);
						j++;
					}else{
						if(j==5){
							j=0;
						}else{
							j++;
						};
					};
					var test='"'+medDocSpecs[i].specSid+'"';
					var onClick="selectLearnByParams('02',null,null,"+test+")";
					var aUl="<a  href='javascript:;'style='width:97px' onclick="+onClick+">"+medDocSpecs[i].specName+"</a>";
					$("#medDocLearnUl li:last").append(aUl);
				};
			};
			if(nerseSpecs.length>0){
				var j=0;
				for(var i=0;i<nerseSpecs.length;i++){
					var a="<a class='box1' href='../pages/spec/spec-index.jsp'>"+nerseSpecs[i].specName+"</a>";
					var a1="<a class='curr' href='../pages/spec/spec-index.jsp'>"+nerseSpecs[i].specName+"</a>";
					
					//填充菜单栏，欠缺数量控制
					nerse.append(a);
					
					//填充菜单弹出栏，欠缺数量控制
					nerse1.append(a1);
					
					//填充按专科查询进修
					if(j==0){
						var li="<li></li>";
						nerseUl.append(li);
						j++;
					}else{
						if(j==6){
							j=0;
						}else{
							j++;
						};
					};
					var test='"'+nerseSpecs[i].specSid+'"';
					var onClick="selectLearnByParams('03',null,null,"+test+")";
					var aUl="<a  href='javascript:;'style='width:97px' onclick="+onClick+">"+nerseSpecs[i].specName+"</a>";
					$("#nursLearnUl li:last").append(aUl);
				};
			};
		}
	}); 
};

//根据专科类型查询进修
function selectLearnByParams(specType,hosSid,userSid,specSid){
	Core.AjaxRequest({
		url : ws_url + "/rest/position/selectBachByParams",
		type:"POST",
		params:{
			specType:specType,
			hospitalSid:hosSid,
			userSid:userSid,
			specSid:specSid
		},
		callback : function (data) {
			console.log(data);
			if(specType!=null){
				selectLeranBySpec(data);
			}
			
		}
	}); 
}

// 按专科查询进修生产选项
function selectLeranBySpec(data) {
	$("#learnBySpec ul").remove();
	if (data != null && data.length > 0) {
		var j = 0;
		// 控制UL数量
		var ulNum = 0;
		for ( var i = 0; i < data.length; i++) {
			var isTest=data[i].isRetest;
			var isTestName='';
			if('01'==isTest){
				isTestName="需面试";
			}else{
				isTestName="不需面试";
			}
			var aHref="../pages/spec/spec-detail.jsp?deptSid="+data[i].deptSid;
			if (j == 0) {
				if (ulNum > 1) {
					break;
				}
				ulNum++;
				
				var ul = $("<ul class='clearfix'></ul>");
				$("#specDropDown").before(ul);
				var li = "<li><a href='"+aHref+"' class='specA'>" + "<h3 style='font-weight: normal;'>" + data[i].deptName
				+ "</h3>" + "<dl>" + "<dt>" + "<i class='key'>医&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;院：</i>"
				+ "<i class='value'>" + data[i].hopitalName + "</i>"
				+ "</dt>" + "<dd>" + "<i class='key'>费&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;用：</i>"
				+ "<i class='value'>" + data[i].batchCourseCost + "（元）</i>"
				+ "</dd>" + "<dd>" + "<i class='key'>进修周期：</i>"
				+ "<i class='value'>" + data[i].batchCourseLength
				+ "个月</i>" + "</dd>" + "<dd>"
				+ "<i class='key'>招生日期：</i>" + "<i class='value'>"
				+ data[i].recruitDateYear + "年"
				+ data[i].recruitDateMonth + "月</i>" + "</dd>" + "<dd>"
				+ "<i class='key'>招生人数：</i>" + "<i class='value'>"
				+ data[i].recruitPeopleNum + "人</i>" + "</dd>"
				+ "<dd>" + "<i class='key'>其&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;他：</i>"
				+ "<i class='value'>"+isTestName+"</i>" + "</dd>" + 
				"</dl>"
				+ "<p class='check_con shanchang'>擅长：" + data[i].partFeature
				+ "</p>" +
				"<p class='check_jx'>"
				+ "<strong class='yuedu'>186</strong>"
				+ "<strong class='zan'>72</strong>"
				+ "<b class='check'>查看进修</b>" + "</p>"
				+ "</a></li>";
				$("#learnBySpec ul:last").append(li);
				
				j++;
			} else {
				if (j == 2) {
					var li = "<li><a href='"+aHref+"' class='specA'>" + "<h3 style='font-weight: normal;'>" + data[i].deptName
							+ "</h3>" + "<dl>" + "<dt>" + "<i class='key'>医&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;院：</i>"
							+ "<i class='value'>" + data[i].hopitalName + "</i>"
							+ "</dt>" + "<dd>" + "<i class='key'>费&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;用：</i>"
							+ "<i class='value'>" + data[i].batchCourseCost + "（元）</i>"
							+ "</dd>" + "<dd>" + "<i class='key'>进修周期：</i>"
							+ "<i class='value'>" + data[i].batchCourseLength
							+ "个月</i>" + "</dd>" + "<dd>"
							+ "<i class='key'>招生日期：</i>" + "<i class='value'>"
							+ data[i].recruitDateYear + "年"
							+ data[i].recruitDateMonth + "月</i>" + "</dd>" + "<dd>"
							+ "<i class='key'>招生人数：</i>" + "<i class='value'>"
							+ data[i].recruitPeopleNum + "人</i>" + "</dd>"
							+ "<dd>" + "<i class='key'>其&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;他：</i>"
							+ "<i class='value'>"+isTestName+"</i>" + "</dd>" + 
							"</dl>"
							+ "<p class='check_con shanchang'>擅长：" + data[i].partFeature
							+ "</p>" +
							"<p class='check_jx'>"
							+ "<strong class='yuedu'>186</strong>"
							+ "<strong class='zan'>72</strong>"
							+ "<b class='check'>查看进修</b>" + "</p>"
							+ "</a></li>";
					j = 0;
					$("#learnBySpec ul:last").append(li);
				} else {
					var li = "<li><a href='"+aHref+"' class='specA'>" + "<h3 style='font-weight: normal;'>" + data[i].deptName
					+ "</h3>" + "<dl>" + "<dt>" + "<i class='key'>医&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;院：</i>"
					+ "<i class='value'>" + data[i].hopitalName + "</i>"
					+ "</dt>" + "<dd>" + "<i class='key'>费&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;用：</i>"
					+ "<i class='value'>" + data[i].batchCourseCost + "（元）</i>"
					+ "</dd>" + "<dd>" + "<i class='key'>进修周期：</i>"
					+ "<i class='value'>" + data[i].batchCourseLength
					+ "个月</i>" + "</dd>" + "<dd>"
					+ "<i class='key'>招生日期：</i>" + "<i class='value'>"
					+ data[i].recruitDateYear + "年"
					+ data[i].recruitDateMonth + "月</i>" + "</dd>" + "<dd>"
					+ "<i class='key'>招生人数：</i>" + "<i class='value'>"
					+ data[i].recruitPeopleNum + "人</i>" + "</dd>"
					+ "<dd>" + "<i class='key'>其&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;他：</i>"
					+ "<i class='value'>需面试</i>" + "</dd>" + 
					"</dl>"
					+ "<p class='check_con shanchang'>擅长：" + data[i].partFeature
					+ "</p>" +
					"<p class='check_jx'>"
					+ "<strong class='yuedu'>186</strong>"
					+ "<strong class='zan'>72</strong>"
					+ "<b class='check'>查看进修</b>" + "</p>"
					+ "</a></li>";
					$("#learnBySpec ul:last").append(li);
					j++;
				}
				;
			}
			;

		}
		
		
	}
	
	$(".zjjx .zk_con").children('ul').eq(1).hide();
	$(".xxg").css({
		"background":"url(../img/drop_down.png) no-repeat"
	});
	
	
}

// 查询省
/*function selectProvince(){
	Core.AjaxRequest({
		url :ws_url + "/rest/system/PROVINCE", 
		type:"get",
		callback : function (data) {
			console.log(data);
			var cityUl=$("#tab_yy");
			for(var i=0;i<data.length;i++){
				if(i==8){
					break;
				}
				var method="selectHosByProvince('"+data[i].codeValue+"')";
				if(i==0){
					console.log("selectHosByProvince('"+data[i].codeValue+"')");
					var li="<li class='active' onClick="+method+">"+data[i].codeDisplay+"</li>";
					cityUl.append(li);
				}else{
					var li="<li onClick="+method+">"+data[i].codeDisplay+"</li>";
					cityUl.append(li);
				}
				
			}
        } 
     });
	
}*/


//根据省查询医院
function selectHosByProvince(privinceSid){
//	var hosUl=$("#hosUl");
////	hosUl.children().remove();
//	if('01'==privinceSid){
//		var j=0;
//		for(var i=0;i<dataBJ.length;i++){
//			
//			//填充按专科查询进修
//			if(j==0){
//				var li=$("<li></li>");
//				$("#hosUl").append(li);
//				j++;
//			}else{
//				if(j==5){
//					j=0;
//				}else{
//					j++;
//				};
//			};
//			var aUl="<a  href='' style='width:88px'>"+dataBJ[i].hospitalName+"</a>";
//			$("#hosUl li:last").append(aUl);
//		}
//	}
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectHospital", 
		type:"POST",
		params:{
			proviceSid:privinceSid
		},
		callback : function (data) {
			var dataBJ=new Array({"hospitalName":"北京协和医院"},
			          {"hospitalName":"中国人民解放军总医院"},
			          {"hospitalName":"北京大学第一医院"},
			          {"hospitalName":"北京大学人民医院"},
			          {"hospitalName":"北京大学第三医院"},
			         
			          {"hospitalName":"中国医学科学院肿瘤医院"},
			          {"hospitalName":"中国医学科学院阜外心血管病医院"},
			          {"hospitalName":"首都医科大学附属北京安贞医院"},
			          {"hospitalName":"首都医科大学附属北京天坛医院"},
			          {"hospitalName":"首都医科大学宣武医院"},
			          {"hospitalName":"首都医科大学附属北京同仁医院"},
			          {"hospitalName":"首都医科大学附属北京儿童医院"},
			          {"hospitalName":"北京大学口腔医院"},
			          {"hospitalName":"首都医科大学附属北京朝阳医院"},
			          {"hospitalName":"北京大学肿瘤医院"},
			          {"hospitalName":"中国医学科学院整形外科医院"},
			          {"hospitalName":"北京积水潭医院"},
			          {"hospitalName":"北京大学第六医院"},
			          {"hospitalName":"中日友好医院"},
			          {"hospitalName":"首都儿科研究所"},
			          {"hospitalName":"首都医科大学附属北京地坛医院"},
			          {"hospitalName":"首都医科大学附属北京友谊医院"},
			          {"hospitalName":"中国人民解放军第三零二医院"}
			          );
			var dataTJ=new Array(
			            {"hospitalName":"天津医科大学附属肿瘤医院"},
			            {"hospitalName":"天津医科大学总医院"},
			            {"hospitalName":"中国医学科学院血液学研究所"},
			            {"hospitalName":"天津医科大学第二医院"}
			            );
			var dataSH=new Array(
			            {"hospitalName":"上海交通大学医学院附属瑞金医院"},
			            {"hospitalName":"复旦大学附属华山医院"},
			            {"hospitalName":"复旦大学附属中山医院"},
			            {"hospitalName":"上海交通大学医学院附属仁济医院"},
			            {"hospitalName":"第二军医大学长海医院"},
			            {"hospitalName":"复旦大学附属肿瘤医院"},
			            {"hospitalName":"上海交通大学医学院附属第九人民医院"},
			            {"hospitalName":"上海交通大学医学院附属新华医院"},
			            {"hospitalName":"第二军医大学长征医院"},
			            {"hospitalName":"上海市第六人民医院"},
			            {"hospitalName":"复旦大学附属眼耳鼻喉科医院"},
			            {"hospitalName":"复旦大学附属儿童医院"},
			            {"hospitalName":"上海交通大学医学院上海儿童医学中心"},
			            {"hospitalName":"上海市胸科医院"},
			            {"hospitalName":"复旦大学附属妇产科医院"},
			            {"hospitalName":"上海交通大学医学院附属第一人民医院"},
			            {"hospitalName":"同济大学附属上海市肺科医院"},
			            {"hospitalName":"上海市精神卫生中心"},
			            {"hospitalName":"东方肝胆外科医院"},
			            {"hospitalName":"上海市儿童医院"},
			            {"hospitalName":"复旦大学附属华东医院"}
			            );
			var dataAH=new Array(
			             {"hospitalName":"安徽医科大学第一附属医院"}
			             );
			var dataHLJ=new Array(
			             {"hospitalName":"哈尔滨医科大学附属第一医院"},
			             {"hospitalName":"哈尔滨医科大学附属第二医院"},
			             {"hospitalName":"哈尔滨医科大学附属肿瘤医院"}
			             );
			var dataJL=new Array(
			            {"hospitalName":"吉林大学第一医院"}
			            );
			var dataLN=new Array(
			            {"hospitalName":"中国医科大学附属盛京医院"},
			            {"hospitalName":"沈阳军区总医院"}
			            );
			var dataGD=new Array(
            {hospitalName:"中山大学附属第一医院"},
            {hospitalName:"南方医科大学南方医院"},
            {hospitalName:"中山大学肿瘤防治中心"},
            {hospitalName:"广东省人民医院"},
            {hospitalName:"广州医科大学附属第一医院"},
            {hospitalName:"中山大学孙逸仙纪念医院"},
            {hospitalName:"中山大学中山眼科医院"},
            {hospitalName:"中山大学附属第三医院"},
            {hospitalName:"广州市妇女儿童医疗中心"}
            );
var dataHB=Array(
             {hospitalName:"华中科技大学同济医学院附属同济医院"},
             {hospitalName:"华中科技大学同济医学院附属协和医院"},
             {hospitalName:"武汉大学人民医院"},
             {hospitalName:"武汉大学口腔医院"}
             );
var dataHN=Array(
            {hospitalName:"中南大学湘雅二医院"},
            {hospitalName:"中南大学湘雅医院"}
            );
var dataJS=Array(
            {hospitalName:"江苏省人民医院"},
            {hospitalName:"南京军区南京总医院"},
            {hospitalName:"南京大学医学院附属鼓楼医院"},
            {hospitalName:"苏州大学附属第一医院"},
            {hospitalName:"中国医学科学院皮肤病医院（研究所）"},
            {hospitalName:"南京医科大学附属南京第一医院"}
            );
var dataSD=Array(
            {hospitalName:"山东大学齐鲁医院"},
            {hospitalName:"山东省立医院"},
            {hospitalName:"山东省肿瘤医院"}
            );
var dataSX=Array(
            {hospitalName:"第四军医大学西京医院"},
            {hospitalName:"第四军医大学唐都医院"},
            {hospitalName:"第四军医大学口腔医院"},
            {hospitalName:"西安交通大学医学院第一附属医院"},
            {hospitalName:"西安交通大学医学院第二附属医院"}
            );

var dataSC=Array(
            {hospitalName:"四川大学华西医院"},
            {hospitalName:"四川大学华西口腔医院"},
            {hospitalName:"四川大学华西第二医院"}
            );
var dataZJ=Array(
            {hospitalName:"浙江大学医学院附属第一医院"},
            {hospitalName:"浙江大学医学院附属第二医院"},
            {hospitalName:"浙江大学医学院附属儿童医院"},
            {hospitalName:"浙江大学医学院附属妇产科医院"},
            {hospitalName:"浙江省肿瘤医院"}
            );
var dataCQ=Array(
            {hospitalName:"第三军医大学西南医院"},
            {hospitalName:"重庆医科大学附属儿童医院"},
            {hospitalName:"重庆医科大学妇产科医院"},
            {hospitalName:"第三军医大学新桥医院"},
            {hospitalName:"重庆医科大学附属第二医院"}
            );
			var data=null;
			if('01'==privinceSid){
				data=dataBJ;
			}else if('03'==privinceSid){
				data=dataSH;
			}else if('19'==privinceSid){
				data=dataGD;
			}else if('17'==privinceSid){
				data=dataJS;
			}else if('28'==privinceSid){
				data=dataZJ;
			}else if('04'==privinceSid){
				data=dataCQ;
			}else if('11'==privinceSid){
				data=dataSX;
			}else if('14'==privinceSid){
				data=dataHB;
			}else if('08'==privinceSid){
				data=dataLN;
			}else if('15'==privinceSid){
				data=dataHN;
			}else if('23'==privinceSid){
				data=dataSC;
			}else if('02'==privinceSid){
				data=dataTJ;
			}else if('09'==privinceSid){
				data=dataSD;
			}else if('08'==privinceSid){
				data=dataLN;
			}else if('06'==privinceSid){
				data=dataHLJ;
			}
				var hosUl=$("#hosUl");
				hosUl.children().remove();
				var j=0;
				for(var i=0;i<data.length;i++){
					
					//填充按专科查询进修
					if(j==0){
						var li="<li style='display:block'></li>";
						hosUl.append(li);
						j++;
					}else{
						if(j==2){
							j=0;
						}else{
							j++;
						};
					};
					var aUl="<a  href='javascript:;' style='width:227px'>"+data[i].hospitalName+"</a>";
					$("#hosUl li:last").append(aUl);
				}
			}
			
     });
}


//查询所有专科
function selectSpec(){
	Core.AjaxRequest({
		url :ws_url + "/rest/dept/selectAllSpec", 
		type:"POST",
		params:{
			
		},
		callback : function (data) {
			console.log(data);
			var j=0;
			for(var i=0;i<dataDocSpec.length;i++){
				if(j==6){
					break;
				}
				var method="selectUserBySpec('"+dataDocSpec[i].specSid+"')";
				var aUl="<li onClick="+method+">"+dataDocSpec[i].specName+"</li>";
				$("#all_ds").append(aUl);
				j++;
			}
			
			var m=0;
			var n=0;
			for(var k=0;k<dataDocSpec.length;k++){
				if(m==0){
					if(n>3){
						break;
					}
					var li="<li></li>";
					$("#yxClassSpec").append(li);
					var aUl="<span style='width:135px'><a href='../pages/yxclass/yx_filter.jsp'>"+dataDocSpec[k].specName+"</a></span>";
					$("#yxClassSpec li:last").append(aUl);
					m++;
					n++;
				}else{
					if(m>4){
						m=0;
//						var aUl="<span style='width:135px'><a href=''>"+data[k].specName+"</a></span>";
//						$("#yxClassSpec li:last").append(aUl);
					}else{
						var aUl="<span style='width:135px'><a href='../pages/yxclass/yx_filter.jsp'>"+dataDocSpec[k].specName+"</a></span>";
						$("#yxClassSpec li:last").append(aUl);
						m++;
					};
				};
			}
        } 
     });
}
function checkRepeatRandom(num,randomArray){
	var flag=false;
	for(var i=0;i<randomArray.length;i++){
		if(num==randomArray[i]){
			flag=true;
			break;
		}
	}
	
	return flag;
}
function selectUserBySpec(specSid){
	Core.AjaxRequest({
		url :ws_url + "/rest/user/selectTutorBySpec", 
		type:"POST",
		params:{
			specSid:specSid
		},
		callback : function (data) {
			console.log(data);
			$("#totures ul").remove();
			if (data != null && data.length > 0) {
				var dataRandom=new Array();
				var randomNum=new Array();
				if(data.length>3){
					//循环3次取3个随机数，并判断是否重复
					for(var m=0;m<3;m++){
						var random=Math.ceil(Math.random()*data.length);
						if(m==0){
							randomNum.push(random);
						}else{
							
							//判断数组中是否已存在
							var flag=true;
							var a=1;
							while(flag){
								if(randomNum.length>2){
									flag=false;
									break;
								}
								flag=checkRepeatRandom(random,randomNum);
								if(flag){
									random=Math.ceil(Math.random()*data.length);
								}else{
									randomNum.push(random);
								}
								
							}
						}
					}
					dataRandom[0]=data[randomNum[0]-1];
					dataRandom[1]=data[randomNum[1]-1];
					dataRandom[2]=data[randomNum[2]-1];
				}else{
					dataRandom[0]=data[0];
					dataRandom[1]=data[1];
					dataRandom[2]=data[2];
				}
				console.log(dataRandom);
				
				var j = 0;
				// 控制UL数量
				var ulNum = 0;
				for ( var i = 0; i < dataRandom.length; i++) {
					if (j == 0) {
						if (ulNum > 0) {
							break;
						}
						ulNum++;

						var ul = "<ul class='clearfix'></ul>";
						$("#totures").append(ul);
						// ul.insertBefore();
						var li = "<li><h3 style='border-radius:50%'><a href='../pages/expert/expert-personal.jsp?userSid="+dataRandom[i].userSid+"'><img width='130' height='130' style='border-radius:50%;' src='"+ctx+"/"+dataRandom[i].faceImage+"' alt=''></a></h3>" +
						"<a href='../pages/expert/expert-personal.jsp' class='ds_a'><dl style='line-height:20px'>" +
							"<dt>"+dataRandom[i].realName+"</dt>" +
							"<dd>" +
								"<i class='key'>"+dataRandom[i].hosName+"</i> " +
							"</dd>" +
							"<dd>" +
							"<i class='value'>"+dataRandom[i].deptName+"</i> &nbsp;&nbsp;&nbsp;" +
							"<i class='value'>"+dataRandom[i].workTitle+"</i>" +
						"</dd>" +
						"</dl></a>" +
						
						
						"<p class='shanchang'>擅长："+dataRandom[i].keySkills+""+
						"</p>"+
						"<p class='check_jx'>" +
							"<strong class='yuedu'>186</strong>" +
							"<strong class='zan'>72</strong>" +
							"<a href='../pages/expert/expert-personal.jsp' class='check'>查看进修</a>" +
						"</p>" +
						
					"</li>";
						$("#totures ul:last").append(li);
						j++;
					} else {
						if (j == 2) {
							var li = "<li><h3 style='border-radius:50%'><a href='../pages/expert/expert-personal.jsp'><img width='130' height='130' style='border-radius:50%;' src='"+ctx+"/"+dataRandom[i].faceImage+"' alt=''></a></h3>" +
							"<a href='../pages/expert/expert-personal.jsp' class='ds_a'><dl style='line-height:20px'>" +
								"<dt>"+dataRandom[i].realName+"</dt>" +
								"<dd>" +
									"<i class='key'>"+dataRandom[i].hosName+"</i> " +
								"</dd>" +
								"<dd>" +
								"<i class='value'>"+dataRandom[i].deptName+"</i> &nbsp;&nbsp;&nbsp;" +
								"<i class='value'>"+dataRandom[i].workTitle+"</i>" +
							"</dd>" +
							"</dl></a>" +
							
							
							"<p class='shanchang'>擅长："+dataRandom[i].keySkills+""+
							"</p>"+
							"<p class='check_jx'>" +
								"<strong class='yuedu'>186</strong>" +
								"<strong class='zan'>72</strong>" +
								"<a href='../pages/expert/expert-personal.jsp' class='check'>查看进修</a>" +
							"</p>" +
							
						"</li>";
							$("#totures ul:last").append(li);
							j = 0;
						} else {
							var li = "<li><h3 style='border-radius:50%'><a href='../pages/expert/expert-personal.jsp'><img width='130' height='130' style='border-radius:50%;' src='"+ctx+"/"+dataRandom[i].faceImage+"' alt=''></a></h3>" +
							"<a href='../pages/expert/expert-personal.jsp' class='ds_a'><dl style='line-height:20px'>" +
								"<dt>"+dataRandom[i].realName+"</dt>" +
								"<dd>" +
									"<i class='key'>"+dataRandom[i].hosName+"</i> " +
								"</dd>" +
								"<dd>" +
								"<i class='value'>"+dataRandom[i].deptName+"</i> &nbsp;&nbsp;&nbsp;" +
								"<i class='value'>"+dataRandom[i].workTitle+"</i>" +
							"</dd>" +
							"</dl></a>" +
							
							
							"<p class='shanchang'>擅长："+dataRandom[i].keySkills+""+
							"</p>"+
							"<p class='check_jx'>" +
								"<strong class='yuedu'>186</strong>" +
								"<strong class='zan'>72</strong>" +
								"<a href='../pages/expert/expert-personal.jsp' class='check'>查看进修</a>" +
							"</p>" +
							
						"</li>";
							$("#totures ul:last").append(li);
							j++;
						}
						;
					}
					;

				}
			}
        } 
     });
}

// ----------------------------------------------
//登录框显示隐藏
function showBg() { 
var bh = $("body").height(); 
var bw = $("body").width(); 
$("#fullbg").css({ 
height:bh, 
width:bw, 
display:"block" 
}); 
$("#dialog").show(); 
} 
//关闭灰色 jQuery 遮罩 
function closeBg() { 
$("#fullbg,#dialog").hide(); 
} 


//----------------------------------------------
//用户协议显示隐藏
function showProtocol() { 
var bh = $("body").height(); 
var bw = $("body").width(); 
$("#fullbg").css({ 
height:bh, 
width:bw, 
display:"block" 
}); 
$("#protocol").show(); 
} 
//关闭灰色 jQuery 遮罩 
function closeProtocol() { 
$("#fullbg,#protocol").hide(); 
} 

/*var dataGD=[
            {hospitalName:"中山大学附属第一医院"},
            {hospitalName:"南方医科大学南方医院"},
            {hospitalName:"中山大学肿瘤防治中心"},
            {hospitalName:"广东省人民医院"},
            {hospitalName:"广州医科大学附属第一医院"},
            {hospitalName:"中山大学孙逸仙纪念医院"},
            {hospitalName:"中山大学中山眼科医院"},
            {hospitalName:"中山大学附属第三医院"},
            {hospitalName:"广州市妇女儿童医疗中心"},
            ];
var dataHLJ=[
        {hospitalName:"哈尔滨医科大学附属第一医院"},
        {hospitalName:"哈尔滨医科大学附属第二医院"},
        {hospitalName:"哈尔滨医科大学附属肿瘤医院"},
        ];
var dataHB=[
             {hospitalName:"华中科技大学同济医学院附属同济医院"},
             {hospitalName:"华中科技大学同济医学院附属协和医院"},
             {hospitalName:"武汉大学人民医院"},
             {hospitalName:"武汉大学口腔医院"},
             ];
var dataHN=[
            {hospitalName:"中南大学湘雅二医院"},
            {hospitalName:"中南大学湘雅医院"},
            ];
var dataJL=[
            {hospitalName:"吉林大学第一医院"},
            ];
var dataJS=[
            {hospitalName:"江苏省人民医院"},
            {hospitalName:"南京军区南京总医院"},
            {hospitalName:"南京大学医学院附属鼓楼医院"},
            {hospitalName:"苏州大学附属第一医院"},
            {hospitalName:"中国医学科学院皮肤病医院（研究所）"},
            {hospitalName:"南京医科大学附属南京第一医院"},
            ];
var dataLN=[
            {hospitalName:"中国医科大学附属盛京医院"},
            {hospitalName:"沈阳军区总医院"},
            ];
var dataSD=[
            {hospitalName:"山东大学齐鲁医院"},
            {hospitalName:"山东省立医院"},
            {hospitalName:"山东省肿瘤医院"},
            ];
var dataSX=[
            {hospitalName:"第四军医大学西京医院"},
            {hospitalName:"第四军医大学唐都医院"},
            {hospitalName:"第四军医大学口腔医院"},
            {hospitalName:"西安交通大学医学院第一附属医院"},
            {hospitalName:"西安交通大学医学院第二附属医院"},
            ];
var dataSH=[
            {hospitalName:"上海交通大学医学院附属瑞金医院"},
            {hospitalName:"复旦大学附属华山医院"},
            {hospitalName:"复旦大学附属中山医院"},
            {hospitalName:"上海交通大学医学院附属仁济医院"},
            {hospitalName:"第二军医大学长海医院"},
            {hospitalName:"复旦大学附属肿瘤医院"},
            {hospitalName:"上海交通大学医学院附属第九人民医院"},
            {hospitalName:"上海交通大学医学院附属新华医院"},
            {hospitalName:"第二军医大学长征医院"},
            {hospitalName:"上海市第六人民医院"},
            {hospitalName:"复旦大学附属眼耳鼻喉科医院"},
            {hospitalName:"复旦大学附属儿童医院"},
            {hospitalName:"上海交通大学医学院附属上海儿童医学中心"},
            {hospitalName:"上海市胸科医院"},
            {hospitalName:"复旦大学附属妇产科医院"},
            {hospitalName:"上海交通大学医学院附属第一人民医院"},
            {hospitalName:"同济大学附属上海市肺科医院"},
            {hospitalName:"上海市精神卫生中心"},
            {hospitalName:"东方肝胆外科医院"},
            {hospitalName:"上海市儿童医院"},
            {hospitalName:"复旦大学附属华东医院"},
            ];

var dataSC=[
            {hospitalName:"四川大学华西医院"},
            {hospitalName:"四川大学华西口腔医院"},
            {hospitalName:"四川大学华西第二医院"},
            ];
var dataTJ=[
            {hospitalName:"天津医科大学附属肿瘤医院"},
            {hospitalName:"天津医科大学总医院"},
            {hospitalName:"中国医学科学院血液学研究所"},
            {hospitalName:"天津医科大学第二医院"},
            ];
var dataZJ=[
            {hospitalName:"浙江大学医学院附属第一医院"},
            {hospitalName:"浙江大学医学院附属第二医院"},
            {hospitalName:"浙江大学医学院附属儿童医院"},
            {hospitalName:"浙江大学医学院附属妇产科医院"},
            {hospitalName:"浙江省肿瘤医院"},
            ];
var dataCQ=[
            {hospitalName:"第三军医大学西南医院"},
            {hospitalName:"重庆医科大学附属儿童医院"},
            {hospitalName:"重庆医科大学妇产科医院"},
            {hospitalName:"第三军医大学新桥医院"},
            {hospitalName:"重庆医科大学附属第二医院"},
            ];*/


