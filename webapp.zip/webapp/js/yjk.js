$(function(){
	    
		//日期插件
		$( ".classtime" ).datepicker();
		$( "#public_st" ).datepicker();
		
//		getPage(".fenye","yx_sort_ul",1);
//		getPage(".fenye","attention",1);
//		getPage(".fenye","train_content_s",1);
//		getPage(".fenye","train_content",1);
//		getPage(".fenye","yjk_yfs_c",1);
//		getPage(".fenye","ks_yxgl_fy",1);
//		getPage(".fenye","xq_sort_ul",1);
//		getPage(".fenye_yxbinfo","yxbinfo",1);
//		getPage(".fenye_tzfb","tzfb",1);
		
		
		
});

/*function alert_box_check(load_ele, data) {

   // var b_h = $(document).height();
	var b_h=$(".viewReusmeDiv").height();

    var creBox = $("<div class='aler_bg'>").css({
        "width": "100%",
        "height": b_h,
        "position": "absolute",
        "left": 0,
        "top": 0,

        "background": "rgba(0,0,0,.5)",

        "z-index": 300
    });
    creBox.bind("click",function(){
    	$(this).remove();
    });
    $(creBox).appendTo($("body"));
    $(creBox).load(load_ele, data);

}*/




