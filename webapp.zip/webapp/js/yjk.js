var medEduPartSid=null;
var deptSid=null;
//若用户已经登录设置医教科SID
if (currentUser != null && currentUser != '' && currentUser != "") { 
	medEduPartSid=currentUser.medEduSid;
	deptSid=currentUser.partSid;
}
