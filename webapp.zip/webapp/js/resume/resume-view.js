function getResumeByUserSid(userSid){
	console.log(userSid);
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/getResumeByUserSid/"+userSid, 
		type:"get",
		callback : function (data) {
			console.log(data);
			$("#realName").html(data.realName);
			$("#sex").html(data.sexName);
			$("#age").html(data.age+"岁");
			$("#nation").html(data.nationName);
			$("#nativePlace").html(data.provinceName);
			$("#cardId").html(data.cardId);
			$("#birthTime").html(data.birthDate);
			$("#isMary").html(data.isMaryName);
			$("#polityStatus").html(data.polityName);
			$("#healthStatus").html(data.healthStatusName);
			if(data.resumeLanList.length>0){
				$("#lanName").html(data.resumeLanList[0].languageName);
				$("#lanLevel").html(data.resumeLanList[0].languageLevelName);
			}
			$("#mobile").html(data.mobile);
			$("#email").html(data.mail);
			$("#leanrRequest").html(data.learnPurposeRequire);
			$("#currentState").html(data.currentState);
			
			//教育经历
			var stuProcess=data.resumeSPList;
			if(stuProcess!=null&&stuProcess.length>0){
				$("#eduInfo li").remove();
				$.each(stuProcess,function(index,content){
					var li="<li>"+content.collageBeginDate+"——"+content.collageEndDate+" "+content.collageName+" "+content.majorName+" "+content.degreeName+"  "+content.collegeDegreeName+"</li>";
					$("#eduInfo").append(li);
				});
			}
			
			//工作经历
			var workProcess=data.resumeWPList;
			if(workProcess!=null&&workProcess.length>0){
				$("#workInfo li").remove();
				$.each(workProcess,function(index,content){
					if("current"==content.workEndDate){
						$("#currentHosName").html(content.hospitalName);
						$("#currentHosLevel").html(content.hospitalLevelName);
						$("#currentMedEduTelephone").html(content.medEduTelephone);
						$("#currentDept").html(content.partName);
						$("#currentDeptBedNum").html(content.deptBedNum);
						$("#currentDeptTelephone").html(content.deptTelephone);
						$("#currentWorkDuty").html(content.workDutyName);
						$("#currentTitle").html(content.hospitalTitleName);
						$("#currentTitleGetTime").html(content.titleGetDate);
						$("#beginWorkTime").html(content.workBeginDate);
						$("#workLength").html(content.workMajorLength+"年");
						var li="<li>"+content.workBeginDate+"—— 至今 "+content.hospitalName+" "+content.partName+"</li>";
						$("#workInfo").append(li);
					}else{
						var li="<li>"+content.workBeginDate+"——"+content.workEndDate+" "+content.hospitalName+" "+content.partName+"</li>";
						$("#workInfo").append(li);
					}
				});
			}
			
			//相关证件
			var cerList=data.resumeCerList;
			if(cerList!=null&&cerList.length>0){
				$("#otherCerUl li").remove();
				$.each(cerList,function(index,content){
					if("01"==content.cerType){
						$("#cerQuaImage").attr("src",""+ctx+"/img/cer.png");
						$("#cerQuaNum").html(content.cerNo);
						$("#cerQuaNumGetDate").html(content.cerAwardDate);
					}else if("02"==content.cerType){
						$("#cerPraNumImage").attr("src",""+ctx+"/img/cer.png");
						$("#cerPraScopeImage").attr("src",""+ctx+"/img/cer.png");
						$("#cerPraType").html(content.cerPraTypeName);
						$("#cerPraScope").html(content.cerPraScope);
						$("#cerPraLocation").html(content.cerPraLocation);
						$("#cerPraNum").html(content.cerNo);
						$("#cerPraGetDate").html(content.cerAwardDate);
					}else if("03"==content.cerType){
						var li="<li style='width:155px;'><i>"+content.cerName+"</i><img alt='' src='"+ctx+"/img/cer.png'></li>";
						$("#otherCerUl").append(li);
					}
				});
			}
      }
   });
}

//查询所报进修
function getPosBatchByResDept(resDeptSidView){
	Core.AjaxRequest({
		url :ws_url + "/rest/position/selectResPosByResDeptSid/"+resDeptSidView, 
		type:"get",
		async:false,
		callback : function (data) {
			$("#registerDeptName").html(data.deptName);
			$("#registerLearnBeginDate").html(data.learnBeginDateYear+"年"+data.learnBeginDateMonth+"月");
			$("#registerLearnLength").html(data.cycleLength+"个月");
			$("#registerSubDeptName").html(data.subDept);
			if("01"==data.isDeptFlag){
				$("#flagStu").html("已标记");
				$("#flagStu").attr("class","flagStu");
				flag=true;
			}else{
				$("#flagStu").html("标记星标学员");
				$("#flagStu").attr("class","noflagStu");
				flag=false;
			}
		} 
	})
}

//标记学员
function changeDeptFlag(flag){
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/changeDeptFlag/"+flag+"/"+resDeptSidView, 
		type:"get",
		async:false,
		callback : function (data) {
			console.log(data.isDeptFlag);
			if("01"==data.isDeptFlag){
				$("#flagStu").html("已标记");
				$("#flagStu").attr("class","flagStu");
			}else{
				$("#flagStu").html("标记星标学员");
				$("#flagStu").attr("class","noflagStu");
			}
		} 
	})
}

//发送单一简历到科室
function sendReusmeToDeptView(resDeptSid){
	var resDeptSidArray=new Array();
	resDeptSidArray.push(resDeptSid);
	console.log(resDeptSidArray);
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/deliveryResumeToDept", 
		type:"POST",
		params:{
			resumeDeptSid:resDeptSidArray,
		},
		callback : function (data) {
			selectResumeByParams();
      } 
   });
	
}

//医教科拒绝
function refuseResumeView(resDeptSid){
	var resDeptSidArray=new Array();
	resDeptSidArray.push(resDeptSid);
	Core.AjaxRequest({
		url :ws_url + "/rest/resume/oprateResume", 
		type:"POST",
		params:{
			resumeDeptSids:resDeptSidArray,
			status:"05"
		},
		callback : function (data) {
			selectResumeByParams();
		} 
   });
	
}