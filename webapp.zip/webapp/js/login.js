				
		// TO_DO  添加enter建登录
		function verifyUser(logType) {
// 			$("#login").removeClass("animated").removeClass("shake");
			if($("#login-username").val() =="" && $("#login-password").val() !=""){
				setTimeout(function(){
					$("#login").addClass("animated").addClass("shake");
		    		$("#login-message").css("color","red").html("请输入用户名！");
				},50);
			}else if($("#login-username").val() !="" && $("#login-password").val() ==""){
				setTimeout(function(){
					$("#login").addClass("animated").addClass("shake");
		    		$("#login-message").css("color","red").html("请输入密码！");
				},50);
			}else if($("#login-username").val() =="" && $("#login-password").val() ==""){
				setTimeout(function(){
					$("#login").addClass("animated").addClass("shake");
		    		$("#login-message").css("color","red").html("请输入用户名和密码！");
				},50);
			}else{
				//验证用户
				Core.AjaxRequest({
					url : ws_url + "/rest/user/verify",
					params : { 
						registMail : $("#login-username").val(),
						password : $("#login-password").val(),
						logType : logType
					},
					callback : function (data) {
						if (data.status == "failure") {
				    		$("#login").addClass("animated").addClass("shake");
				    		$("#login-message").css("color","red").html(""+ data.message +"");
						} else {
							// 获取user信息
							var user = data.user;
							if(user) {
//	 							if(user.userType == "01") {
//	 								window.location.href = ctx + "/pages/approve-mgt.jsp";
//	 							} else {
									window.location.href = ctx + "/pages/index.jsp";
//	 							}
							} else {
								window.location.href = ctx + "/pages/index.jsp";
							}
						}
				    },
				    failure:function(data){
			    		var errorObj = data.responseJSON; 
			    		$("#login").addClass("animated").addClass("shake");
			    		$("#login-message").css("color","red").html(""+errorObj.message+"");
				    }
				});
			}
		}